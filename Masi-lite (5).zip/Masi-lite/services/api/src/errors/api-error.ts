import { ZodError } from "zod";

export class ApiError extends Error {
  readonly status: number;
  readonly code: string;
  readonly details?: unknown;

  constructor(status: number, code: string, message: string, details?: unknown) {
    super(message);
    this.status = status;
    this.code = code;
    this.details = details;
  }
}

export function toErrorPayload(error: unknown) {
  if (error instanceof ZodError) {
    return {
      status: 400,
      payload: {
        error: {
          code: "VALIDATION_ERROR",
          message: "Request validation failed",
          details: error.issues
        }
      }
    };
  }

  if (error instanceof ApiError) {
    return {
      status: error.status,
      payload: {
        error: {
          code: error.code,
          message: error.message,
          details: error.details ?? []
        }
      }
    };
  }

  return {
    status: 500,
    payload: {
      error: {
        code: "INTERNAL_ERROR",
        message: "Unexpected server error",
        details: []
      }
    }
  };
}
