import { env } from "./config/env.js";
import { closeDbPool } from "./db/pool.js";
import { createServer } from "./server.js";

const app = createServer();

const server = app.listen(env.PORT, () => {
  console.log(`MASI API listening on http://localhost:${env.PORT}`);
});

async function shutdown(signal: string) {
  console.log(`Received ${signal}. Shutting down MASI API...`);

  server.close(async () => {
    await closeDbPool();
    process.exit(0);
  });
}

process.on("SIGINT", () => {
  void shutdown("SIGINT");
});

process.on("SIGTERM", () => {
  void shutdown("SIGTERM");
});
