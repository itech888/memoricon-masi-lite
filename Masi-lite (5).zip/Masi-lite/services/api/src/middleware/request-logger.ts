import type { NextFunction, Request, Response } from "express";

export function requestLoggerMiddleware(req: Request, res: Response, next: NextFunction) {
  const startMs = Date.now();

  res.on("finish", () => {
    const durationMs = Date.now() - startMs;
    const requestId = req.requestId ?? "n/a";

    console.log(
      JSON.stringify({
        level: "info",
        request_id: requestId,
        method: req.method,
        path: req.originalUrl,
        status: res.statusCode,
        duration_ms: durationMs
      })
    );
  });

  next();
}
