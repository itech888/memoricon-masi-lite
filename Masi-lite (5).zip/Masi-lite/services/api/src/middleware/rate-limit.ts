import rateLimit from "express-rate-limit";

import { env } from "../config/env.js";

export const captureRateLimit = rateLimit({
  windowMs: env.RATE_LIMIT_WINDOW_MS,
  limit: env.RATE_LIMIT_MAX_CAPTURE,
  standardHeaders: true,
  legacyHeaders: false,
  message: {
    error: {
      code: "RATE_LIMITED",
      message: "Too many capture requests. Please retry shortly.",
      details: []
    }
  }
});

export const askRateLimit = rateLimit({
  windowMs: env.RATE_LIMIT_WINDOW_MS,
  limit: env.RATE_LIMIT_MAX_ASK,
  standardHeaders: true,
  legacyHeaders: false,
  message: {
    error: {
      code: "RATE_LIMITED",
      message: "Too many ask requests. Please retry shortly.",
      details: []
    }
  }
});
