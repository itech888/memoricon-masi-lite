import { env } from "../config/env.js";
import { prisma } from "../db/prisma.js";

async function runMigration() {
  if (!env.DATABASE_URL) {
    throw new Error("DATABASE_URL is required to run migrations.");
  }

  // Legacy script kept for compatibility. Prisma migrations are executed via:
  // `npm run db:migrate` / `npm run db:migrate:dev` / `npm run db:migrate:deploy`
  await prisma.$queryRaw`SELECT 1`;
  console.log("Database connection verified. Run `npm run db:migrate` to apply Prisma migrations.");
}

runMigration()
  .catch((error) => {
    console.error("Migration check failed:", error);
    process.exitCode = 1;
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
