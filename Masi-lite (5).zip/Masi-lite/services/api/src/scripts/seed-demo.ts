import type { MemoryDraft } from "../schemas/memory.js";

import { buildMemoryEmbeddingText, createVerifiedMemoryWithEmbedding } from "../db/embeddings.js";
import { prisma } from "../db/prisma.js";
import { createEmbedding } from "../lib/openai.js";

const DEMO_SESSION_ID = "11111111-1111-4111-8111-111111111111";

const seedMemories: MemoryDraft[] = [
  {
    transcript:
      "The vacuum pump pressure on Line 3 dropped below threshold during wafer processing. I stopped the process and replaced the pump filter.",
    summary: "Vacuum pump pressure drop on Line 3",
    tags: ["maintenance", "pump", "wafer-processing"],
    masi: {
      state: "Wafer processing operation on Line 3",
      intent: "Maintain safe operating conditions",
      constraint: "Pump pressure must remain above minimum threshold",
      verification: "Pump filter replacement performed",
      outcome: "Process paused and maintenance action taken"
    },
    confidence_score: 0.92,
    source_device: "web",
    audio_url: null,
    verification_status: "verified",
    verification_response: "confirmed",
    verification_question:
      "We detected a maintenance event where the vacuum pump pressure dropped and the filter was replaced. Is this confirmed?"
  },
  {
    transcript:
      "I told Jenifer that smart glasses will capture audio but verification runs on the server.",
    summary: "Smart glasses capture audio while verification stays server-side",
    tags: ["smart-glasses", "architecture", "verification"],
    masi: {
      state: "Architecture discussion about smart glasses input",
      intent: "Define device-agnostic capture and verification architecture",
      constraint: "Verification logic must execute on backend services",
      verification: "Server-side verification requirement stated explicitly",
      outcome: "Capture on device and verify/store on server architecture confirmed"
    },
    confidence_score: 0.9,
    source_device: "web",
    audio_url: null,
    verification_status: "verified",
    verification_response: "confirmed",
    verification_question: "Is the smart glasses architecture statement accurate?"
  },
  {
    transcript:
      "During line startup, we delayed release until calibration finished and all safety checks passed.",
    summary: "Startup release delayed until calibration and safety checks",
    tags: ["startup", "calibration", "safety"],
    masi: {
      state: "Production line startup",
      intent: "Prevent unsafe release",
      constraint: "Calibration and safety checks must pass before release",
      verification: "Safety checklist completed and signed off",
      outcome: "Release delayed until requirements were met"
    },
    confidence_score: 0.88,
    source_device: "web",
    audio_url: null,
    verification_status: "verified",
    verification_response: "confirmed",
    verification_question: "Is this startup delay event confirmed?"
  }
];

async function run() {
  let inserted = 0;
  let skipped = 0;

  for (const memory of seedMemories) {
    const existing = await prisma.memory.findFirst({
      where: {
        summary: memory.summary,
        sessionId: DEMO_SESSION_ID,
        verificationStatus: "verified"
      },
      select: { id: true }
    });

    if (existing) {
      skipped += 1;
      continue;
    }

    const embedding = await createEmbedding(buildMemoryEmbeddingText(memory));
    await createVerifiedMemoryWithEmbedding({
      draft: memory,
      sessionId: DEMO_SESSION_ID,
      embedding,
      embeddingModel: process.env.OPENAI_EMBEDDING_MODEL ?? "text-embedding-3-small"
    });
    inserted += 1;
  }

  console.log(`Seed complete. Inserted: ${inserted}, Skipped: ${skipped}`);
}

run()
  .catch((error) => {
    console.error("Seed failed:", error);
    process.exitCode = 1;
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
