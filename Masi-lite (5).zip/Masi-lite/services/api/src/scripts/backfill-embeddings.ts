import { prisma } from "../db/prisma.js";
import { buildMemoryEmbeddingText, upsertMemoryEmbedding } from "../db/embeddings.js";
import { listVerifiedMemoriesForBackfill } from "../db/memories.js";
import { env } from "../config/env.js";
import { createEmbedding } from "../lib/openai.js";

async function run() {
  const memories = await listVerifiedMemoriesForBackfill();
  let updated = 0;

  for (const memory of memories) {
    const embedding = await createEmbedding(buildMemoryEmbeddingText(memory));
    await upsertMemoryEmbedding({
      memoryId: memory.id,
      model: env.OPENAI_EMBEDDING_MODEL,
      embedding
    });
    updated += 1;
  }

  console.log(`Embedding backfill complete. Updated: ${updated}`);
}

run()
  .catch((error) => {
    console.error("Embedding backfill failed:", error);
    process.exitCode = 1;
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
