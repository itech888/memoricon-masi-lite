import { env } from "../config/env.js";
import { prisma } from "../db/prisma.js";

async function runSmoke() {
  if (!env.DATABASE_URL) {
    throw new Error("DATABASE_URL is required to run DB smoke tests.");
  }

  const inserted = await prisma.memory.create({
    data: {
      transcript: "Smoke test transcript",
      summary: "Smoke test summary",
      tags: ["smoke-test"],
      masiState: "Smoke test state",
      masiIntent: "Smoke test intent",
      masiConstraint: "Smoke test constraint",
      masiVerification: "Smoke test verification",
      masiOutcome: "Smoke test outcome",
      confidenceScore: 0.95,
      sourceDevice: "cli",
      audioUrl: null,
      verificationStatus: "verified",
      verificationResponse: "confirmed",
      verificationQuestion: "Is this smoke test valid?",
      verifiedAt: new Date()
    },
    select: { id: true }
  });

  const verify = await prisma.memory.findUnique({
    where: { id: inserted.id },
    select: { summary: true }
  });

  if (verify?.summary !== "Smoke test summary") {
    throw new Error("DB smoke verification failed. Inserted row not found.");
  }

  await prisma.memory.delete({ where: { id: inserted.id } });

  console.log("DB smoke test passed.", { insertedId: inserted.id });
}

runSmoke()
  .catch((error) => {
    console.error("DB smoke test failed:", error);
    process.exitCode = 1;
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
