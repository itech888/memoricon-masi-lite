type CaptureResponse = {
  draft_memory: {
    transcript: string;
    summary: string;
    tags: string[];
    masi: {
      state: string;
      intent: string;
      constraint: string;
      verification: string;
      outcome: string;
    };
    confidence_score: number;
    source_device: string;
    audio_url: string | null;
    verification_status: "draft" | "verified" | "discarded";
    verification_question?: string;
    verification_response:
      | "confirmed"
      | "needs_clarification"
      | "insufficient_detail";
  };
};

type SaveResponse = {
  memory: {
    id: string;
    timestamp: string;
    summary: string;
    verification_status: string;
  };
};

type ListResponse = {
  items: Array<{
    id: string;
    summary: string;
  }>;
  total: number;
};

type AskResponse = {
  answer: string;
  citations: Array<{
    memory_id: string;
    summary: string;
  }>;
};

const API_BASE_URL = (process.env.API_BASE_URL ?? "http://localhost:8080").replace(/\/$/, "");

async function request<T>(path: string, init?: RequestInit): Promise<T> {
  const response = await fetch(`${API_BASE_URL}${path}`, {
    ...init,
    headers: {
      "Content-Type": "application/json",
      ...(init?.headers ?? {})
    }
  });

  const payload = await response.json();

  if (!response.ok) {
    throw new Error(`Request failed (${response.status}): ${JSON.stringify(payload)}`);
  }

  return payload as T;
}

async function run() {
  const capture = await request<CaptureResponse>("/capture", {
    method: "POST",
    body: JSON.stringify({
      input_type: "text",
      text: "The vacuum pump pressure on Line 3 dropped below threshold during wafer processing. I stopped the process and replaced the pump filter.",
      source_device: "smoke-test"
    })
  });

  if (!capture.draft_memory.transcript) {
    throw new Error("Capture failed: transcript is empty.");
  }

  const save = await request<SaveResponse>("/memory", {
    method: "POST",
    body: JSON.stringify({
      ...capture.draft_memory,
      verification_status: "verified",
      verification_response: "confirmed"
    })
  });

  const list = await request<ListResponse>("/memory?limit=10&offset=0&q=vacuum");
  if (!list.items.some((item) => item.id === save.memory.id)) {
    throw new Error("Saved memory not found in timeline list query.");
  }

  const ask = await request<AskResponse>("/ask", {
    method: "POST",
    body: JSON.stringify({
      question: "What happened with the vacuum pump on Line 3?",
      top_k: 5
    })
  });

  if (!ask.answer || ask.citations.length === 0) {
    throw new Error("Recall response missing answer or citations.");
  }

  console.log("Smoke E2E passed", {
    memory_id: save.memory.id,
    citation_ids: ask.citations.map((citation) => citation.memory_id)
  });
}

run().catch((error) => {
  console.error("Smoke E2E failed:", error);
  process.exitCode = 1;
});
