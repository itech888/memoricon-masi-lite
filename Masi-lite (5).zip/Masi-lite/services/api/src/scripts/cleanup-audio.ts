import { promises as fs } from "node:fs";
import { resolve } from "node:path";

import { getAudioStorageDir } from "../lib/audio-storage.js";

const MAX_AGE_DAYS = 7;
const MAX_AGE_MS = MAX_AGE_DAYS * 24 * 60 * 60 * 1000;

async function run() {
  const directory = getAudioStorageDir();
  const entries = await fs.readdir(directory, { withFileTypes: true });
  const cutoff = Date.now() - MAX_AGE_MS;
  let removed = 0;

  for (const entry of entries) {
    if (!entry.isFile()) {
      continue;
    }

    const absolutePath = resolve(directory, entry.name);
    const stats = await fs.stat(absolutePath);

    if (stats.mtimeMs <= cutoff) {
      await fs.unlink(absolutePath);
      removed += 1;
    }
  }

  console.log(`Audio cleanup complete. Removed: ${removed}`);
}

run().catch((error) => {
  console.error("Audio cleanup failed:", error);
  process.exitCode = 1;
});
