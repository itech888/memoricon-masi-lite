import { env } from "../config/env.js";
import { ApiError } from "../errors/api-error.js";
import { prisma } from "./prisma.js";

function ensureDatabaseConfigured() {
  if (!env.DATABASE_URL) {
    throw new ApiError(500, "CONFIG_ERROR", "DATABASE_URL is not configured on the server");
  }
}

export function getDbPool() {
  ensureDatabaseConfigured();
  return prisma;
}

export async function pingDatabase(): Promise<boolean> {
  ensureDatabaseConfigured();

  const result = await prisma.$queryRaw<Array<{ ok: number }>>`SELECT 1 AS ok`;
  return result[0]?.ok === 1;
}

export async function closeDbPool(): Promise<void> {
  await prisma.$disconnect();
}
