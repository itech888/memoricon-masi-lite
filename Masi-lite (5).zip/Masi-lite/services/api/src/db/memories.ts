import type { PrismaClient } from "@prisma/client";

import type { MemoryCard, MemoryRecord } from "../schemas/memory.js";
import { getDbPool } from "./pool.js";

type MemoryListFilters = {
  sessionId: string;
  q?: string;
  tag?: string;
  dateFrom?: Date;
  dateTo?: Date;
  limit: number;
  offset: number;
};

type MemoryListResult = {
  items: MemoryCard[];
  total: number;
  page: number;
  pageSize: number;
  pageCount: number;
  availableTags: string[];
};

type PersistedMemory = Awaited<
  ReturnType<PrismaClient["memory"]["findFirst"]>
>;
type MemoryWhere = NonNullable<
  NonNullable<Parameters<PrismaClient["memory"]["findMany"]>[0]>["where"]
>;

function memoryToRecord(memory: NonNullable<PersistedMemory>): MemoryRecord {
  return {
    id: memory.id,
    timestamp: memory.createdAt.toISOString(),
    session_id: memory.sessionId ?? "",
    transcript: memory.transcript,
    summary: memory.summary,
    tags: memory.tags ?? [],
    masi: {
      state: memory.masiState,
      intent: memory.masiIntent,
      constraint: memory.masiConstraint,
      verification: memory.masiVerification,
      outcome: memory.masiOutcome
    },
    confidence_score: Number(memory.confidenceScore),
    source_device: memory.sourceDevice,
    audio_url: memory.audioUrl,
    verification_status: memory.verificationStatus as "draft" | "verified" | "discarded",
    verification_question: memory.verificationQuestion ?? "",
    verification_response: memory.verificationResponse as
      | "confirmed"
      | "needs_clarification"
      | "insufficient_detail",
    verified_at: memory.verifiedAt?.toISOString() ?? null
  };
}

function memoryToCard(memory: NonNullable<PersistedMemory>): MemoryCard {
  return {
    id: memory.id,
    timestamp: memory.createdAt.toISOString(),
    summary: memory.summary,
    tags: memory.tags ?? [],
    confidence_score: Number(memory.confidenceScore),
    verification_status: memory.verificationStatus as "draft" | "verified" | "discarded"
  };
}

function buildSearchWhere(filters: MemoryListFilters): MemoryWhere {
  const query = filters.q?.trim();

  return {
    sessionId: filters.sessionId,
    verificationStatus: "verified",
    ...(query
      ? {
          OR: [
            { summary: { contains: query, mode: "insensitive" } },
            { transcript: { contains: query, mode: "insensitive" } },
            { masiState: { contains: query, mode: "insensitive" } },
            { masiIntent: { contains: query, mode: "insensitive" } },
            { masiConstraint: { contains: query, mode: "insensitive" } },
            { masiVerification: { contains: query, mode: "insensitive" } },
            { masiOutcome: { contains: query, mode: "insensitive" } }
          ]
        }
      : {}),
    ...(filters.tag ? { tags: { has: filters.tag } } : {}),
    ...((filters.dateFrom || filters.dateTo)
      ? {
          createdAt: {
            ...(filters.dateFrom ? { gte: filters.dateFrom } : {}),
            ...(filters.dateTo ? { lte: filters.dateTo } : {})
          }
        }
      : {})
  };
}

export async function listMemories(filters: MemoryListFilters): Promise<MemoryListResult> {
  const db = getDbPool();
  const where = buildSearchWhere(filters);
  const tagScopeWhere = buildSearchWhere({
    ...filters,
    tag: undefined
  });

  const [items, total, tagRows] = await Promise.all([
    db.memory.findMany({
      where,
      orderBy: { createdAt: "desc" },
      skip: filters.offset,
      take: filters.limit
    }),
    db.memory.count({ where }),
    db.memory.findMany({
      where: tagScopeWhere,
      select: { tags: true },
      orderBy: { createdAt: "desc" },
      take: 250
    })
  ]);

  const availableTags = Array.from(
    new Set(
      tagRows
        .flatMap((row: { tags: string[] | null }) => row.tags ?? [])
        .filter((tag: string) => tag.length > 0)
    )
  ).sort((left: string, right: string) => left.localeCompare(right));
  const page = Math.floor(filters.offset / filters.limit);
  const pageCount = total === 0 ? 0 : Math.ceil(total / filters.limit);

  return {
    items: items.map(memoryToCard),
    total,
    page,
    pageSize: filters.limit,
    pageCount,
    availableTags
  };
}

export async function getMemoryById(id: string, sessionId: string): Promise<MemoryRecord | null> {
  const db = getDbPool();

  const memory = await db.memory.findFirst({
    where: {
      id,
      sessionId,
      verificationStatus: "verified"
    }
  });

  return memory ? memoryToRecord(memory) : null;
}

export async function listVerifiedMemoriesForSession(
  sessionId: string,
  limit = 50
): Promise<MemoryRecord[]> {
  const db = getDbPool();
  const memories = await db.memory.findMany({
    where: {
      sessionId,
      verificationStatus: "verified"
    },
    orderBy: { createdAt: "desc" },
    take: limit
  });

  return memories.map(memoryToRecord);
}

export async function listVerifiedMemoriesForBackfill() {
  const db = getDbPool();
  const memories = await db.memory.findMany({
    where: {
      verificationStatus: "verified"
    },
    orderBy: { createdAt: "asc" }
  });

  return memories.map(memoryToRecord);
}
