import { randomUUID } from "node:crypto";

import type { Prisma, PrismaClient } from "@prisma/client";

import type { MemoryDraft, MemoryRecord } from "../schemas/memory.js";
import { getDbPool } from "./pool.js";

export const EMBEDDING_DIMENSION = 1536;

export type RetrievedMemory = MemoryRecord & {
  relevance_score: number;
};

type PersistedMemory = Awaited<
  ReturnType<PrismaClient["memory"]["findFirst"]>
>;

function embeddingToVectorLiteral(embedding: number[]) {
  const normalized = embedding.map((value) => {
    if (!Number.isFinite(value)) {
      throw new Error("Embedding contains a non-finite value.");
    }

    return Number(value.toFixed(8));
  });

  return `[${normalized.join(",")}]`;
}

function memoryToRecord(memory: NonNullable<PersistedMemory>): MemoryRecord {
  return {
    id: memory.id,
    timestamp: memory.createdAt.toISOString(),
    session_id: memory.sessionId ?? "",
    transcript: memory.transcript,
    summary: memory.summary,
    tags: memory.tags ?? [],
    masi: {
      state: memory.masiState,
      intent: memory.masiIntent,
      constraint: memory.masiConstraint,
      verification: memory.masiVerification,
      outcome: memory.masiOutcome
    },
    confidence_score: Number(memory.confidenceScore),
    source_device: memory.sourceDevice,
    audio_url: memory.audioUrl,
    verification_status: memory.verificationStatus as "draft" | "verified" | "discarded",
    verification_question: memory.verificationQuestion ?? "",
    verification_response: memory.verificationResponse as
      | "confirmed"
      | "needs_clarification"
      | "insufficient_detail",
    verified_at: memory.verifiedAt?.toISOString() ?? null
  };
}

export function buildMemoryEmbeddingText(draft: Pick<
  MemoryDraft,
  "summary" | "transcript" | "tags" | "masi"
>) {
  return [
    `summary: ${draft.summary}`,
    `transcript: ${draft.transcript}`,
    `tags: ${draft.tags.join(", ")}`,
    `state: ${draft.masi.state}`,
    `intent: ${draft.masi.intent}`,
    `constraint: ${draft.masi.constraint}`,
    `verification: ${draft.masi.verification}`,
    `outcome: ${draft.masi.outcome}`
  ].join("\n");
}

async function upsertMemoryEmbeddingTx(input: {
  db: PrismaClient | Prisma.TransactionClient;
  memoryId: string;
  model: string;
  embedding: number[];
}) {
  const vectorLiteral = embeddingToVectorLiteral(input.embedding);

  await input.db.$executeRawUnsafe(
    `
      INSERT INTO "memory_embeddings" (
        "id",
        "memory_id",
        "model",
        "embedding",
        "created_at",
        "updated_at"
      )
      VALUES ($1::uuid, $2::uuid, $3, $4::vector, NOW(), NOW())
      ON CONFLICT ("memory_id")
      DO UPDATE SET
        "model" = EXCLUDED."model",
        "embedding" = EXCLUDED."embedding",
        "updated_at" = NOW()
    `,
    randomUUID(),
    input.memoryId,
    input.model,
    vectorLiteral
  );
}

export async function upsertMemoryEmbedding(input: {
  memoryId: string;
  model: string;
  embedding: number[];
}) {
  const db = getDbPool();
  await upsertMemoryEmbeddingTx({ db, ...input });
}

export async function createVerifiedMemoryWithEmbedding(input: {
  draft: MemoryDraft;
  sessionId: string;
  embedding: number[];
  embeddingModel: string;
}) {
  const db = getDbPool();

  const created = await db.$transaction(async (tx: Prisma.TransactionClient) => {
    const memory = await tx.memory.create({
      data: {
        sessionId: input.sessionId,
        transcript: input.draft.transcript,
        summary: input.draft.summary,
        tags: input.draft.tags,
        masiState: input.draft.masi.state,
        masiIntent: input.draft.masi.intent,
        masiConstraint: input.draft.masi.constraint,
        masiVerification: input.draft.masi.verification,
        masiOutcome: input.draft.masi.outcome,
        confidenceScore: input.draft.confidence_score,
        sourceDevice: input.draft.source_device,
        audioUrl: input.draft.audio_url,
        verificationStatus: input.draft.verification_status,
        verificationResponse: input.draft.verification_response,
        verificationQuestion: input.draft.verification_question,
        verifiedAt: new Date()
      }
    });

    await upsertMemoryEmbeddingTx({
      db: tx,
      memoryId: memory.id,
      model: input.embeddingModel,
      embedding: input.embedding
    });

    return memory;
  });

  return memoryToRecord(created);
}

export async function searchMemoriesByEmbedding(input: {
  sessionId: string;
  embedding: number[];
  topK: number;
}) {
  const db = getDbPool();
  const vectorLiteral = embeddingToVectorLiteral(input.embedding);
  const topK = Math.max(1, Math.min(10, Math.trunc(input.topK)));

  const rows = (await db.$queryRawUnsafe(
    `
      SELECT
        m."id",
        m."created_at",
        m."session_id",
        m."transcript",
        m."summary",
        m."tags",
        m."masi_state",
        m."masi_intent",
        m."masi_constraint",
        m."masi_verification",
        m."masi_outcome",
        m."confidence_score"::float8 AS "confidence_score",
        m."source_device",
        m."audio_url",
        m."verification_status",
        m."verification_question",
        m."verification_response",
        m."verified_at",
        GREATEST(0, 1 - (e."embedding" <=> $1::vector))::float8 AS "relevance_score"
      FROM "memory_embeddings" e
      INNER JOIN "memories" m ON m."id" = e."memory_id"
      WHERE m."verification_status" = 'verified'
        AND m."session_id" = $2::uuid
      ORDER BY e."embedding" <=> $1::vector
      LIMIT $3
    `,
    vectorLiteral,
    input.sessionId,
    topK
  )) as Array<{
    id: string;
    created_at: Date;
    session_id: string | null;
    transcript: string;
    summary: string;
    tags: string[];
    masi_state: string;
    masi_intent: string;
    masi_constraint: string;
    masi_verification: string;
    masi_outcome: string;
    confidence_score: number;
    source_device: string;
    audio_url: string | null;
    verification_status: "draft" | "verified" | "discarded";
    verification_question: string | null;
    verification_response: "confirmed" | "needs_clarification" | "insufficient_detail";
    verified_at: Date | null;
    relevance_score: number;
  }>;

  return rows.map((row: (typeof rows)[number]) => ({
    id: row.id,
    timestamp: row.created_at.toISOString(),
    session_id: row.session_id ?? "",
    transcript: row.transcript,
    summary: row.summary,
    tags: row.tags ?? [],
    masi: {
      state: row.masi_state,
      intent: row.masi_intent,
      constraint: row.masi_constraint,
      verification: row.masi_verification,
      outcome: row.masi_outcome
    },
    confidence_score: Number(row.confidence_score),
    source_device: row.source_device,
    audio_url: row.audio_url,
    verification_status: row.verification_status,
    verification_question: row.verification_question ?? "",
    verification_response: row.verification_response,
    verified_at: row.verified_at?.toISOString() ?? null,
    relevance_score: row.relevance_score
  }));
}
