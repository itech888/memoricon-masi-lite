import { memoryDraftSchema } from "../schemas/memory.js";
import { Request, Router } from "express";
import multer from "multer";
import { z } from "zod";

import {
  getMemoryById,
  listMemories,
  listVerifiedMemoriesForSession
} from "../db/memories.js";
import {
  buildMemoryEmbeddingText,
  createVerifiedMemoryWithEmbedding,
  searchMemoriesByEmbedding
} from "../db/embeddings.js";
import { ApiError } from "../errors/api-error.js";
import { saveAudioBuffer } from "../lib/audio-storage.js";
import { extractMasiDraft, generateRecallAnswer } from "../lib/masi.js";
import { createEmbedding, transcribeAudio } from "../lib/openai.js";
import { env } from "../config/env.js";
import { askRateLimit, captureRateLimit } from "../middleware/rate-limit.js";

const upload = multer({
  storage: multer.memoryStorage(),
  limits: {
    fileSize: 25 * 1024 * 1024
  }
});

const captureTextBodySchema = z.object({
  input_type: z.enum(["text", "audio"]).optional(),
  text: z.string().optional(),
  source_device: z.string().default("web"),
  audio_url: z.string().url().nullable().optional().default(null)
});

const memoryListQuerySchema = z.object({
  q: z.string().optional(),
  tag: z.string().optional(),
  date_from: z.string().optional(),
  date_to: z.string().optional(),
  limit: z.coerce.number().int().positive().max(100).default(20),
  offset: z.coerce.number().int().min(0).default(0)
});

const askBodySchema = z.object({
  question: z.string().min(1),
  top_k: z.coerce.number().int().positive().max(10).default(5)
});

const sessionHeaderSchema = z.string().uuid();

const MIN_RECALL_RELEVANCE_SCORE = 0.18;
const MIN_RECALL_LEXICAL_SCORE = 0.34;
const RECALL_STOP_WORDS = new Set([
  "a",
  "about",
  "an",
  "and",
  "any",
  "are",
  "did",
  "do",
  "does",
  "for",
  "from",
  "have",
  "how",
  "i",
  "in",
  "is",
  "it",
  "me",
  "my",
  "of",
  "on",
  "or",
  "say",
  "tell",
  "that",
  "the",
  "their",
  "there",
  "they",
  "this",
  "to",
  "we",
  "what",
  "when",
  "where",
  "which",
  "who",
  "why",
  "with",
  "you",
  "your"
]);

const RECALL_TOKEN_ALIASES: Record<string, string> = {
  approvals: "approval",
  backend: "server",
  compliance: "review",
  contractor: "contractor",
  contractors: "contractor",
  decision: "decide",
  recordings: "recording",
  review: "review",
  reviews: "review",
  serverside: "server",
  summaries: "summary",
  summary: "summary",
  transcription: "transcribe",
  transcriptions: "transcribe"
};

function parseDateBoundary(value: string | undefined, boundary: "start" | "end") {
  if (!value) {
    return undefined;
  }

  const normalized = value.trim();

  if (normalized.length === 0) {
    return undefined;
  }

  const hasDateOnly = /^\d{4}-\d{2}-\d{2}$/.test(normalized);
  const candidate = hasDateOnly
    ? new Date(`${normalized}T${boundary === "end" ? "23:59:59.999" : "00:00:00.000"}Z`)
    : new Date(normalized);

  if (Number.isNaN(candidate.getTime())) {
    throw new ApiError(400, "VALIDATION_ERROR", `Invalid ${boundary === "start" ? "date_from" : "date_to"} value`);
  }

  return candidate;
}

function getSessionId(req: Request) {
  const parsed = sessionHeaderSchema.safeParse(req.header("x-masi-session-id"));

  if (!parsed.success) {
    throw new ApiError(
      400,
      "VALIDATION_ERROR",
      "Missing or invalid browser session id"
    );
  }

  return parsed.data;
}

function normalizeLexeme(value: string) {
  const cleaned = value.toLowerCase().replace(/[^a-z0-9]+/g, "");

  if (cleaned.length <= 3) {
    return RECALL_TOKEN_ALIASES[cleaned] ?? cleaned;
  }

  const singularized = cleaned.endsWith("s") ? cleaned.slice(0, -1) : cleaned;
  return RECALL_TOKEN_ALIASES[singularized] ?? singularized;
}

function tokenizeRecallQuestion(question: string) {
  return Array.from(
    new Set(
      question
        .split(/[^a-z0-9]+/i)
        .map(normalizeLexeme)
        .filter((token) => token.length >= 3 && !RECALL_STOP_WORDS.has(token))
    )
  );
}

function buildMemoryHaystack(
  memory: {
    summary: string;
    transcript: string;
    tags: string[];
    masi: {
      state: string;
      intent: string;
      constraint: string;
      verification: string;
      outcome: string;
    };
  }
) {
  return [
    memory.summary,
    memory.transcript,
    memory.tags.join(" "),
    memory.masi.state,
    memory.masi.intent,
    memory.masi.constraint,
    memory.masi.verification,
    memory.masi.outcome
  ].join(" ");
}

function tokenizeRecallText(value: string) {
  return Array.from(
    new Set(
      value
        .split(/[^a-z0-9]+/i)
        .map(normalizeLexeme)
        .filter((token) => token.length >= 3 && !RECALL_STOP_WORDS.has(token))
    )
  );
}

function getLexicalSupportScore(
  question: string,
  memory: {
    summary: string;
    transcript: string;
    tags: string[];
    masi: {
      state: string;
      intent: string;
      constraint: string;
      verification: string;
      outcome: string;
    };
  }
) {
  const questionTokens = tokenizeRecallQuestion(question);

  if (questionTokens.length === 0) {
    return 0;
  }

  const haystack = buildMemoryHaystack(memory);
  const haystackLower = haystack.toLowerCase();
  const memoryTokens = new Set(tokenizeRecallText(haystack));

  const directMatches = questionTokens.filter((token) => memoryTokens.has(token)).length;
  const partialMatches = questionTokens.filter(
    (token) =>
      !memoryTokens.has(token) &&
      haystackLower.includes(token)
  ).length;

  let score = (directMatches + partialMatches * 0.5) / questionTokens.length;

  if (directMatches >= 2) {
    score += 0.12;
  }

  if (memory.summary.toLowerCase().includes(questionTokens[0] ?? "")) {
    score += 0.08;
  }

  return Math.max(0, Math.min(1, Number(score.toFixed(4))));
}

export function createMemoryRouter() {
  const router = Router();

  router.post("/capture", captureRateLimit, upload.single("audio_file"), async (req, res, next) => {
    try {
      const sessionId = getSessionId(req);
      const parsed = captureTextBodySchema.safeParse(req.body ?? {});

      if (!parsed.success) {
        throw new ApiError(400, "VALIDATION_ERROR", "Invalid capture payload", {
          issues: parsed.error.issues
        });
      }

      const hasText = typeof parsed.data.text === "string" && parsed.data.text.trim().length > 0;
      const hasAudio = Boolean(req.file);

      if (!hasText && !hasAudio) {
        throw new ApiError(
          400,
          "VALIDATION_ERROR",
          "Either text or audio_file must be provided"
        );
      }

      let transcript = hasText ? parsed.data.text!.trim() : "";
      let audioUrl = parsed.data.audio_url;

      if (!transcript && hasAudio && req.file) {
        const storedAudio = await saveAudioBuffer({
          buffer: req.file.buffer,
          mimeType: req.file.mimetype || "audio/webm",
          fileName: req.file.originalname || "capture.webm"
        });

        audioUrl = storedAudio.audio_url;
        transcript = await transcribeAudio(
          req.file.buffer,
          req.file.mimetype || "audio/webm",
          req.file.originalname || "capture.webm"
        );
      }

      const draftMemory = await extractMasiDraft({
        transcript,
        sourceDevice: parsed.data.source_device,
        audioUrl
      });

      return res.status(200).json({
        draft_memory: {
          ...draftMemory,
          session_id: sessionId
        }
      });
    } catch (error) {
      return next(error);
    }
  });

  router.post("/memory", async (req, res, next) => {
    try {
      const sessionId = getSessionId(req);
      const parsed = memoryDraftSchema.safeParse(req.body);

      if (!parsed.success) {
        throw new ApiError(400, "VALIDATION_ERROR", "Invalid memory payload", {
          issues: parsed.error.issues
        });
      }

      if (parsed.data.verification_status !== "verified") {
        throw new ApiError(
          400,
          "VALIDATION_ERROR",
          "Only verified memories can be persisted"
        );
      }

      if (parsed.data.verification_response !== "confirmed") {
        throw new ApiError(
          400,
          "VALIDATION_ERROR",
          "Only explicitly confirmed memories can be persisted"
        );
      }

      if (parsed.data.session_id && parsed.data.session_id !== sessionId) {
        throw new ApiError(
          400,
          "VALIDATION_ERROR",
          "Draft session does not match the current browser session"
        );
      }

      const draft = {
        ...parsed.data,
        session_id: sessionId
      };

      const embedding = await createEmbedding(buildMemoryEmbeddingText(draft));
      const memory = await createVerifiedMemoryWithEmbedding({
        draft,
        sessionId,
        embedding,
        embeddingModel: env.OPENAI_EMBEDDING_MODEL
      });

      return res.status(201).json({
        memory: {
          id: memory.id,
          timestamp: memory.timestamp,
          summary: memory.summary,
          verification_status: memory.verification_status
        }
      });
    } catch (error) {
      return next(error);
    }
  });

  router.get("/memory", async (req, res, next) => {
    try {
      const sessionId = getSessionId(req);
      const parsed = memoryListQuerySchema.safeParse(req.query);

      if (!parsed.success) {
        throw new ApiError(400, "VALIDATION_ERROR", "Invalid query parameters", {
          issues: parsed.error.issues
        });
      }

      const result = await listMemories({
        sessionId,
        q: parsed.data.q,
        tag: parsed.data.tag,
        dateFrom: parseDateBoundary(parsed.data.date_from, "start"),
        dateTo: parseDateBoundary(parsed.data.date_to, "end"),
        limit: parsed.data.limit,
        offset: parsed.data.offset
      });

      return res.status(200).json({
        items: result.items.map((memory) => ({
          id: memory.id,
          timestamp: memory.timestamp,
          summary: memory.summary,
          tags: memory.tags,
          confidence_score: memory.confidence_score,
          verification_status: memory.verification_status
        })),
        total: result.total,
        page: result.page,
        page_size: result.pageSize,
        page_count: result.pageCount,
        available_tags: result.availableTags
      });
    } catch (error) {
      return next(error);
    }
  });

  router.get("/memory/:id", async (req, res, next) => {
    try {
      const sessionId = getSessionId(req);
      const idSchema = z.string().uuid();
      const id = idSchema.parse(req.params.id);

      const memory = await getMemoryById(id, sessionId);

      if (!memory) {
        throw new ApiError(404, "NOT_FOUND", "Memory not found");
      }

      return res.status(200).json({ memory });
    } catch (error) {
      return next(error);
    }
  });

  router.post("/ask", askRateLimit, async (req, res, next) => {
    try {
      const sessionId = getSessionId(req);
      const parsed = askBodySchema.safeParse(req.body);

      if (!parsed.success) {
        throw new ApiError(400, "VALIDATION_ERROR", "Invalid ask payload", {
          issues: parsed.error.issues
        });
      }

      const questionEmbedding = await createEmbedding(parsed.data.question);
      const retrieved = await searchMemoriesByEmbedding({
        sessionId,
        embedding: questionEmbedding,
        topK: parsed.data.top_k
      });
      const sessionMemories = await listVerifiedMemoriesForSession(sessionId, 50);
      const candidateMap = new Map<string, (typeof retrieved)[number]>();

      for (const memory of retrieved) {
        const lexicalScore = getLexicalSupportScore(parsed.data.question, memory);
        const supportScore = Math.max(memory.relevance_score, lexicalScore);

        if (
          memory.relevance_score >= MIN_RECALL_RELEVANCE_SCORE ||
          lexicalScore >= MIN_RECALL_LEXICAL_SCORE
        ) {
          candidateMap.set(memory.id, {
            ...memory,
            relevance_score: supportScore
          });
        }
      }

      for (const memory of sessionMemories) {
        const lexicalScore = getLexicalSupportScore(parsed.data.question, memory);

        if (lexicalScore < MIN_RECALL_LEXICAL_SCORE) {
          continue;
        }

        const existing = candidateMap.get(memory.id);

        if (existing) {
          candidateMap.set(memory.id, {
            ...existing,
            relevance_score: Math.max(existing.relevance_score, lexicalScore)
          });
          continue;
        }

        candidateMap.set(memory.id, {
          ...memory,
          relevance_score: lexicalScore
        });
      }

      const relevantMatches = Array.from(candidateMap.values())
        .sort((left, right) => right.relevance_score - left.relevance_score)
        .slice(0, parsed.data.top_k);

      if (relevantMatches.length === 0) {
        return res.status(200).json({
          answer: "I do not have verified memories that support this question.",
          citations: []
        });
      }

      const recallResponse = await generateRecallAnswer({
        question: parsed.data.question,
        memories: relevantMatches.map((memory: (typeof relevantMatches)[number]) => ({
          id: memory.id,
          timestamp: memory.timestamp,
          summary: memory.summary,
          transcript: memory.transcript,
          tags: memory.tags,
          masi: memory.masi,
          relevance_score: memory.relevance_score
        }))
      });

      const retrievedMap = new Map(
        relevantMatches.map((memory: (typeof relevantMatches)[number]) => [memory.id, memory])
      );
      const selectedCitations = recallResponse.citation_memory_ids
        .map((id) => retrievedMap.get(id))
        .filter((memory): memory is NonNullable<typeof memory> => Boolean(memory));

      const citations = selectedCitations.map((memory) => ({
          memory_id: memory.id,
          summary: memory.summary,
          timestamp: memory.timestamp,
          relevance_score: memory.relevance_score
        }));

      return res.status(200).json({
        answer: recallResponse.answer,
        citations
      });
    } catch (error) {
      return next(error);
    }
  });

  return router;
}
