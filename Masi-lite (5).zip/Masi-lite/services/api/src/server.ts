import cors from "cors";
import express from "express";
import helmet from "helmet";

import { env } from "./config/env.js";
import { pingDatabase } from "./db/pool.js";
import { toErrorPayload } from "./errors/api-error.js";
import { ensureAudioStorageDir, getAudioStorageDir, isAudioStorageReady } from "./lib/audio-storage.js";
import { getOpenAiReachability } from "./lib/openai.js";
import { requestContextMiddleware } from "./middleware/request-context.js";
import { requestLoggerMiddleware } from "./middleware/request-logger.js";
import { createMemoryRouter } from "./routes/memory-routes.js";

function resolveCorsOrigins() {
  if (env.CORS_ORIGIN.trim() === "*") {
    return "*";
  }

  return env.CORS_ORIGIN.split(",")
    .map((origin) => origin.trim())
    .filter((origin) => origin.length > 0);
}

export function createServer() {
  const app = express();
  ensureAudioStorageDir();

  app.set("trust proxy", 1);
  app.use(helmet());
  app.use(requestContextMiddleware);
  app.use(requestLoggerMiddleware);

  app.use(cors({ origin: resolveCorsOrigins() }));
  app.use(express.json({ limit: env.REQUEST_BODY_LIMIT }));
  app.use(express.urlencoded({ extended: true, limit: env.REQUEST_BODY_LIMIT }));
  app.use(
    "/media/audio",
    (_req, res, next) => {
      res.setHeader("Cross-Origin-Resource-Policy", "cross-origin");
      next();
    },
    express.static(getAudioStorageDir(), {
      setHeaders(res) {
        res.setHeader("Cross-Origin-Resource-Policy", "cross-origin");
      }
    })
  );

  app.get("/health", async (_req, res) => {
    const basePayload = {
      service: "masi-api",
      timestamp: new Date().toISOString()
    };

    const audioStorageReady = await isAudioStorageReady();
    const openAiReachability = await getOpenAiReachability();

    let databaseReady = false;
    try {
      databaseReady = Boolean(env.DATABASE_URL) && (await pingDatabase());
    } catch {
      databaseReady = false;
    }

    const ready =
      databaseReady &&
      openAiReachability.checks.chat === "up" &&
      audioStorageReady &&
      openAiReachability.checks.embeddings === "up";

    return res.status(ready ? 200 : 503).json({
      ...basePayload,
      status: ready ? "ok" : "degraded",
      readiness: {
        database: databaseReady ? "up" : env.DATABASE_URL ? "down" : "not_configured",
        openai: openAiReachability.checks.chat,
        audio_storage: audioStorageReady ? "ready" : "unavailable",
        embeddings: openAiReachability.checks.embeddings
      },
      probes: {
        openai: openAiReachability
      }
    });
  });

  app.use(createMemoryRouter());

  app.use((error: unknown, _req: express.Request, res: express.Response, _next: express.NextFunction) => {
    const { status, payload } = toErrorPayload(error);
    return res.status(status).json(payload);
  });

  return app;
}
