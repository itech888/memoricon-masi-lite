import { existsSync, mkdirSync } from "node:fs";
import { promises as fs } from "node:fs";
import { extname, resolve } from "node:path";
import { randomUUID } from "node:crypto";

import { env } from "../config/env.js";
import { ApiError } from "../errors/api-error.js";

const audioRootDir = resolve(process.cwd(), env.AUDIO_STORAGE_DIR);

function inferExtension(fileName: string, mimeType: string): string {
  const explicitExt = extname(fileName).trim();

  if (explicitExt) {
    return explicitExt.toLowerCase();
  }

  if (mimeType.includes("webm")) {
    return ".webm";
  }

  if (mimeType.includes("mpeg") || mimeType.includes("mp3")) {
    return ".mp3";
  }

  if (mimeType.includes("wav")) {
    return ".wav";
  }

  if (mimeType.includes("ogg")) {
    return ".ogg";
  }

  if (mimeType.includes("mp4") || mimeType.includes("m4a")) {
    return ".m4a";
  }

  return ".bin";
}

export function getAudioStorageDir() {
  return audioRootDir;
}

export function ensureAudioStorageDir() {
  if (!existsSync(audioRootDir)) {
    mkdirSync(audioRootDir, { recursive: true });
  }
}

export async function isAudioStorageReady() {
  try {
    ensureAudioStorageDir();
    await fs.access(audioRootDir);
    return true;
  } catch {
    return false;
  }
}

export async function saveAudioBuffer(input: {
  buffer: Buffer;
  fileName: string;
  mimeType: string;
}) {
  ensureAudioStorageDir();

  if (env.AUDIO_STORAGE_MODE !== "local") {
    throw new ApiError(500, "CONFIG_ERROR", "Unsupported audio storage mode");
  }

  const extension = inferExtension(input.fileName, input.mimeType);
  const storageName = `${randomUUID()}${extension}`;
  const absolutePath = resolve(audioRootDir, storageName);

  await fs.writeFile(absolutePath, input.buffer);

  return {
    file_name: storageName,
    absolute_path: absolutePath,
    audio_url: `${env.APP_BASE_URL.replace(/\/$/, "")}/media/audio/${storageName}`
  };
}

export async function removeAudioByUrl(audioUrl: string | null | undefined) {
  if (!audioUrl) {
    return;
  }

  try {
    const parsed = new URL(audioUrl);
    const fileName = parsed.pathname.split("/").filter(Boolean).at(-1);

    if (!fileName) {
      return;
    }

    await fs.unlink(resolve(audioRootDir, fileName));
  } catch {
    // Ignore malformed URLs or already-deleted files during cleanup paths.
  }
}
