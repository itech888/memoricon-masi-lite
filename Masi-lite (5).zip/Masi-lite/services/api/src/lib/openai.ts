import OpenAI from "openai";
import { toFile } from "openai/uploads";

import { env } from "../config/env.js";
import { ApiError } from "../errors/api-error.js";

let client: OpenAI | null = null;
let healthCache:
  | {
      checked_at: string;
      expires_at: number;
      checks: {
        chat: "up" | "down" | "not_configured";
        embeddings: "up" | "down" | "not_configured";
      };
      errors: string[];
    }
  | null = null;
let healthPromise:
  | Promise<{
      checked_at: string;
      expires_at: number;
      checks: {
        chat: "up" | "down" | "not_configured";
        embeddings: "up" | "down" | "not_configured";
      };
      errors: string[];
    }>
  | null = null;

const OPENAI_HEALTH_TTL_MS = 60_000;

function getClient() {
  if (!env.OPENAI_API_KEY) {
    throw new ApiError(
      500,
      "CONFIG_ERROR",
      "OPENAI_API_KEY is not configured on the server"
    );
  }

  if (!client) {
    client = new OpenAI({ apiKey: env.OPENAI_API_KEY });
  }

  return client;
}

export async function transcribeAudio(
  audioBuffer: Buffer,
  mimeType: string,
  fileName: string
): Promise<string> {
  const openai = getClient();

  const audioFile = await toFile(audioBuffer, fileName, { type: mimeType });

  const response = await openai.audio.transcriptions.create({
    file: audioFile,
    model: env.OPENAI_TRANSCRIBE_MODEL
  });

  const transcript = response.text?.trim();

  if (!transcript) {
    throw new ApiError(502, "TRANSCRIPTION_ERROR", "Transcription returned empty text");
  }

  return transcript;
}

export async function runJsonCompletion(
  systemPrompt: string,
  userPrompt: string
): Promise<unknown> {
  const openai = getClient();

  const completion = await openai.chat.completions.create({
    model: env.OPENAI_CHAT_MODEL,
    temperature: 0.2,
    response_format: { type: "json_object" },
    messages: [
      { role: "system", content: systemPrompt },
      { role: "user", content: userPrompt }
    ]
  });

  const content = completion.choices[0]?.message?.content;

  if (!content) {
    throw new ApiError(502, "MODEL_ERROR", "Model did not return content");
  }

  try {
    return JSON.parse(content);
  } catch {
    throw new ApiError(502, "MODEL_ERROR", "Model returned invalid JSON");
  }
}

export async function createEmbedding(input: string): Promise<number[]> {
  const openai = getClient();

  const response = await openai.embeddings.create({
    model: env.OPENAI_EMBEDDING_MODEL,
    input
  });

  const embedding = response.data[0]?.embedding;

  if (!embedding || embedding.length === 0) {
    throw new ApiError(502, "EMBEDDING_ERROR", "Embedding model returned an empty vector");
  }

  return embedding;
}

export async function getOpenAiReachability() {
  if (!env.OPENAI_API_KEY) {
    return {
      checked_at: new Date().toISOString(),
      expires_at: Date.now() + OPENAI_HEALTH_TTL_MS,
      checks: {
        chat: "not_configured" as const,
        embeddings: "not_configured" as const
      },
      errors: ["OPENAI_API_KEY is not configured."]
    };
  }

  if (healthCache && healthCache.expires_at > Date.now()) {
    return healthCache;
  }

  if (healthPromise) {
    return healthPromise;
  }

  healthPromise = (async () => {
    const openai = getClient();
    const errors: string[] = [];

    const chatStatus = await openai.chat.completions
      .create({
        model: env.OPENAI_CHAT_MODEL,
        temperature: 0,
        max_completion_tokens: 4,
        messages: [{ role: "user", content: "Respond with ok" }]
      })
      .then(() => "up" as const)
      .catch((error: { message?: string }) => {
        errors.push(`chat: ${error.message ?? "unknown error"}`);
        return "down" as const;
      });

    const embeddingStatus = await openai.embeddings
      .create({
        model: env.OPENAI_EMBEDDING_MODEL,
        input: "healthcheck"
      })
      .then((response) => {
        const embedding = response.data[0]?.embedding;

        if (!embedding || embedding.length === 0) {
          errors.push("embeddings: model returned an empty vector");
          return "down" as const;
        }

        return "up" as const;
      })
      .catch((error: { message?: string }) => {
        errors.push(`embeddings: ${error.message ?? "unknown error"}`);
        return "down" as const;
      });

    const result = {
      checked_at: new Date().toISOString(),
      expires_at: Date.now() + OPENAI_HEALTH_TTL_MS,
      checks: {
        chat: chatStatus,
        embeddings: embeddingStatus
      },
      errors
    };

    healthCache = result;
    return result;
  })();

  try {
    return await healthPromise;
  } finally {
    healthPromise = null;
  }
}
