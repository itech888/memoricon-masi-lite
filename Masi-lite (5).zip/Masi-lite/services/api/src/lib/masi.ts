import { memoryDraftSchema } from "../schemas/memory.js";
import { z } from "zod";

import { ApiError } from "../errors/api-error.js";
import { runJsonCompletion } from "./openai.js";

const extractionSystemPrompt = `You are a strict information extraction engine for MASI memories.
Extract one structured MASI memory object from the user transcript.
Return valid JSON only. Do not include markdown.

MASI field rules:
- state: the concrete situation or context. Avoid generic phrases like "decision made" or "planning" when the transcript contains better context.
- intent: what the speaker, team, or user wanted to achieve.
- constraint: limitation, dependency, rule, risk, or condition affecting the situation.
- verification: evidence already performed OR what still needs confirmation. If nothing explicit was verified, phrase it as "Needs confirmation: ...". Do not restate the outcome here.
- outcome: the decision, action taken, or result. Do not place unresolved questions here.

Quality rules:
- summary: one concise, concrete sentence.
- tags: return 2 to 4 topical tags only, lowercase kebab-case, not every noun.
- confidence_score: use lower confidence when any field is inferred or unresolved. Partial inference should usually stay at 0.55 to 0.82. Use 0.83 to 0.95 only when the transcript is very explicit.
- verification_question: ask one short confirmation question that targets the remaining ambiguity, or ask the user to confirm the interpretation if no specific ambiguity remains.

Example mapping:
- Transcript: "We agreed on a 50 thousand dollar acquisition budget for the initial campaign, but I still need to verify whether creative production costs are included."
  - verification: "Needs confirmation: whether creative production costs are included in the 50 thousand dollar budget"
  - outcome: "Initial acquisition budget was agreed"
- Transcript: "Smart glasses will capture audio locally, but verification and structured memory extraction must run on the server because the wearable power budget is limited."
  - verification: "Needs confirmation: server-side processing requirement based on wearable power budget"
  - outcome: "Audio capture stays local while verification and extraction run on the server"

Do not fabricate stakeholder consensus, proof, or maintenance actions that are not supported by the transcript.`;

const verificationSignalTokens = [
  "confirm",
  "confirmed",
  "confirmation",
  "verify",
  "verified",
  "validation",
  "validated",
  "proof",
  "evidence",
  "check",
  "checked",
  "clarify",
  "clarification",
  "pending",
  "unknown",
  "needs confirmation",
  "needs verification",
  "requires confirmation"
];

const uncertaintySignalTokens = [
  "need",
  "needs",
  "pending",
  "unclear",
  "clarify",
  "clarification",
  "verify",
  "verification",
  "confirm",
  "unknown"
];

const recallSystemPrompt = `You are a memory recall assistant.
Answer using only the supplied memories.
If evidence is insufficient, say so clearly.
Cite memory IDs you used.
Do not fabricate facts.`;

function normalizeTag(tag: string): string {
  return tag
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "");
}

function clampScore(score: number): number {
  if (Number.isNaN(score)) {
    return 0;
  }

  if (score < 0) {
    return 0;
  }

  if (score > 1) {
    return 1;
  }

  return score;
}

function normalizeSentence(value: string) {
  return value.trim().replace(/\s+/g, " ");
}

function normalizeVerification(
  verification: string,
  verificationQuestion: string
) {
  const cleaned = normalizeSentence(verification);
  const normalizedQuestion = normalizeSentence(verificationQuestion).replace(/\?+$/g, "");

  if (cleaned.length === 0) {
    if (normalizedQuestion.length > 0) {
      return `Needs confirmation: ${normalizedQuestion.charAt(0).toLowerCase()}${normalizedQuestion.slice(1)}`;
    }

    return "Needs confirmation: whether this interpretation is accurate";
  }

  const lower = cleaned.toLowerCase();

  if (verificationSignalTokens.some((token) => lower.includes(token))) {
    return cleaned;
  }

  return `Needs confirmation: ${cleaned.charAt(0).toLowerCase()}${cleaned.slice(1)}`;
}

function calibrateConfidence(input: {
  confidence_score: number;
  summary: string;
  verification_question: string;
  masi: {
    state: string;
    intent: string;
    constraint: string;
    verification: string;
    outcome: string;
  };
}) {
  let score = clampScore(input.confidence_score);
  const joinedText = [
    input.summary,
    input.masi.state,
    input.masi.intent,
    input.masi.constraint,
    input.masi.verification,
    input.masi.outcome,
    input.verification_question
  ]
    .join(" ")
    .toLowerCase();

  if (uncertaintySignalTokens.some((token) => joinedText.includes(token))) {
    score = Math.min(score, 0.82);
  }

  const terseFieldExists = [
    input.masi.state,
    input.masi.intent,
    input.masi.constraint,
    input.masi.verification,
    input.masi.outcome
  ].some((field) => normalizeSentence(field).split(/\s+/).length < 3);

  if (terseFieldExists) {
    score = Math.min(score, 0.78);
  }

  return clampScore(score);
}

export async function extractMasiDraft(input: {
  transcript: string;
  sourceDevice: string;
  audioUrl: string | null;
}) {
  const userPrompt = `Extract MASI fields from this transcript:\n\nTRANSCRIPT:\n${input.transcript}\n\nSOURCE_DEVICE:\n${input.sourceDevice}\n\nReturn JSON with this exact schema:\n{\n  "transcript": "string",\n  "summary": "string",\n  "tags": ["string"],\n  "masi": {\n    "state": "string",\n    "intent": "string",\n    "constraint": "string",\n    "verification": "string",\n    "outcome": "string"\n  },\n  "confidence_score": 0.0,\n  "source_device": "string",\n  "audio_url": null,\n  "verification_status": "draft",\n  "verification_question": "string"\n}`;

  const json = await runJsonCompletion(extractionSystemPrompt, userPrompt);
  const parsed = memoryDraftSchema.safeParse(json);

  if (!parsed.success) {
    throw new ApiError(502, "EXTRACTION_ERROR", "Invalid MASI extraction payload", {
      issues: parsed.error.issues
    });
  }

  const tags = Array.from(
    new Set(
      parsed.data.tags
        .map((tag: string) => normalizeTag(tag))
        .filter((tag: string) => tag.length > 0)
    )
  ).slice(0, 4);

  const normalizedVerification = normalizeVerification(
    parsed.data.masi.verification,
    parsed.data.verification_question
  );

  return {
    ...parsed.data,
    transcript: input.transcript,
    source_device: input.sourceDevice,
    audio_url: input.audioUrl,
    verification_status: "draft" as const,
    verification_response: "needs_clarification" as const,
    confidence_score: calibrateConfidence({
      ...parsed.data,
      masi: {
        ...parsed.data.masi,
        verification: normalizedVerification
      }
    }),
    tags,
    masi: {
      ...parsed.data.masi,
      verification: normalizedVerification
    }
  };
}

const recallSchema = z.object({
  answer: z.string().min(1),
  citation_memory_ids: z.array(z.string().uuid()).default([])
});

export type RecallContextMemory = {
  id: string;
  timestamp: string;
  summary: string;
  transcript: string;
  tags: string[];
  masi: {
    state: string;
    intent: string;
    constraint: string;
    verification: string;
    outcome: string;
  };
  relevance_score: number;
};

export async function generateRecallAnswer(input: {
  question: string;
  memories: RecallContextMemory[];
}) {
  const userPrompt = `QUESTION:\n${input.question}\n\nMEMORIES:\n${JSON.stringify(
    input.memories,
    null,
    2
  )}\n\nReturn JSON:\n{\n  "answer": "string",\n  "citation_memory_ids": ["uuid"]\n}`;

  const json = await runJsonCompletion(recallSystemPrompt, userPrompt);
  const parsed = recallSchema.safeParse(json);

  if (!parsed.success) {
    throw new ApiError(502, "RETRIEVAL_ERROR", "Invalid recall response payload", {
      issues: parsed.error.issues
    });
  }

  return parsed.data;
}
