ALTER TABLE "memories"
ADD COLUMN "session_id" UUID;

CREATE INDEX "idx_memories_session_id"
ON "memories" ("session_id");

CREATE INDEX "idx_memories_session_created_at"
ON "memories" ("session_id", "created_at");

CREATE INDEX "idx_memories_session_verification"
ON "memories" ("session_id", "verification_status");
