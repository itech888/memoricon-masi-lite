CREATE EXTENSION IF NOT EXISTS vector;

ALTER TABLE "memories"
ADD COLUMN "verification_response" TEXT NOT NULL DEFAULT 'needs_clarification';

CREATE TABLE "memory_embeddings" (
    "id" UUID NOT NULL,
    "memory_id" UUID NOT NULL,
    "model" TEXT NOT NULL,
    "embedding" vector(1536) NOT NULL,
    "created_at" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "memory_embeddings_pkey" PRIMARY KEY ("id"),
    CONSTRAINT "memory_embeddings_memory_id_key" UNIQUE ("memory_id"),
    CONSTRAINT "memory_embeddings_memory_id_fkey"
      FOREIGN KEY ("memory_id") REFERENCES "memories"("id")
      ON DELETE CASCADE ON UPDATE CASCADE
);

CREATE INDEX "idx_memory_embeddings_model" ON "memory_embeddings"("model");
CREATE INDEX "idx_memory_embeddings_embedding" ON "memory_embeddings"
USING ivfflat ("embedding" vector_cosine_ops)
WITH (lists = 100);
