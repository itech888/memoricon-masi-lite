-- CreateSchema
CREATE SCHEMA IF NOT EXISTS "public";

-- CreateTable
CREATE TABLE "memories" (
    "id" UUID NOT NULL,
    "created_at" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMPTZ(6) NOT NULL,
    "transcript" TEXT NOT NULL,
    "summary" TEXT NOT NULL,
    "tags" TEXT[],
    "masi_state" TEXT NOT NULL,
    "masi_intent" TEXT NOT NULL,
    "masi_constraint" TEXT NOT NULL,
    "masi_verification" TEXT NOT NULL,
    "masi_outcome" TEXT NOT NULL,
    "confidence_score" DECIMAL(5,4) NOT NULL,
    "source_device" TEXT NOT NULL,
    "audio_url" TEXT,
    "verification_status" TEXT NOT NULL,
    "verification_question" TEXT,
    "verified_at" TIMESTAMPTZ(6),

    CONSTRAINT "memories_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "idx_memories_created_at_desc" ON "memories"("created_at");

-- CreateIndex
CREATE INDEX "idx_memories_verification_status" ON "memories"("verification_status");

