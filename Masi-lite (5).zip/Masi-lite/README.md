# MASI-Lite Verified Memory Prototype

This repository contains the build documents for a **MASI-Lite Verified Memory Agent** prototype.

The goal is to demonstrate this full pipeline:

1. Voice/Text capture
2. Transcription
3. MASI structured extraction
4. User verification
5. Persistent storage
6. Recall with citations

## Prototype Constraints

- No login/auth (single demo user)
- Frontend: Next.js + Tailwind CSS + shadcn-style UI components
- Backend: Node.js + Express
- Database: PostgreSQL + Prisma ORM
- AI services: OpenAI Whisper (speech-to-text) + ChatGPT (MASI extraction and recall answering)
- Deploy online with a public URL

## Documents

- [Product Requirements](docs/01_PRODUCT_REQUIREMENTS.md)
- [System Architecture](docs/02_SYSTEM_ARCHITECTURE.md)
- [Database Schema (SQL)](docs/03_DATABASE_SCHEMA.sql)
- [API Contract](docs/04_API_CONTRACT.md)
- [LLM Prompt Contracts](docs/05_LLM_PROMPTS.md)
- [UI Screen Spec (Next.js)](docs/06_UI_SCREEN_SPEC.md)
- [Phased Implementation Plan (13 days)](docs/07_PHASED_IMPLEMENTATION_PLAN.md)
- [Testing and Demo Runbook](docs/08_TESTING_AND_DEMO_RUNBOOK.md)
- [Deployment Runbook](docs/09_DEPLOYMENT_RUNBOOK.md)
- [Definition of Done Checklist](docs/11_DEFINITION_OF_DONE.md)
- [Ubuntu VPS Deployment (DigitalOcean)](docs/12_UBUNTU_VPS_DEPLOYMENT.md)


## Owner Metadata

- Company: Memoricon
- Owner/Founder: Scott Dang
- Prototype Name: MASI Verified Memory Agent

## Phase 1 Bootstrap (Implemented)

The repository now includes:

- Monorepo workspaces: `apps/web`, `services/api`, `packages/shared`
- Next.js app with Tailwind + shadcn-style components
- Express API with `GET /health`
- Prisma schema and generated Prisma Client
- DB smoke-check script
- Service-level `.env.example` files

## Current Status

Core prototype flow is implemented:

- `/capture` (voice/text input)
- `/extract` (MASI preview/edit)
- `/verify` (confirm/edit/discard)
- `/timeline` (memory cards + search)
- `/memory/[id]` (full memory detail)
- `/ask` (recall with citations)

Backend endpoints are implemented:

- `POST /capture`
- `POST /memory`
- `GET /memory`
- `GET /memory/:id`
- `POST /ask`
- `GET /health`

## Local Run

1. Ensure local PostgreSQL 17 is running on `localhost:5432`.
   - Homebrew services:
     - `brew services stop postgresql@16`
     - `brew services start postgresql@17`
   - Verify:
     - `brew services list | rg 'postgresql@1[67]'`
2. Install dependencies:
   - `npm install`
3. Ensure the `vector` extension is available in your local PostgreSQL installation.
4. Generate Prisma client:
   - `npm run db:generate`
5. Configure env files:
   - `cp services/api/.env.example services/api/.env`
   - `cp apps/web/.env.example apps/web/.env.local`
   - set `OPENAI_API_KEY` in `services/api/.env`
6. Apply schema migrations:
   - `npm run db:migrate`
7. Optional embedding backfill for existing verified memories:
   - `npm run embeddings:backfill`
8. Optional DB smoke test:
   - `npm run db:smoke`
9. Seed demo memories (optional but recommended):
   - `npm run seed:demo`
10. Run API e2e smoke (requires DB + OpenAI key + running API):

- `npm run smoke:e2e`

11. Run backend:

- `npm run dev:api`

12. Run frontend:

- `npm run dev:web`

Useful URLs:

- Web: `http://localhost:3000`
- Web health page: `http://localhost:3000/health`
- API health endpoint: `http://localhost:8080/health`

## Ubuntu VPS Deploy

For your Ubuntu droplet deployment (PM2 + Nginx + TLS), use:

- [Ubuntu VPS Deployment (DigitalOcean)](docs/12_UBUNTU_VPS_DEPLOYMENT.md)

Deployment assets included in repo:

- PM2 process config: [`ops/pm2/ecosystem.config.cjs`](ops/pm2/ecosystem.config.cjs)
- Nginx reverse proxy config: [`ops/nginx/masi-lite.conf`](ops/nginx/masi-lite.conf)
- Server bootstrap script: [`ops/deploy/bootstrap-ubuntu.sh`](ops/deploy/bootstrap-ubuntu.sh)
- Update/redeploy script: [`ops/deploy/deploy.sh`](ops/deploy/deploy.sh)
- Production env templates:
  - [`ops/env/api.production.env.example`](ops/env/api.production.env.example)
  - [`ops/env/web.production.env.example`](ops/env/web.production.env.example)

## Database Commands (Root)

- `npm run db:generate` -> Generate Prisma client
- `npm run db:push` -> Push Prisma schema to DB (quick sync)
- `npm run db:migrate` -> Create/apply versioned Prisma migration (development)
- `npm run db:migrate:dev` -> Create/apply versioned Prisma migration (development)
- `npm run db:migrate:deploy` -> Apply committed migrations (production/staging)
- `npm run db:reset` -> Reset DB and reapply migrations (destructive)
- `npm run db:studio` -> Open Prisma Studio UI
- `npm run db:smoke` -> DB write/read smoke test
- `npm run db:seed` -> Seed demo memories
- `npm run embeddings:backfill` -> Generate or refresh embeddings for verified memories
- `npm run audio:cleanup` -> Remove old local audio files from the API storage directory

## Prisma P3005 (Existing DB) Fix

If you already created tables via `db push` and then run `db:migrate:deploy`, Prisma may show `P3005` because no migration history exists yet.

Baseline once:

1. Generate initial migration from current schema:
   - `cd services/api`
   - `mkdir -p prisma/migrations/0001_init`
   - `npx prisma migrate diff --from-empty --to-schema-datamodel prisma/schema.prisma --script > prisma/migrations/0001_init/migration.sql`
2. Mark it as applied:
   - `npx prisma migrate resolve --applied 0001_init`
3. Return to root and verify:
   - `cd ../..`
   - `npm run db:migrate:deploy`

## Prototype Completion Notes

- The enforced local workflow is now:
  - `Capture -> Extraction Preview -> Verification -> Timeline -> Memory Detail -> Ask/Recall`
- Drafts remain in browser storage until explicitly confirmed on the verification screen.
- Voice captures store audio locally through the API and expose a real `audio_url` for later playback.
- Recall now uses embeddings plus pgvector-backed retrieval before answer generation.
- This repo assumes a plain local PostgreSQL installation; Docker is not required.
