import { z } from "zod";

export const sessionIdSchema = z.string().uuid();

export const masiSchema = z.object({
  state: z.string().min(1),
  intent: z.string().min(1),
  constraint: z.string().min(1),
  verification: z.string().min(1),
  outcome: z.string().min(1)
});

export const verificationStatusSchema = z.enum(["draft", "verified", "discarded"]);
export const verificationResponseSchema = z.enum([
  "confirmed",
  "needs_clarification",
  "insufficient_detail"
]);

export const memoryDraftSchema = z.object({
  session_id: sessionIdSchema.optional(),
  transcript: z.string().min(1),
  summary: z.string().min(1),
  tags: z.array(z.string()).default([]),
  masi: masiSchema,
  confidence_score: z.coerce.number().min(0).max(1),
  source_device: z.string().min(1),
  audio_url: z.string().url().nullable().optional().default(null),
  verification_status: verificationStatusSchema.default("draft"),
  verification_question: z.string().optional().default(""),
  verification_response: verificationResponseSchema.default("needs_clarification")
});

export const memoryRecordSchema = memoryDraftSchema.extend({
  id: z.string().uuid(),
  timestamp: z.string().datetime(),
  session_id: sessionIdSchema,
  verified_at: z.string().datetime().nullable().optional().default(null)
});

export const memoryCardSchema = z.object({
  id: z.string().uuid(),
  timestamp: z.string().datetime(),
  summary: z.string().min(1),
  tags: z.array(z.string()).default([]),
  confidence_score: z.number().min(0).max(1),
  verification_status: verificationStatusSchema
});

export const memoryCitationSchema = z.object({
  memory_id: z.string().uuid(),
  summary: z.string(),
  timestamp: z.string().datetime(),
  relevance_score: z.number().min(0)
});

export const askResponseSchema = z.object({
  answer: z.string(),
  citations: z.array(memoryCitationSchema)
});

export const memoryListResponseSchema = z.object({
  items: z.array(memoryCardSchema),
  total: z.number().int().min(0),
  page: z.number().int().min(0),
  page_size: z.number().int().positive(),
  page_count: z.number().int().min(0),
  available_tags: z.array(z.string()).default([])
});

export type Masi = z.infer<typeof masiSchema>;
export type MemoryDraft = z.infer<typeof memoryDraftSchema>;
export type MemoryRecord = z.infer<typeof memoryRecordSchema>;
export type MemoryCard = z.infer<typeof memoryCardSchema>;
export type MemoryCitation = z.infer<typeof memoryCitationSchema>;
export type AskResponse = z.infer<typeof askResponseSchema>;
export type VerificationResponse = z.infer<typeof verificationResponseSchema>;
export type MemoryListResponse = z.infer<typeof memoryListResponseSchema>;
