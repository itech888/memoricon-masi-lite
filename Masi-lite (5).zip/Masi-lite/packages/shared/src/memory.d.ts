import { z } from "zod";
export declare const masiSchema: z.ZodObject<{
    state: z.ZodString;
    intent: z.ZodString;
    constraint: z.ZodString;
    verification: z.ZodString;
    outcome: z.ZodString;
}, "strip", z.ZodTypeAny, {
    state: string;
    intent: string;
    constraint: string;
    verification: string;
    outcome: string;
}, {
    state: string;
    intent: string;
    constraint: string;
    verification: string;
    outcome: string;
}>;
export declare const verificationStatusSchema: z.ZodEnum<["draft", "verified", "discarded"]>;
export declare const verificationResponseSchema: z.ZodEnum<["confirmed", "needs_clarification", "insufficient_detail"]>;
export declare const memoryDraftSchema: z.ZodObject<{
    transcript: z.ZodString;
    summary: z.ZodString;
    tags: z.ZodDefault<z.ZodArray<z.ZodString, "many">>;
    masi: z.ZodObject<{
        state: z.ZodString;
        intent: z.ZodString;
        constraint: z.ZodString;
        verification: z.ZodString;
        outcome: z.ZodString;
    }, "strip", z.ZodTypeAny, {
        state: string;
        intent: string;
        constraint: string;
        verification: string;
        outcome: string;
    }, {
        state: string;
        intent: string;
        constraint: string;
        verification: string;
        outcome: string;
    }>;
    confidence_score: z.ZodNumber;
    source_device: z.ZodString;
    audio_url: z.ZodDefault<z.ZodOptional<z.ZodNullable<z.ZodString>>>;
    verification_status: z.ZodDefault<z.ZodEnum<["draft", "verified", "discarded"]>>;
    verification_question: z.ZodDefault<z.ZodOptional<z.ZodString>>;
    verification_response: z.ZodDefault<z.ZodEnum<["confirmed", "needs_clarification", "insufficient_detail"]>>;
}, "strip", z.ZodTypeAny, {
    transcript: string;
    summary: string;
    tags: string[];
    masi: {
        state: string;
        intent: string;
        constraint: string;
        verification: string;
        outcome: string;
    };
    confidence_score: number;
    source_device: string;
    audio_url: string | null;
    verification_status: "draft" | "verified" | "discarded";
    verification_question: string;
    verification_response: "confirmed" | "needs_clarification" | "insufficient_detail";
}, {
    transcript: string;
    summary: string;
    masi: {
        state: string;
        intent: string;
        constraint: string;
        verification: string;
        outcome: string;
    };
    confidence_score: number;
    source_device: string;
    tags?: string[] | undefined;
    audio_url?: string | null | undefined;
    verification_status?: "draft" | "verified" | "discarded" | undefined;
    verification_question?: string | undefined;
    verification_response?: "confirmed" | "needs_clarification" | "insufficient_detail" | undefined;
}>;
export declare const memoryRecordSchema: z.ZodObject<{
    transcript: z.ZodString;
    summary: z.ZodString;
    tags: z.ZodDefault<z.ZodArray<z.ZodString, "many">>;
    masi: z.ZodObject<{
        state: z.ZodString;
        intent: z.ZodString;
        constraint: z.ZodString;
        verification: z.ZodString;
        outcome: z.ZodString;
    }, "strip", z.ZodTypeAny, {
        state: string;
        intent: string;
        constraint: string;
        verification: string;
        outcome: string;
    }, {
        state: string;
        intent: string;
        constraint: string;
        verification: string;
        outcome: string;
    }>;
    confidence_score: z.ZodNumber;
    source_device: z.ZodString;
    audio_url: z.ZodDefault<z.ZodOptional<z.ZodNullable<z.ZodString>>>;
    verification_status: z.ZodDefault<z.ZodEnum<["draft", "verified", "discarded"]>>;
    verification_question: z.ZodDefault<z.ZodOptional<z.ZodString>>;
    verification_response: z.ZodDefault<z.ZodEnum<["confirmed", "needs_clarification", "insufficient_detail"]>>;
} & {
    id: z.ZodString;
    timestamp: z.ZodString;
    verified_at: z.ZodDefault<z.ZodOptional<z.ZodNullable<z.ZodString>>>;
}, "strip", z.ZodTypeAny, {
    id: string;
    transcript: string;
    summary: string;
    tags: string[];
    masi: {
        state: string;
        intent: string;
        constraint: string;
        verification: string;
        outcome: string;
    };
    confidence_score: number;
    source_device: string;
    audio_url: string | null;
    verification_status: "draft" | "verified" | "discarded";
    verification_question: string;
    verification_response: "confirmed" | "needs_clarification" | "insufficient_detail";
    timestamp: string;
    verified_at: string | null;
}, {
    id: string;
    transcript: string;
    summary: string;
    masi: {
        state: string;
        intent: string;
        constraint: string;
        verification: string;
        outcome: string;
    };
    confidence_score: number;
    source_device: string;
    timestamp: string;
    tags?: string[] | undefined;
    audio_url?: string | null | undefined;
    verification_status?: "draft" | "verified" | "discarded" | undefined;
    verification_question?: string | undefined;
    verification_response?: "confirmed" | "needs_clarification" | "insufficient_detail" | undefined;
    verified_at?: string | null | undefined;
}>;
export declare const memoryCardSchema: z.ZodObject<{
    id: z.ZodString;
    timestamp: z.ZodString;
    summary: z.ZodString;
    tags: z.ZodDefault<z.ZodArray<z.ZodString, "many">>;
    confidence_score: z.ZodNumber;
    verification_status: z.ZodEnum<["draft", "verified", "discarded"]>;
}, "strip", z.ZodTypeAny, {
    id: string;
    summary: string;
    tags: string[];
    confidence_score: number;
    verification_status: "draft" | "verified" | "discarded";
    timestamp: string;
}, {
    id: string;
    summary: string;
    confidence_score: number;
    verification_status: "draft" | "verified" | "discarded";
    timestamp: string;
    tags?: string[] | undefined;
}>;
export declare const memoryCitationSchema: z.ZodObject<{
    memory_id: z.ZodString;
    summary: z.ZodString;
    timestamp: z.ZodString;
    relevance_score: z.ZodNumber;
}, "strip", z.ZodTypeAny, {
    summary: string;
    timestamp: string;
    memory_id: string;
    relevance_score: number;
}, {
    summary: string;
    timestamp: string;
    memory_id: string;
    relevance_score: number;
}>;
export declare const askResponseSchema: z.ZodObject<{
    answer: z.ZodString;
    citations: z.ZodArray<z.ZodObject<{
        memory_id: z.ZodString;
        summary: z.ZodString;
        timestamp: z.ZodString;
        relevance_score: z.ZodNumber;
    }, "strip", z.ZodTypeAny, {
        summary: string;
        timestamp: string;
        memory_id: string;
        relevance_score: number;
    }, {
        summary: string;
        timestamp: string;
        memory_id: string;
        relevance_score: number;
    }>, "many">;
}, "strip", z.ZodTypeAny, {
    answer: string;
    citations: {
        summary: string;
        timestamp: string;
        memory_id: string;
        relevance_score: number;
    }[];
}, {
    answer: string;
    citations: {
        summary: string;
        timestamp: string;
        memory_id: string;
        relevance_score: number;
    }[];
}>;
export declare const memoryListResponseSchema: z.ZodObject<{
    items: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        timestamp: z.ZodString;
        summary: z.ZodString;
        tags: z.ZodDefault<z.ZodArray<z.ZodString, "many">>;
        confidence_score: z.ZodNumber;
        verification_status: z.ZodEnum<["draft", "verified", "discarded"]>;
    }, "strip", z.ZodTypeAny, {
        id: string;
        summary: string;
        tags: string[];
        confidence_score: number;
        verification_status: "draft" | "verified" | "discarded";
        timestamp: string;
    }, {
        id: string;
        summary: string;
        confidence_score: number;
        verification_status: "draft" | "verified" | "discarded";
        timestamp: string;
        tags?: string[] | undefined;
    }>, "many">;
    total: z.ZodNumber;
    page: z.ZodNumber;
    page_size: z.ZodNumber;
    page_count: z.ZodNumber;
    available_tags: z.ZodDefault<z.ZodArray<z.ZodString, "many">>;
}, "strip", z.ZodTypeAny, {
    items: {
        id: string;
        summary: string;
        tags: string[];
        confidence_score: number;
        verification_status: "draft" | "verified" | "discarded";
        timestamp: string;
    }[];
    total: number;
    page: number;
    page_size: number;
    page_count: number;
    available_tags: string[];
}, {
    items: {
        id: string;
        summary: string;
        confidence_score: number;
        verification_status: "draft" | "verified" | "discarded";
        timestamp: string;
        tags?: string[] | undefined;
    }[];
    total: number;
    page: number;
    page_size: number;
    page_count: number;
    available_tags?: string[] | undefined;
}>;
export type Masi = z.infer<typeof masiSchema>;
export type MemoryDraft = z.infer<typeof memoryDraftSchema>;
export type MemoryRecord = z.infer<typeof memoryRecordSchema>;
export type MemoryCard = z.infer<typeof memoryCardSchema>;
export type MemoryCitation = z.infer<typeof memoryCitationSchema>;
export type AskResponse = z.infer<typeof askResponseSchema>;
export type VerificationResponse = z.infer<typeof verificationResponseSchema>;
export type MemoryListResponse = z.infer<typeof memoryListResponseSchema>;
