"use client";

import Link from "next/link";
import { useParams } from "next/navigation";
import { useEffect, useState } from "react";

import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { PageHeader } from "@/components/ui/page-header";
import { PageSection } from "@/components/ui/page-section";
import { PageState } from "@/components/ui/page-state";
import { PropertyItem, PropertyList } from "@/components/ui/property-list";
import { SectionCard } from "@/components/ui/section-card";
import { getMemory } from "@/lib/api";
import type { MemoryRecord } from "@/lib/types";

export default function MemoryDetailPage() {
  const params = useParams<{ id: string }>();

  const [memory, setMemory] = useState<MemoryRecord | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    async function load() {
      setLoading(true);
      setError(null);

      try {
        const payload = await getMemory(params.id);
        setMemory(payload);
      } catch (loadError) {
        setError(String(loadError));
      } finally {
        setLoading(false);
      }
    }

    if (params.id) {
      void load();
    }
  }, [params.id]);

  if (loading) {
    return (
      <main className="page-container">
        <PageState
          title="Memory Detail"
          description="Loading memory details."
        />
      </main>
    );
  }

  if (error || !memory) {
    return (
      <main className="page-container">
        <PageState
          title="Memory Detail"
          description={error ?? "Memory not found"}
          variant="error"
          action={
            <Link href="/timeline">
              <Button variant="outline">Back to Timeline</Button>
            </Link>
          }
        />
      </main>
    );
  }

  return (
    <main className="page-container">
      <PageHeader
        eyebrow="Verified Record"
        title="Memory Detail"
        meta={new Date(memory.timestamp).toLocaleString()}
        actions={<Badge variant="success">{memory.verification_status}</Badge>}
      />

      <PageSection>
        <SectionCard title={memory.summary}>
          <PropertyList>
            <PropertyItem label="Transcript" value={memory.transcript} />

            <PropertyItem label="MASI">
              <PropertyList variant="dense">
                <PropertyItem label="State" value={memory.masi.state} variant="inline" />
                <PropertyItem label="Intent" value={memory.masi.intent} variant="inline" />
                <PropertyItem label="Constraint" value={memory.masi.constraint} variant="inline" />
                <PropertyItem label="Verification" value={memory.masi.verification} variant="inline" />
                <PropertyItem label="Outcome" value={memory.masi.outcome} variant="inline" />
              </PropertyList>
            </PropertyItem>

            <PropertyItem label="Metadata">
              <div className="space-y-2">
                <PropertyList variant="dense">
                  <PropertyItem label="Source Device" value={memory.source_device} variant="inline" />
                  <PropertyItem
                    label="Confidence"
                    value={`${Math.round(memory.confidence_score * 100)}%`}
                    variant="inline"
                  />
                  <PropertyItem
                    label="Verification Status"
                    value={memory.verification_status}
                    variant="inline"
                  />
                  <PropertyItem
                    label="Verification Response"
                    value={memory.verification_response}
                    variant="inline"
                  />
                  <PropertyItem
                    label="Session ID"
                    value={memory.session_id}
                    variant="inline"
                  />
                  <PropertyItem
                    label="Verified At"
                    value={memory.verified_at ? new Date(memory.verified_at).toLocaleString() : "n/a"}
                    variant="inline"
                  />
                </PropertyList>
                <div className="flex flex-wrap gap-1">
                  {memory.tags.length > 0 ? (
                    memory.tags.map((tag: string) => (
                      <Badge key={tag}>{tag}</Badge>
                    ))
                  ) : (
                    <Badge variant="outline">no-tags</Badge>
                  )}
                </div>
              </div>
            </PropertyItem>

            {memory.audio_url ? (
              <PropertyItem label="Audio">
                <audio controls src={memory.audio_url} className="w-full" />
              </PropertyItem>
            ) : null}
          </PropertyList>
        </SectionCard>
      </PageSection>

      <PageSection>
        <Link href="/timeline">
          <Button variant="outline">Back to Timeline</Button>
        </Link>
      </PageSection>
    </main>
  );
}
