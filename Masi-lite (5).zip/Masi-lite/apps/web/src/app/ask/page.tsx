"use client";

import { Sparkles } from "lucide-react";
import { useEffect, useMemo, useState } from "react";

import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { FormField } from "@/components/ui/form-field";
import { MemoryResultCard } from "@/components/ui/memory-result-card";
import { PageHeader } from "@/components/ui/page-header";
import { PageSection } from "@/components/ui/page-section";
import { QueryChip } from "@/components/ui/query-chip";
import { SearchField } from "@/components/ui/search-field";
import { SectionCard } from "@/components/ui/section-card";
import { SourceCard } from "@/components/ui/source-card";
import { Text } from "@/components/ui/typography";
import { askMemories, getMemory, listMemories } from "@/lib/api";
import type {
  AskResponse,
  Citation,
  MemoryCard,
  MemoryRecord,
} from "@/lib/types";

type RelevantMemory = MemoryRecord & {
  relevance_score: number;
};

function formatTagLabel(tag: string) {
  return tag.replace(/-/g, " ");
}

function shortenSummary(summary: string, maxLength = 42) {
  if (summary.length <= maxLength) {
    return summary;
  }

  return `${summary.slice(0, maxLength - 1).trimEnd()}...`;
}

function buildSuggestedQueries(
  memories: MemoryCard[],
  availableTags: string[],
) {
  const suggestions = new Set<string>();

  for (const tag of availableTags.slice(0, 2)) {
    suggestions.add(`What did I record about ${formatTagLabel(tag)}?`);
    suggestions.add(
      `Summarize verified memories related to ${formatTagLabel(tag)}.`,
    );
  }

  for (const memory of memories.slice(0, 2)) {
    suggestions.add(
      `What do my memories say about "${shortenSummary(memory.summary)}"?`,
    );
  }

  suggestions.add("What are the most recent verified memories?");

  return Array.from(suggestions).slice(0, 4);
}

function formatCapturedAt(timestamp: string) {
  return new Date(timestamp).toLocaleString(undefined, {
    month: "long",
    day: "numeric",
    year: "numeric",
    hour: "numeric",
    minute: "2-digit",
  });
}

function formatSourceMeta(timestamp: string) {
  return `Captured ${new Date(timestamp).toLocaleDateString(undefined, {
    month: "short",
    day: "numeric",
    year: "numeric",
  })}`;
}

async function loadRelevantMemories(citations: Citation[]) {
  const settled = await Promise.allSettled(
    citations.map(async (citation) => {
      const memory = await getMemory(citation.memory_id);

      return {
        ...memory,
        relevance_score: citation.relevance_score,
      } satisfies RelevantMemory;
    }),
  );

  return settled.flatMap((result) =>
    result.status === "fulfilled" ? [result.value] : [],
  );
}

export default function AskPage() {
  const [question, setQuestion] = useState("");
  const [submittedQuestion, setSubmittedQuestion] = useState("");
  const [loading, setLoading] = useState(false);
  const [loadingRelevant, setLoadingRelevant] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [response, setResponse] = useState<AskResponse | null>(null);
  const [relevantMemories, setRelevantMemories] = useState<RelevantMemory[]>(
    [],
  );
  const [suggestedQueries, setSuggestedQueries] = useState<string[]>([]);

  useEffect(() => {
    async function loadSuggestions() {
      try {
        const payload = await listMemories({
          limit: 8,
          offset: 0,
        });

        setSuggestedQueries(
          buildSuggestedQueries(payload.items, payload.available_tags),
        );
      } catch {
        setSuggestedQueries([]);
      }
    }

    void loadSuggestions();
  }, []);

  const resultCountLabel = useMemo(() => {
    if (!response) {
      return "No results yet";
    }

    return `${relevantMemories.length || response.citations.length} results found`;
  }, [relevantMemories.length, response]);

  async function submitQuestion(nextQuestion = question) {
    const trimmed = nextQuestion.trim();

    if (!trimmed) {
      return;
    }

    setLoading(true);
    setLoadingRelevant(true);
    setError(null);
    setSubmittedQuestion(trimmed);
    setResponse(null);
    setRelevantMemories([]);

    try {
      const payload = await askMemories(trimmed, 5);
      setResponse(payload);
      setQuestion(trimmed);

      const detailedMemories = await loadRelevantMemories(payload.citations);
      setRelevantMemories(detailedMemories);
    } catch (askError) {
      setError(String(askError));
      setResponse(null);
      setRelevantMemories([]);
    } finally {
      setLoading(false);
      setLoadingRelevant(false);
    }
  }

  return (
    <main className="page-container max-w-none md:px-8 lg:px-10">
      <PageHeader
        eyebrow="Recall Workspace"
        title="Ask Recall"
        description="Search through your personal knowledge base with AI synthesis."
        actions={
          <Badge variant="primary">Answers cite verified memories</Badge>
        }
      />

      <PageSection>
        <SectionCard variant="outline" contentClassName="p-0">
          <form
            className="flex flex-wrap items-center gap-3 px-5 py-4"
            onSubmit={(event) => {
              event.preventDefault();
              void submitQuestion();
            }}
          >
            <div className="min-w-0 flex-1">
              <SearchField
                value={question}
                onChange={(event) => setQuestion(event.target.value)}
                placeholder="Ask MASI about your memories..."
              />
            </div>

            <Button
              type="submit"
              disabled={loading || question.trim().length === 0}
            >
              {loading ? "Searching..." : "Search"}
            </Button>
          </form>
        </SectionCard>
      </PageSection>

      {suggestedQueries.length > 0 ? (
        <PageSection stagger="one">
          <FormField
            label="Suggested Questions"
            hint="These prompts are generated from your current verified memory base."
          >
            <div className="flex flex-wrap gap-2">
              {suggestedQueries.map((prompt: string) => (
                <QueryChip
                  key={prompt}
                  variant={question === prompt ? "active" : "default"}
                  onClick={() => void submitQuestion(prompt)}
                  disabled={loading}
                >
                  {prompt}
                </QueryChip>
              ))}
            </div>
          </FormField>
        </PageSection>
      ) : null}

      {error ? (
        <Text variant="error" className="mt-4">
          {error}
        </Text>
      ) : null}

      <PageSection>
        <SectionCard
          variant="outline"
          title={
            <span className="inline-flex items-center gap-2">
              <Sparkles className="h-4 w-4 text-primary" />
              <span>AI Synthesis</span>
            </span>
          }
          description={
            response
              ? "Evidence-backed synthesis generated from verified memories."
              : "The synthesis panel stays empty until a recall query is submitted."
          }
        >
          {response ? (
            <div className="space-y-8">
              <div className="space-y-4">
                <Text as="div" variant="lead">
                  {response.answer}
                </Text>
                <Text variant="muted">
                  Synthesized from verified memories related to{" "}
                  <span className="font-semibold text-foreground">
                    {submittedQuestion}
                  </span>
                  .
                </Text>
              </div>

              <div className="border-t border-input pt-8">
                <FormField label="Citations & Sources">
                  {response.citations.length > 0 ? (
                    <div className="grid gap-3 lg:grid-cols-2">
                      {response.citations.map((citation: Citation) => (
                        <SourceCard
                          key={citation.memory_id}
                          href={`/memory/${citation.memory_id}`}
                          title={citation.summary}
                          meta={formatSourceMeta(citation.timestamp)}
                        />
                      ))}
                    </div>
                  ) : (
                    <div className="rounded-[1.25rem] border border-panel-border bg-surface-soft px-5 py-5 shadow-soft">
                      <Text variant="meta">
                        No supporting citations were found for this question.
                      </Text>
                    </div>
                  )}
                </FormField>
              </div>
            </div>
          ) : (
            <div className="space-y-3">
              <Text variant="body" className="font-medium">
                Ask a question to generate an evidence-backed synthesis.
              </Text>
              <Text variant="meta">
                MASI will retrieve relevant memories, synthesize an answer, and
                cite the memory cards used in the response.
              </Text>
            </div>
          )}
        </SectionCard>
      </PageSection>

      <PageSection stagger="three">
        <SectionCard
          variant="outline"
          title="Relevant Memories"
          headerAside={<Text variant="meta">{resultCountLabel}</Text>}
          description={
            response
              ? "Ranked verified records that directly support the generated answer."
              : "Relevant records appear here after a recall query runs."
          }
        >
          <div className="grid gap-4">
            {loadingRelevant && response ? (
              <div className="rounded-[1.25rem] border border-panel-border bg-surface-soft px-5 py-5 shadow-soft">
                <Text variant="meta">Loading relevant memories...</Text>
              </div>
            ) : null}

            {!response && !loading ? (
              <div className="rounded-[1.25rem] border border-panel-border bg-surface-soft px-5 py-5 shadow-soft">
                <Text variant="body" className="font-medium">
                  No recall has been generated yet.
                </Text>
                <Text variant="meta" className="mt-2">
                  Use the search bar to retrieve memory-backed answers from
                  verified records.
                </Text>
              </div>
            ) : null}

            {response &&
              !loadingRelevant &&
              relevantMemories.map((memory: RelevantMemory) => (
                <MemoryResultCard
                  key={memory.id}
                  href={`/memory/${memory.id}`}
                  title={memory.summary}
                  meta={formatCapturedAt(memory.timestamp)}
                  tags={memory.tags}
                  confidence={Math.round(memory.confidence_score * 100)}
                  note={
                    <Text variant="meta" className="mt-2">
                      Relevance score {memory.relevance_score.toFixed(2)}
                    </Text>
                  }
                />
              ))}

            {response && !loadingRelevant && relevantMemories.length === 0 ? (
              <div className="rounded-[1.25rem] border border-panel-border bg-surface-soft px-5 py-5 shadow-soft">
                <Text variant="body" className="font-medium">
                  No relevant memories support this answer.
                </Text>
                <Text variant="meta" className="mt-2">
                  MASI could not find verified records relevant enough to cite for
                  this question.
                </Text>
              </div>
            ) : null}
          </div>
        </SectionCard>
      </PageSection>
    </main>
  );
}
