import Link from "next/link";

import { Button } from "@/components/ui/button";
import { PageState } from "@/components/ui/page-state";

export default function NotFoundPage() {
  return (
    <main className="page-container">
      <PageState
        title="Page Not Found"
        description="The requested route is not available in this prototype."
        action={
          <Link href="/capture">
            <Button>Back to Capture</Button>
          </Link>
        }
      />
    </main>
  );
}
