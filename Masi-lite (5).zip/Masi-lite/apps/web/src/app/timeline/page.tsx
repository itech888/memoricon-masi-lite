"use client";

import Link from "next/link";
import { CalendarRange, Filter, Search, SlidersHorizontal } from "lucide-react";
import { useEffect, useMemo, useState } from "react";

import { Badge } from "@/components/ui/badge";
import { DataTablePagination } from "@/components/ui/data-table-pagination";
import { MetricBar } from "@/components/ui/metric-bar";
import { PageHeader } from "@/components/ui/page-header";
import { PageSection } from "@/components/ui/page-section";
import { SearchField } from "@/components/ui/search-field";
import { Select } from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableFooterBar,
  TableHead,
  TableHeader,
  TableRow,
  TableShell,
  TableToolbar,
} from "@/components/ui/table";
import { Text } from "@/components/ui/typography";
import { listMemories } from "@/lib/api";
import type { MemoryCard, MemoryListResponse } from "@/lib/types";
import { cn } from "@/lib/utils";

type DateRangeFilter = "all" | "7" | "30" | "90";

type TimelineStatus = {
  label: string;
  badgeVariant: "success" | "warning" | "danger";
  note: string;
};

function truncateText(value: string, maxLength: number) {
  if (value.length <= maxLength) {
    return value;
  }

  return `${value.slice(0, maxLength - 1).trimEnd()}…`;
}

function formatTagLabel(tag: string) {
  return truncateText(tag, 14);
}

function formatDateParts(timestamp: string) {
  const date = new Date(timestamp);

  return {
    day: date.toLocaleDateString(undefined, {
      month: "short",
      day: "numeric",
      year: "numeric",
    }),
    time: date.toLocaleTimeString(undefined, {
      hour: "2-digit",
      minute: "2-digit",
    }),
  };
}

function getTimelineStatus(
  status: MemoryCard["verification_status"],
): TimelineStatus {
  if (status === "verified") {
    return {
      label: "Verified",
      badgeVariant: "success",
      note: "Verified and available for recall.",
    };
  }

  if (status === "draft") {
    return {
      label: "Pending",
      badgeVariant: "warning",
      note: "Draft memory pending verification.",
    };
  }

  return {
    label: "Discarded",
    badgeVariant: "danger",
    note: "Discarded memory retained for audit only.",
  };
}

function getDateRangeParams(range: DateRangeFilter) {
  if (range === "all") {
    return {};
  }

  const now = new Date();
  const days = Number(range);
  const start = new Date(now.getTime() - days * 24 * 60 * 60 * 1000);

  return {
    date_from: start.toISOString(),
    date_to: now.toISOString(),
  };
}

function getSummaryNote(memory: MemoryCard, status: TimelineStatus) {
  if (memory.tags.length > 0) {
    return `Tagged ${memory.tags.slice(0, 2).join(", ")}. ${status.note}`;
  }

  return status.note;
}

const initialData: MemoryListResponse = {
  items: [],
  total: 0,
  page: 0,
  page_size: 8,
  page_count: 0,
  available_tags: [],
};

export default function TimelinePage() {
  const [savedId, setSavedId] = useState<string | null>(null);
  const [query, setQuery] = useState("");
  const [selectedTag, setSelectedTag] = useState("all");
  const [selectedRange, setSelectedRange] = useState<DateRangeFilter>("all");
  const [page, setPage] = useState(0);
  const [pageSize, setPageSize] = useState(8);
  const [data, setData] = useState<MemoryListResponse>(initialData);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const currentUrl = new URL(window.location.href);
    setSavedId(currentUrl.searchParams.get("saved"));
  }, []);

  useEffect(() => {
    const timer = window.setTimeout(async () => {
      setLoading(true);
      setError(null);

      try {
        const dateRange = getDateRangeParams(selectedRange);
        const payload = await listMemories({
          q: query.trim() || undefined,
          tag: selectedTag !== "all" ? selectedTag : undefined,
          ...dateRange,
          limit: pageSize,
          offset: page * pageSize,
        });

        setData(payload);
      } catch (loadError) {
        setError(String(loadError));
      } finally {
        setLoading(false);
      }
    }, 300);

    return () => window.clearTimeout(timer);
  }, [page, pageSize, query, selectedRange, selectedTag]);

  const displayStart = data.items.length > 0 ? page * pageSize + 1 : 0;
  const displayEnd =
    data.items.length > 0 ? page * pageSize + data.items.length : 0;

  const resultSummary = useMemo(() => {
    if (loading) {
      return "Loading verified memories";
    }

    if (error) {
      return "Unable to load timeline";
    }

    if (data.total === 0) {
      return "No verified memories found";
    }

    return `${data.total} verified memories in index`;
  }, [data.total, error, loading]);

  return (
    <main className="page-container max-w-none md:px-8 lg:px-10">
      <PageHeader
        variant="compact"
        eyebrow="Verified Memory Index"
        title="Memory Timeline"
        description="Browse, search, and manage your structured long-term memories."
        actions={<Badge variant="primary">Verified records only</Badge>}
      />

      <PageSection>
        <TableShell>
          <TableToolbar>
            <div className="space-y-1">
              <Text variant="eyebrow" as="div">
                Timeline Controls
              </Text>
              <Text variant="meta">{resultSummary}</Text>
            </div>

            <div className="grid w-full gap-3 lg:max-w-[58rem] lg:grid-cols-[minmax(0,1fr)_12rem_12rem]">
              <SearchField
                value={query}
                onChange={(event) => {
                  setPage(0);
                  setQuery(event.target.value);
                }}
                placeholder="Search verified memories, transcript text, or MASI fields..."
              />

              <Select
                value={selectedTag}
                onChange={(event) => {
                  setPage(0);
                  setSelectedTag(event.target.value);
                }}
                variant="outline"
                leadingIcon={<Filter className="h-4 w-4" />}
              >
                <option value="all">All tags</option>
                {data.available_tags.map((tag: string) => (
                  <option key={tag} value={tag}>
                    {tag}
                  </option>
                ))}
              </Select>

              <Select
                value={selectedRange}
                onChange={(event) => {
                  setPage(0);
                  setSelectedRange(event.target.value as DateRangeFilter);
                }}
                variant="outline"
                leadingIcon={<CalendarRange className="h-4 w-4" />}
              >
                <option value="all">All time</option>
                <option value="7">Last 7 days</option>
                <option value="30">Last 30 days</option>
                <option value="90">Last 90 days</option>
              </Select>
            </div>
          </TableToolbar>

          <TableContainer>
            <Table className="min-w-[72rem] table-fixed">
              <TableHeader>
                <TableRow className="hover:bg-surface-soft">
                  <TableHead className="w-[10rem]">Created</TableHead>
                  <TableHead>Memory Summary</TableHead>
                  <TableHead className="w-[14rem]">Tags</TableHead>
                  <TableHead className="w-[9rem]">Status</TableHead>
                  <TableHead className="w-[9rem]">Confidence</TableHead>
                </TableRow>
              </TableHeader>

              <TableBody>
                {loading ? (
                  <TableRow>
                    <TableCell colSpan={5} className="py-10">
                      <div className="flex items-center gap-3">
                        <Search className="h-4 w-4 text-muted-foreground" />
                        <Text variant="meta">
                          Loading memories from the verified memory index...
                        </Text>
                      </div>
                    </TableCell>
                  </TableRow>
                ) : null}

                {error ? (
                  <TableRow>
                    <TableCell colSpan={5} className="py-10">
                      <Text variant="error">{error}</Text>
                    </TableCell>
                  </TableRow>
                ) : null}

                {!loading && !error && data.items.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={5} className="py-12">
                      <div className="space-y-2">
                        <Text variant="body" className="font-medium">
                          No memories match this view.
                        </Text>
                        <Text variant="meta">
                          Adjust your search query or API-backed filters to
                          continue.
                        </Text>
                      </div>
                    </TableCell>
                  </TableRow>
                ) : null}

                {!loading &&
                  !error &&
                  data.items.map((memory: MemoryCard, index: number) => {
                    const status = getTimelineStatus(
                      memory.verification_status,
                    );
                    const dateParts = formatDateParts(memory.timestamp);
                    const confidence = Math.round(
                      memory.confidence_score * 100,
                    );
                    const visibleTags = memory.tags.slice(0, 2);
                    const hiddenTagCount = Math.max(0, memory.tags.length - visibleTags.length);

                    return (
                      <TableRow
                        key={memory.id}
                        className={cn(
                          index === 0 ? "border-t border-panel-border" : undefined,
                          savedId === memory.id
                            ? "bg-primary-soft/60 ring-1 ring-inset ring-highlight-ring"
                            : undefined,
                        )}
                      >
                        <TableCell>
                          <div className="space-y-1">
                            <Text variant="bodySm" className="font-semibold">
                              {dateParts.day}
                            </Text>
                            <Text variant="meta">{dateParts.time}</Text>
                          </div>
                        </TableCell>

                        <TableCell>
                          <div className="space-y-2">
                            <Link
                              href={`/memory/${memory.id}`}
                              className="inline-flex max-w-full items-center gap-2 text-base font-semibold text-foreground transition hover:text-primary"
                            >
                              <span className="block max-w-full truncate pr-4">
                                {truncateText(memory.summary, 88)}
                              </span>
                            </Link>
                            <Text variant="meta" className="truncate">
                              {truncateText(getSummaryNote(memory, status), 88)}
                            </Text>
                          </div>
                        </TableCell>

                        <TableCell>
                          <div className="flex flex-wrap gap-1.5">
                            {memory.tags.length > 0 ? (
                              visibleTags.map((tag: string) => (
                                <Badge key={tag} variant="outline">
                                  {formatTagLabel(tag)}
                                </Badge>
                              ))
                            ) : (
                              <Badge variant="soft">No tags</Badge>
                            )}
                            {hiddenTagCount > 0 ? (
                              <Badge variant="soft">{`+${hiddenTagCount}`}</Badge>
                            ) : null}
                          </div>
                        </TableCell>

                        <TableCell>
                          <Badge variant={status.badgeVariant}>
                            {status.label}
                          </Badge>
                        </TableCell>

                        <TableCell>
                          <MetricBar
                            size="compact"
                            value={confidence}
                            displayValue={`${confidence}%`}
                          />
                        </TableCell>
                      </TableRow>
                    );
                  })}
              </TableBody>
            </Table>
          </TableContainer>

          <TableFooterBar>
            <DataTablePagination
              page={page}
              pageCount={data.page_count}
              pageSize={pageSize}
              total={data.total}
              displayStart={displayStart}
              displayEnd={displayEnd}
              disabled={loading}
              onPageChange={setPage}
              onPageSizeChange={(nextPageSize) => {
                setPage(0);
                setPageSize(nextPageSize);
              }}
            />
          </TableFooterBar>
        </TableShell>
      </PageSection>
    </main>
  );
}
