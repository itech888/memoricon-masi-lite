import { redirect } from "next/navigation";

export default function ExtractRedirectPage() {
  redirect("/capture?step=extract");
}
