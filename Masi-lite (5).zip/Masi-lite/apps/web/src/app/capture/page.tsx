"use client";

import { Suspense, useEffect, useMemo, useRef, useState } from "react";
import {
  ArrowRight,
  CheckCircle2,
  Loader2,
  Mic,
  MicOff,
  PenLine,
  Sparkles,
  Trash2,
} from "lucide-react";
import { useRouter, useSearchParams } from "next/navigation";

import { AssuranceStrip } from "@/components/app/assurance-strip";
import {
  getWorkflowStepHref,
  type WorkflowStepKey,
} from "@/components/app/navigation";
import { WorkflowStepper } from "@/components/app/workflow-stepper";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ChoiceTile } from "@/components/ui/choice-tile";
import { FormField } from "@/components/ui/form-field";
import { MetricBar } from "@/components/ui/metric-bar";
import { PageHeader } from "@/components/ui/page-header";
import { PageSection } from "@/components/ui/page-section";
import { PageState } from "@/components/ui/page-state";
import { SegmentedControl } from "@/components/ui/segmented-control";
import { SectionCard } from "@/components/ui/section-card";
import { TagEditor } from "@/components/ui/tag-editor";
import { Textarea } from "@/components/ui/textarea";
import { Heading, Text } from "@/components/ui/typography";
import { captureFromAudio, captureFromText, saveMemory } from "@/lib/api";
import { useDraftMemory } from "@/lib/use-draft-memory";
import type { MemoryDraft, VerificationResponse } from "@/lib/types";

type CaptureMode = "voice" | "text";
type MasiKey = "state" | "intent" | "constraint" | "verification" | "outcome";

type AudioRecordingProfile = {
  fileName: string;
  mimeType?: string;
};

const masiFields: Array<{ key: MasiKey; label: string; rows?: number }> = [
  { key: "state", label: "State", rows: 2 },
  { key: "intent", label: "Intent", rows: 2 },
  { key: "constraint", label: "Constraint", rows: 2 },
  { key: "verification", label: "Verification", rows: 2 },
  { key: "outcome", label: "Outcome", rows: 3 },
];

const verificationOptions: Array<{
  label: string;
  value: VerificationResponse;
  description: string;
}> = [
  {
    label: "Accurate as written",
    value: "confirmed",
    description: "Everything needed for permanent save is present.",
  },
  {
    label: "Needs clarification",
    value: "needs_clarification",
    description: "The interpretation is close, but still needs edits.",
  },
  {
    label: "Not enough detail",
    value: "insufficient_detail",
    description: "This draft should not be saved yet.",
  },
];

const AUDIO_RECORDING_PROFILES: AudioRecordingProfile[] = [
  {
    mimeType: "audio/mp4;codecs=mp4a.40.2",
    fileName: "capture.m4a",
  },
  {
    mimeType: "audio/mp4",
    fileName: "capture.m4a",
  },
  {
    mimeType: "audio/webm;codecs=opus",
    fileName: "capture.webm",
  },
  {
    mimeType: "audio/webm",
    fileName: "capture.webm",
  },
  {
    mimeType: "audio/ogg;codecs=opus",
    fileName: "capture.ogg",
  },
  {
    mimeType: "audio/ogg",
    fileName: "capture.ogg",
  },
  {
    fileName: "capture.audio",
  },
];

const headerCopy: Record<
  WorkflowStepKey,
  {
    eyebrow: string;
    title: string;
    description: string;
    badge: { label: string; variant: "primary" | "soft" | "success" };
  }
> = {
  capture: {
    eyebrow: "Workflow / Step 1",
    title: "Capture Memory",
    description:
      "Start with text or voice, confirm the recording when needed, and create a local draft for MASI extraction.",
    badge: {
      label: "Local draft only until confirmation",
      variant: "primary",
    },
  },
  extract: {
    eyebrow: "Workflow / Step 2",
    title: "Refine MASI Draft",
    description:
      "Review the transcript, summary, tags, and MASI fields before moving into permanent verification.",
    badge: {
      label: "Everything here remains editable",
      variant: "soft",
    },
  },
  verify: {
    eyebrow: "Workflow / Step 3",
    title: "Verify and Save",
    description:
      "Explicit confirmation is required before the memory is stored in PostgreSQL and indexed for recall.",
    badge: {
      label: "Affirmative verification required",
      variant: "success",
    },
  },
};

function formatDuration(totalSeconds: number) {
  const minutes = Math.floor(totalSeconds / 60)
    .toString()
    .padStart(2, "0");
  const seconds = (totalSeconds % 60).toString().padStart(2, "0");
  return `${minutes}:${seconds}`;
}

function resolveWorkflowStep(value: string | null): WorkflowStepKey {
  if (value === "extract" || value === "verify") {
    return value;
  }

  return "capture";
}

function generateSessionId(draft: MemoryDraft) {
  const input = `${draft.summary}:${draft.transcript}:${draft.source_device}`;
  let hash = 0;

  for (let index = 0; index < input.length; index += 1) {
    hash = (hash * 31 + input.charCodeAt(index)) % 10000;
  }

  return `#${String(hash).padStart(4, "0")}-M`;
}

function generateDraftMemoryId(draft: MemoryDraft) {
  const input = `${draft.summary}:${draft.transcript}:${draft.source_device}`;
  let hash = 0;

  for (let index = 0; index < input.length; index += 1) {
    hash = (hash * 31 + input.charCodeAt(index)) % 10000;
  }

  return `#${String(hash).padStart(4, "0")}-V`;
}

function getCaptureMeta(draft: MemoryDraft) {
  const captureSource = draft.audio_url
    ? "Captured via voice"
    : "Captured via typed input";

  return `${captureSource} • Awaiting permanent verification`;
}

function renderFieldPreview(content: string) {
  return content.trim().length > 0 ? content : "No detail captured yet.";
}

function getSupportedRecordingProfile(): AudioRecordingProfile {
  if (typeof MediaRecorder === "undefined") {
    return AUDIO_RECORDING_PROFILES[AUDIO_RECORDING_PROFILES.length - 1];
  }

  for (const profile of AUDIO_RECORDING_PROFILES) {
    if (!profile.mimeType) {
      return profile;
    }

    if (MediaRecorder.isTypeSupported(profile.mimeType)) {
      return profile;
    }
  }

  return AUDIO_RECORDING_PROFILES[AUDIO_RECORDING_PROFILES.length - 1];
}

function resolveRecordedMimeType(
  recorder: MediaRecorder,
  profile: AudioRecordingProfile,
  chunks: Blob[],
) {
  return (
    recorder.mimeType ||
    profile.mimeType ||
    chunks.find((chunk) => chunk.type.length > 0)?.type ||
    "audio/webm"
  );
}

function CaptureWorkflow() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const requestedStep = resolveWorkflowStep(searchParams.get("step"));

  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const recordingProfileRef = useRef<AudioRecordingProfile>(
    AUDIO_RECORDING_PROFILES[0],
  );
  const streamRef = useRef<MediaStream | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  const timerRef = useRef<number | null>(null);

  const [captureMode, setCaptureMode] = useState<CaptureMode>("text");
  const [textInput, setTextInput] = useState("");
  const [audioBlob, setAudioBlob] = useState<Blob | null>(null);
  const [audioFileName, setAudioFileName] = useState<string | null>(null);
  const [audioPreviewUrl, setAudioPreviewUrl] = useState<string | null>(null);
  const [isAudioConfirmed, setIsAudioConfirmed] = useState(false);
  const [recordedSeconds, setRecordedSeconds] = useState(0);
  const [isRecording, setIsRecording] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const { draft, hydrated, clearDraft, setDraft } = useDraftMemory();

  useEffect(() => {
    return () => {
      if (timerRef.current) {
        window.clearInterval(timerRef.current);
      }

      if (streamRef.current) {
        streamRef.current.getTracks().forEach((track) => track.stop());
      }

      if (audioPreviewUrl) {
        URL.revokeObjectURL(audioPreviewUrl);
      }
    };
  }, [audioPreviewUrl]);

  useEffect(() => {
    if (hydrated && !draft && requestedStep !== "capture") {
      router.replace("/capture");
    }
  }, [draft, hydrated, requestedStep, router]);

  const currentStep: WorkflowStepKey =
    hydrated && !draft && requestedStep !== "capture"
      ? "capture"
      : requestedStep;

  const confidencePercent = useMemo(
    () => Math.round((draft?.confidence_score ?? 0) * 100),
    [draft],
  );

  const canProcess = useMemo(() => {
    if (captureMode === "text") {
      return textInput.trim().length > 0;
    }

    return Boolean(audioBlob && isAudioConfirmed);
  }, [audioBlob, captureMode, isAudioConfirmed, textInput]);

  const canConfirm = draft?.verification_response === "confirmed";

  function navigateToStep(step: WorkflowStepKey) {
    router.push(getWorkflowStepHref(step));
  }

  function resetVoiceCapture() {
    if (audioPreviewUrl) {
      URL.revokeObjectURL(audioPreviewUrl);
    }

    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop());
      streamRef.current = null;
    }

    if (timerRef.current) {
      window.clearInterval(timerRef.current);
      timerRef.current = null;
    }

    setAudioBlob(null);
    setAudioFileName(null);
    setAudioPreviewUrl(null);
    setIsAudioConfirmed(false);
    setRecordedSeconds(0);
    setIsRecording(false);
  }

  function resetLocalCaptureInputs() {
    setTextInput("");
    resetVoiceCapture();
  }

  function discardWorkflow() {
    clearDraft();
    resetLocalCaptureInputs();
    setError(null);
    router.push("/capture");
  }

  function clearExistingDraft() {
    clearDraft();
    setError(null);
    router.push("/capture");
  }

  async function startRecording() {
    setError(null);

    if (!navigator.mediaDevices?.getUserMedia) {
      setError("This browser does not support audio recording.");
      return;
    }

    try {
      resetVoiceCapture();

      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      streamRef.current = stream;

      const recordingProfile = getSupportedRecordingProfile();
      recordingProfileRef.current = recordingProfile;

      const recorder = recordingProfile.mimeType
        ? new MediaRecorder(stream, { mimeType: recordingProfile.mimeType })
        : new MediaRecorder(stream);
      chunksRef.current = [];

      recorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          chunksRef.current.push(event.data);
        }
      };

      recorder.onstop = () => {
        const mimeType = resolveRecordedMimeType(
          recorder,
          recordingProfile,
          chunksRef.current,
        );
        const blob = new Blob(chunksRef.current, { type: mimeType });
        const previewUrl = URL.createObjectURL(blob);

        setAudioBlob(blob);
        setAudioFileName(recordingProfile.fileName);
        setAudioPreviewUrl(previewUrl);

        if (timerRef.current) {
          window.clearInterval(timerRef.current);
          timerRef.current = null;
        }

        stream.getTracks().forEach((track) => track.stop());
        streamRef.current = null;
      };

      mediaRecorderRef.current = recorder;
      recorder.start();
      setIsRecording(true);
      setRecordedSeconds(0);

      timerRef.current = window.setInterval(() => {
        setRecordedSeconds((value) => value + 1);
      }, 1000);
    } catch (recordingError) {
      setError(`Unable to start recording: ${String(recordingError)}`);
    }
  }

  function stopRecording() {
    const recorder = mediaRecorderRef.current;

    if (!recorder || recorder.state !== "recording") {
      return;
    }

    recorder.stop();
    setIsRecording(false);
  }

  async function processToExtraction() {
    setError(null);
    setIsProcessing(true);

    try {
      const nextDraft =
        captureMode === "text"
          ? await captureFromText({
              text: textInput.trim(),
              source_device: "web",
            })
          : await captureFromAudio({
              blob: audioBlob!,
              fileName: audioFileName ?? undefined,
              source_device: "web",
            });

      setDraft(nextDraft);
      resetLocalCaptureInputs();
      navigateToStep("extract");
    } catch (processingError) {
      setError(String(processingError));
    } finally {
      setIsProcessing(false);
    }
  }

  function updateDraft(nextDraft: MemoryDraft) {
    setDraft(nextDraft);
  }

  function updateVerificationResponse(nextResponse: VerificationResponse) {
    if (!draft) {
      return;
    }

    updateDraft({
      ...draft,
      verification_response: nextResponse,
    });
  }

  async function confirmMemory() {
    if (!draft || !canConfirm) {
      return;
    }

    setIsSaving(true);
    setError(null);

    try {
      const payload = await saveMemory({
        ...draft,
        verification_status: "verified",
      });

      clearDraft();
      resetLocalCaptureInputs();
      router.push(`/timeline?saved=${payload.memory.id}`);
    } catch (saveError) {
      setError(String(saveError));
    } finally {
      setIsSaving(false);
    }
  }

  const hero = headerCopy[currentStep];

  return (
    <main className="page-container max-w-none md:px-8 lg:px-10">
      <PageHeader
        variant="compact"
        eyebrow={hero.eyebrow}
        title={hero.title}
        description={hero.description}
        actions={<Badge variant={hero.badge.variant}>{hero.badge.label}</Badge>}
      />

      <PageSection className="mt-5">
        <WorkflowStepper
          currentStep={currentStep}
          hasDraft={hydrated && Boolean(draft)}
          compact
        />
      </PageSection>

      {currentStep === "capture" ? (
        <PageSection className="mt-5">
          <div className="grid gap-6 xl:grid-cols-[minmax(0,1.15fr)_22rem]">
            <SectionCard
              variant="outline"
              title="Start a New Memory"
              description="Capture the raw event first. Nothing is stored permanently until the final verification step."
              headerAside={
                <SegmentedControl
                  items={[
                    { label: "Text", value: "text" },
                    { label: "Voice", value: "voice" },
                  ]}
                  value={captureMode}
                  onValueChange={(value) =>
                    setCaptureMode(value as CaptureMode)
                  }
                />
              }
              footer={
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <Text variant="meta">
                    {captureMode === "voice"
                      ? "Playback confirmation is required before the audio can move into extraction."
                      : "Typed memories go straight into a local MASI draft for extraction review."}
                  </Text>
                  <div className="flex flex-wrap items-center gap-2">
                    {captureMode === "voice" ? (
                      <Button
                        type="button"
                        variant={isRecording ? "destructive" : "outline"}
                        onClick={isRecording ? stopRecording : startRecording}
                        disabled={isProcessing}
                      >
                        {isRecording ? (
                          <MicOff className="h-4 w-4" />
                        ) : (
                          <Mic className="h-4 w-4" />
                        )}
                        {isRecording ? "Stop Recording" : "Record Audio"}
                      </Button>
                    ) : null}

                    <Button
                      type="button"
                      onClick={processToExtraction}
                      disabled={!canProcess || isProcessing}
                    >
                      {isProcessing ? (
                        <Loader2 className="h-4 w-4 animate-spin" />
                      ) : (
                        <Sparkles className="h-4 w-4" />
                      )}
                      {isProcessing ? "Creating Draft" : "Generate MASI Draft"}
                    </Button>
                  </div>
                </div>
              }
            >
              <div className="space-y-5">
                {captureMode === "text" ? (
                  <FormField
                    label="Memory input"
                    hint="Describe the event, meeting, or decision in plain language."
                    variant="dense"
                  >
                    <Textarea
                      rows={6}
                      variant="composer"
                      value={textInput}
                      onChange={(event) => setTextInput(event.target.value)}
                      placeholder="What happened, who was involved, what constraints mattered, and what outcome was reached?"
                      disabled={isProcessing}
                    />
                  </FormField>
                ) : (
                  <div className="rounded-[1.4rem] border border-panel-border bg-surface-soft px-5 py-5 shadow-soft">
                    <div className="flex flex-wrap items-center justify-between gap-3">
                      <div className="space-y-1">
                        <Text variant="eyebrow">Voice capture status</Text>
                        <Heading as="h2" variant="card">
                          {isRecording
                            ? "Recording is live"
                            : audioPreviewUrl
                              ? "Recording captured"
                              : "Ready to record"}
                        </Heading>
                      </div>
                      <Badge variant={isRecording ? "danger" : "soft"}>
                        {isRecording
                          ? `Recording ${formatDuration(recordedSeconds)}`
                          : audioPreviewUrl
                            ? `Captured ${formatDuration(recordedSeconds || 1)}`
                            : "Awaiting audio"}
                      </Badge>
                    </div>

                    <div className="mt-4 space-y-2">
                      <Text variant="bodySm">
                        {audioPreviewUrl
                          ? "Use the review panel to play back the recording and confirm it before continuing."
                          : "Start recording, speak naturally, then stop and confirm the playback once the clip is ready."}
                      </Text>
                      <Text variant="meta">
                        Source device is tagged automatically as the current web
                        session.
                      </Text>
                    </div>
                  </div>
                )}
              </div>
            </SectionCard>

            <div className="space-y-6">
              <SectionCard
                variant="soft"
                title={
                  captureMode === "voice" ? "Audio Review" : "What Happens Next"
                }
              >
                {captureMode === "voice" ? (
                  audioPreviewUrl ? (
                    <div className="space-y-4">
                      <div className="flex flex-wrap items-center gap-2">
                        <Badge variant="outline">
                          Duration {formatDuration(recordedSeconds || 1)}
                        </Badge>
                        <Badge
                          variant={isAudioConfirmed ? "success" : "warning"}
                        >
                          {isAudioConfirmed
                            ? "Recording confirmed"
                            : "Playback still needs confirmation"}
                        </Badge>
                      </div>

                      <audio
                        controls
                        src={audioPreviewUrl}
                        className="w-full"
                        playsInline
                        onError={() =>
                          setError(
                            "This recording format could not be previewed on this device. Try recording again, or switch to typed capture if the issue persists.",
                          )
                        }
                      />

                      <label className="inline-flex cursor-pointer items-start gap-3 rounded-[1.15rem] border border-input bg-surface px-4 py-3 text-sm font-medium text-foreground shadow-soft">
                        <input
                          type="checkbox"
                          checked={isAudioConfirmed}
                          onChange={(event) =>
                            setIsAudioConfirmed(event.target.checked)
                          }
                          className="mt-1"
                        />
                        <span>
                          I listened to this recording and confirm it is the
                          clip I want to process.
                        </span>
                      </label>
                    </div>
                  ) : (
                    <div className="space-y-2">
                      <Text variant="bodySm">
                        No recording has been captured yet.
                      </Text>
                      <Text variant="meta">
                        Once audio is recorded, the review controls and
                        confirmation checkbox appear here.
                      </Text>
                    </div>
                  )
                ) : (
                  <div className="space-y-4">
                    {[
                      "Create a local draft from the typed memory.",
                      "Review transcript, summary, tags, and MASI fields.",
                      "Explicitly verify before the record is stored and indexed.",
                    ].map((item: string, index: number) => (
                      <div key={item} className="flex items-start gap-3">
                        <span className="inline-flex h-8 w-8 items-center justify-center rounded-full border border-panel-border bg-surface text-sm font-semibold text-foreground">
                          {index + 1}
                        </span>
                        <Text variant="bodySm" as="div">
                          {item}
                        </Text>
                      </div>
                    ))}
                  </div>
                )}
              </SectionCard>

              <SectionCard
                variant="soft"
                title={draft ? "Local Draft in Progress" : "Capture Notes"}
                footer={
                  draft ? (
                    <div className="flex flex-wrap items-center justify-between gap-3">
                      <Text variant="meta">
                        A draft is already saved locally in this browser.
                      </Text>
                      <div className="flex flex-wrap items-center gap-2">
                        <Button
                          type="button"
                          variant="outline"
                          onClick={clearExistingDraft}
                        >
                          <Trash2 className="h-4 w-4" />
                          Clear Draft
                        </Button>
                        <Button
                          type="button"
                          onClick={() => navigateToStep("extract")}
                        >
                          Continue Draft
                        </Button>
                      </div>
                    </div>
                  ) : undefined
                }
              >
                {draft ? (
                  <div className="space-y-2">
                    <Heading as="h2" variant="card">
                      {draft.summary}
                    </Heading>
                    <Text variant="meta">{getCaptureMeta(draft)}</Text>
                  </div>
                ) : (
                  <div className="space-y-2">
                    <Text variant="bodySm">
                      Keep capture short and factual. The extraction step is
                      where structure, tags, and MASI editing happen.
                    </Text>
                    <Text variant="meta">
                      Voice uploads keep a playable audio file so the final
                      memory detail view can cite the original recording.
                    </Text>
                  </div>
                )}
              </SectionCard>
            </div>
          </div>
        </PageSection>
      ) : null}

      {currentStep !== "capture" && !hydrated ? (
        <PageSection className="mt-5">
          <PageState
            title="Loading Draft Memory"
            description="Hydrating the local draft before continuing the workflow."
          />
        </PageSection>
      ) : null}

      {currentStep === "extract" && draft ? (
        <PageSection className="mt-5">
          <div className="grid gap-6 xl:grid-cols-[minmax(0,0.95fr)_minmax(0,1.05fr)]">
            <SectionCard
              variant="outline"
              title="Transcript"
              description="Edit the transcript if the initial extraction needs cleanup."
              headerAside={
                <Badge variant="soft">Session {generateSessionId(draft)}</Badge>
              }
            >
              <Textarea
                variant="transcript"
                value={draft.transcript}
                onChange={(event) =>
                  updateDraft({ ...draft, transcript: event.target.value })
                }
              />
            </SectionCard>

            <SectionCard
              variant="outline"
              title="MASI Extraction Draft"
              description="Refine the AI interpretation before moving into the confirmation gate."
              headerAside={
                <div className="w-full min-w-[14rem] max-w-[18rem]">
                  <MetricBar
                    label="Confidence"
                    value={confidencePercent}
                    displayValue={`${confidencePercent}%`}
                    size="compact"
                  />
                </div>
              }
              footer={
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <div className="flex flex-wrap items-center gap-2">
                    <Button
                      type="button"
                      variant="soft"
                      onClick={() => navigateToStep("capture")}
                    >
                      Back to Capture
                    </Button>
                    <Button
                      type="button"
                      variant="outline"
                      onClick={discardWorkflow}
                    >
                      <Trash2 className="h-4 w-4" />
                      Discard Draft
                    </Button>
                  </div>

                  <Button
                    type="button"
                    onClick={() => navigateToStep("verify")}
                  >
                    <ArrowRight className="h-4 w-4" />
                    Continue to Verification
                  </Button>
                </div>
              }
            >
              <div className="space-y-7">
                <FormField label="Summary" variant="section">
                  <Textarea
                    rows={3}
                    value={draft.summary}
                    onChange={(event) =>
                      updateDraft({ ...draft, summary: event.target.value })
                    }
                  />
                </FormField>

                <FormField label="Tags" variant="section">
                  <TagEditor
                    tags={draft.tags}
                    onChange={(nextTags) =>
                      updateDraft({
                        ...draft,
                        tags: nextTags,
                      })
                    }
                    placeholder="Add tag..."
                  />
                </FormField>

                <div className="grid gap-5 md:grid-cols-2">
                  {masiFields.map((field: (typeof masiFields)[number]) => (
                    <FormField
                      key={field.key}
                      label={field.label}
                      className={
                        field.key === "outcome" ? "md:col-span-2" : undefined
                      }
                    >
                      <Textarea
                        rows={field.rows}
                        value={draft.masi[field.key]}
                        onChange={(event) =>
                          updateDraft({
                            ...draft,
                            masi: {
                              ...draft.masi,
                              [field.key]: event.target.value,
                            },
                          })
                        }
                      />
                    </FormField>
                  ))}
                </div>
              </div>
            </SectionCard>
          </div>
        </PageSection>
      ) : null}

      {currentStep === "verify" && draft ? (
        <>
          <PageSection className="mt-5">
            <SectionCard variant="outline">
              <div className="grid gap-6 lg:grid-cols-[minmax(0,1fr)_18rem] lg:items-center">
                <div className="space-y-3">
                  <Text variant="eyebrow">
                    Memory ID: {generateDraftMemoryId(draft)}
                  </Text>
                  <Heading as="h2" variant="section">
                    Review Memory Before Save
                  </Heading>
                  <Text variant="subtitle">{getCaptureMeta(draft)}</Text>
                </div>

                <MetricBar
                  label="Confidence Score"
                  value={confidencePercent}
                  displayValue={`${confidencePercent}%`}
                />
              </div>
            </SectionCard>
          </PageSection>

          <PageSection className="mt-5">
            <SectionCard
              variant="outline"
              title="Verification Gate"
              description="This is the only step that can persist the memory. Edit the draft if the interpretation is not accurate enough yet."
              footer={
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <div className="flex flex-wrap items-center gap-2">
                    <Button
                      type="button"
                      onClick={confirmMemory}
                      disabled={isSaving || !canConfirm}
                    >
                      <CheckCircle2 className="h-4 w-4" />
                      {isSaving ? "Saving Memory" : "Confirm Memory"}
                    </Button>
                    <Button
                      type="button"
                      variant="soft"
                      onClick={() => navigateToStep("extract")}
                    >
                      <PenLine className="h-4 w-4" />
                      Edit Draft
                    </Button>
                  </div>

                  <Button
                    type="button"
                    variant="destructiveOutline"
                    onClick={discardWorkflow}
                  >
                    <Trash2 className="h-4 w-4" />
                    Discard
                  </Button>
                </div>
              }
            >
              <div className="space-y-8">
                <FormField label="Summary" variant="section">
                  <div className="rounded-[1.35rem] border border-input bg-surface-soft px-5 py-5 shadow-soft">
                    <Text as="div" variant="lead">
                      {draft.summary}
                    </Text>
                  </div>
                </FormField>

                <FormField label="MASI Snapshot" variant="section">
                  <div className="grid gap-4 md:grid-cols-2">
                    {masiFields.map((field: (typeof masiFields)[number]) => (
                      <div
                        key={field.key}
                        className="rounded-[1.25rem] border border-panel-border bg-surface px-4 py-4 shadow-soft"
                      >
                        <Text variant="eyebrow" as="div">
                          {field.label}
                        </Text>
                        <Text
                          as="div"
                          variant="bodySm"
                          className="mt-2 leading-7"
                        >
                          {renderFieldPreview(draft.masi[field.key])}
                        </Text>
                      </div>
                    ))}
                  </div>
                </FormField>

                <FormField label="Verification Question" variant="section">
                  <div className="space-y-6">
                    <div className="rounded-[1.35rem] border border-input bg-surface-soft px-5 py-5 shadow-soft">
                      <Text as="div" variant="lead">
                        {draft.verification_question ||
                          "Is this memory accurate and complete enough to store permanently?"}
                      </Text>
                    </div>

                    <div className="grid gap-3 lg:grid-cols-3">
                      {verificationOptions.map(
                        (option: (typeof verificationOptions)[number]) => (
                          <div key={option.value} className="space-y-2">
                            <ChoiceTile
                              variant={
                                draft.verification_response === option.value
                                  ? "selected"
                                  : "default"
                              }
                              onClick={() =>
                                updateVerificationResponse(option.value)
                              }
                            >
                              {option.label}
                            </ChoiceTile>
                            <Text variant="meta">{option.description}</Text>
                          </div>
                        ),
                      )}
                    </div>

                    {draft.verification_response ? (
                      <Text variant="meta">
                        Selected response:{" "}
                        <span className="font-semibold text-foreground">
                          {
                            verificationOptions.find(
                              (option: (typeof verificationOptions)[number]) =>
                                option.value === draft.verification_response,
                            )?.label
                          }
                        </span>
                      </Text>
                    ) : null}

                    {!canConfirm ? (
                      <Text variant="meta">
                        Permanent save stays disabled until you explicitly
                        confirm that the draft is accurate as written.
                      </Text>
                    ) : null}
                  </div>
                </FormField>
              </div>
            </SectionCard>
          </PageSection>

          {/* <AssuranceStrip /> */}
        </>
      ) : null}

      {error ? (
        <Text variant="error" className="mt-4">
          {error}
        </Text>
      ) : null}
    </main>
  );
}

function CapturePageFallback() {
  return (
    <main className="page-container max-w-none md:px-8 lg:px-10">
      <PageHeader
        variant="compact"
        eyebrow="Workflow"
        title="Loading Capture Workflow"
        description="Preparing the draft workflow and local browser state."
      />
      <PageSection className="mt-5">
        <PageState
          title="Loading Workflow"
          description="Preparing capture, extraction, and verification in one workspace."
        />
      </PageSection>
    </main>
  );
}

export default function CapturePage() {
  return (
    <Suspense fallback={<CapturePageFallback />}>
      <CaptureWorkflow />
    </Suspense>
  );
}
