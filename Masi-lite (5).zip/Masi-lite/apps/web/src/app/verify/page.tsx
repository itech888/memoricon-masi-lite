import { redirect } from "next/navigation";

export default function VerifyRedirectPage() {
  redirect("/capture?step=verify");
}
