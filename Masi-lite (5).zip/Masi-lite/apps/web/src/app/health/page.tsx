"use client";

import { useEffect, useState } from "react";

import { Badge } from "@/components/ui/badge";
import { CodeBlock } from "@/components/ui/code-block";
import { PageHeader } from "@/components/ui/page-header";
import { PageSection } from "@/components/ui/page-section";
import { SectionCard } from "@/components/ui/section-card";

type HealthState = {
  ok: boolean;
  status: number;
  payload: unknown;
};

const initialHealthState: HealthState = {
  ok: false,
  status: 0,
  payload: "Loading health status...",
};

export default function HealthPage() {
  const [health, setHealth] = useState<HealthState>(initialHealthState);

  useEffect(() => {
    const baseUrl =
      process.env.NEXT_PUBLIC_API_BASE_URL ?? "http://localhost:8080";

    async function loadHealth() {
      try {
        const response = await fetch(`${baseUrl}/health`, { cache: "no-store" });

        if (!response.ok) {
          setHealth({
            ok: false,
            status: response.status,
            payload: await response.text(),
          });
          return;
        }

        setHealth({
          ok: true,
          status: response.status,
          payload: await response.json(),
        });
      } catch (error) {
        setHealth({
          ok: false,
          status: 0,
          payload: String(error),
        });
      }
    }

    void loadHealth();
  }, []);

  return (
    <main className="page-container">
      <PageHeader
        eyebrow="System Readiness"
        title="Health Check"
        meta="Frontend route: /health"
        actions={
          <Badge variant={health.ok ? "success" : "danger"}>
            {health.ok ? "Healthy" : "Attention Needed"}
          </Badge>
        }
      />

      <PageSection>
        <SectionCard title="API Status">
          <CodeBlock variant="soft">{JSON.stringify(health, null, 2)}</CodeBlock>
        </SectionCard>
      </PageSection>
    </main>
  );
}
