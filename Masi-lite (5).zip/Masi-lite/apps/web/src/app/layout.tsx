import type { Metadata } from "next";
import { cookies } from "next/headers";

import { AppSidebar } from "@/components/app/app-sidebar";
import { MobileSidebar } from "@/components/app/mobile-sidebar";
import { ThemeProvider } from "@/components/app/theme-provider";
import { THEME_COOKIE_KEY, THEME_STORAGE_KEY } from "@/lib/theme";

import "./globals.css";

export const metadata: Metadata = {
  title: "MASI-Lite",
  description: "MASI Verified Memory Prototype",
};

export default async function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  const cookieStore = await cookies();
  const cookieTheme = cookieStore.get(THEME_COOKIE_KEY)?.value;
  const serverTheme =
    cookieTheme === "dark" || cookieTheme === "light" ? cookieTheme : null;

  return (
    <html
      lang="en"
      suppressHydrationWarning
      className={serverTheme === "dark" ? "dark" : undefined}
      style={serverTheme ? { colorScheme: serverTheme } : undefined}
    >
      <head>
        <script
          dangerouslySetInnerHTML={{
            __html: `(() => {
              try {
                const stored = window.localStorage.getItem("${THEME_STORAGE_KEY}");
                const resolved = stored === "light" || stored === "dark"
                  ? stored
                  : (window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light");
                document.documentElement.classList.toggle("dark", resolved === "dark");
                document.documentElement.style.colorScheme = resolved;
                document.cookie = "${THEME_COOKIE_KEY}=" + resolved + "; path=/; max-age=31536000; samesite=lax";
              } catch {}
            })();`,
          }}
        />
      </head>
      <body
        suppressHydrationWarning
        className="min-h-screen bg-background text-foreground"
      >
        <ThemeProvider initialTheme={serverTheme ?? undefined}>
          <div className="min-h-screen">
            <AppSidebar />

            <div className="relative min-w-0 md:pl-[18.75rem]">
              <MobileSidebar />

              <div className="relative min-h-screen">
                {children}
              </div>
            </div>
          </div>
        </ThemeProvider>
      </body>
    </html>
  );
}
