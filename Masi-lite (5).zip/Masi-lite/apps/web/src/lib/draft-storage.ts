import type { MemoryDraft } from "./types";
import { getOrCreateBrowserSessionId } from "./browser-session";

const DRAFT_KEY = "masi_lite_draft_memory";

function normalizeDraft(draft: MemoryDraft) {
  return {
    ...draft,
    session_id: draft.session_id ?? getOrCreateBrowserSessionId() ?? undefined,
    verification_response: draft.verification_response ?? "needs_clarification",
    verification_question: draft.verification_question ?? ""
  } satisfies MemoryDraft;
}

export function loadDraftMemory(): MemoryDraft | null {
  if (typeof window === "undefined") {
    return null;
  }

  const value = window.localStorage.getItem(DRAFT_KEY);

  if (!value) {
    return null;
  }

  try {
    return normalizeDraft(JSON.parse(value) as MemoryDraft);
  } catch {
    return null;
  }
}

export function saveDraftMemory(draft: MemoryDraft): void {
  if (typeof window === "undefined") {
    return;
  }

  window.localStorage.setItem(DRAFT_KEY, JSON.stringify(normalizeDraft(draft)));
}

export function clearDraftMemory(): void {
  if (typeof window === "undefined") {
    return;
  }

  window.localStorage.removeItem(DRAFT_KEY);
}
