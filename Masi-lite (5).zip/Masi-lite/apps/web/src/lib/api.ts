import type { AskResponse, MemoryDraft, MemoryListResponse, MemoryRecord } from "./types";
import { getOrCreateBrowserSessionId } from "./browser-session";

const API_BASE_URL =
  process.env.NEXT_PUBLIC_API_BASE_URL?.replace(/\/$/, "") ?? "http://localhost:8080";

type ApiErrorPayload = {
  error?: {
    code?: string;
    message?: string;
  };
};

async function apiRequest<T>(path: string, init?: RequestInit): Promise<T> {
  const sessionId = getOrCreateBrowserSessionId();
  const response = await fetch(`${API_BASE_URL}${path}`, {
    ...init,
    headers: {
      ...(sessionId ? { "X-MASI-Session-ID": sessionId } : {}),
      ...(init?.body instanceof FormData ? {} : { "Content-Type": "application/json" }),
      ...(init?.headers ?? {})
    },
    cache: "no-store"
  });

  if (!response.ok) {
    let message = `Request failed with status ${response.status}`;

    try {
      const payload = (await response.json()) as ApiErrorPayload;
      message = payload.error?.message ?? message;
    } catch {
      // Ignore parse errors and keep default message.
    }

    throw new Error(message);
  }

  return response.json() as Promise<T>;
}

export async function captureFromText(input: {
  text: string;
  source_device?: string;
}): Promise<MemoryDraft> {
  const payload = await apiRequest<{ draft_memory: MemoryDraft }>("/capture", {
    method: "POST",
    body: JSON.stringify({
      input_type: "text",
      text: input.text,
      source_device: input.source_device ?? "web"
    })
  });

  return payload.draft_memory;
}

export async function captureFromAudio(input: {
  blob: Blob;
  fileName?: string;
  source_device?: string;
}): Promise<MemoryDraft> {
  const formData = new FormData();
  formData.append("input_type", "audio");
  formData.append("source_device", input.source_device ?? "web");
  formData.append("audio_file", input.blob, input.fileName ?? "capture.webm");

  const payload = await apiRequest<{ draft_memory: MemoryDraft }>("/capture", {
    method: "POST",
    body: formData
  });

  return payload.draft_memory;
}

export async function saveMemory(memory: MemoryDraft) {
  return apiRequest<{ memory: { id: string; timestamp: string; summary: string } }>("/memory", {
    method: "POST",
    body: JSON.stringify(memory)
  });
}

export async function listMemories(input?: {
  q?: string;
  tag?: string;
  date_from?: string;
  date_to?: string;
  limit?: number;
  offset?: number;
}): Promise<MemoryListResponse> {
  const params = new URLSearchParams();

  if (input?.q) {
    params.set("q", input.q);
  }

  if (input?.tag) {
    params.set("tag", input.tag);
  }

  if (input?.date_from) {
    params.set("date_from", input.date_from);
  }

  if (input?.date_to) {
    params.set("date_to", input.date_to);
  }

  params.set("limit", String(input?.limit ?? 20));
  params.set("offset", String(input?.offset ?? 0));

  return apiRequest<MemoryListResponse>(`/memory?${params.toString()}`);
}

export async function getMemory(id: string): Promise<MemoryRecord> {
  const payload = await apiRequest<{ memory: MemoryRecord }>(`/memory/${id}`);
  return payload.memory;
}

export async function askMemories(question: string, topK = 5): Promise<AskResponse> {
  return apiRequest<AskResponse>("/ask", {
    method: "POST",
    body: JSON.stringify({
      question,
      top_k: topK
    })
  });
}
