"use client";

import { useCallback, useEffect, useState } from "react";

import {
  clearDraftMemory,
  loadDraftMemory,
  saveDraftMemory
} from "./draft-storage";
import type { MemoryDraft } from "./types";

export function useDraftMemory() {
  const [draft, setDraftState] = useState<MemoryDraft | null>(null);
  const [hydrated, setHydrated] = useState(false);

  useEffect(() => {
    setDraftState(loadDraftMemory());
    setHydrated(true);
  }, []);

  const setDraft = useCallback((nextDraft: MemoryDraft | null) => {
    setDraftState(nextDraft);

    if (nextDraft) {
      saveDraftMemory(nextDraft);
      return;
    }

    clearDraftMemory();
  }, []);

  const clearDraft = useCallback(() => {
    setDraftState(null);
    clearDraftMemory();
  }, []);

  return {
    draft,
    hydrated,
    setDraft,
    clearDraft
  };
}
