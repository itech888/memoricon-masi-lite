"use client";

import { SidebarNavContent } from "@/components/app/sidebar-nav-content";

export function AppSidebar() {
  return (
    <aside className="sidebar-shell fixed inset-y-0 left-0 z-30 hidden w-[18.75rem] overflow-hidden text-sidebar-foreground md:flex">
      <SidebarNavContent />
    </aside>
  );
}
