import * as React from "react";

import { StatusPill } from "@/components/ui/status-pill";
import { Text } from "@/components/ui/typography";

export interface WorkspaceBarProps {
  path: React.ReactNode;
  statusLabel?: React.ReactNode;
}

export function WorkspaceBar({ path }: WorkspaceBarProps) {
  return (
    <div className="px-5 pt-5 md:px-8 md:pt-6 lg:px-12">
      <div className="workspace-bar-surface flex flex-wrap items-center justify-between gap-3">
        {typeof path === "string" || typeof path === "number" ? (
          <Text variant="subtitle">{path}</Text>
        ) : (
          path
        )}
      </div>
    </div>
  );
}
