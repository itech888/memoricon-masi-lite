"use client";

import Link from "next/link";
import { Menu, X } from "lucide-react";
import { useEffect, useState } from "react";

import { SidebarNavContent } from "@/components/app/sidebar-nav-content";
import { ThemeToggle } from "@/components/app/theme-toggle";
import { Button } from "@/components/ui/button";
import { Heading, Text } from "@/components/ui/typography";
import { cn } from "@/lib/utils";

export function MobileSidebar() {
  const [open, setOpen] = useState(false);

  useEffect(() => {
    if (!open) {
      return;
    }

    const previousOverflow = document.body.style.overflow;

    function handleEscape(event: KeyboardEvent) {
      if (event.key === "Escape") {
        setOpen(false);
      }
    }

    document.body.style.overflow = "hidden";
    window.addEventListener("keydown", handleEscape);

    return () => {
      document.body.style.overflow = previousOverflow;
      window.removeEventListener("keydown", handleEscape);
    };
  }, [open]);

    return (
    <>
      <header className="sticky top-0 z-30 px-4 py-4 md:hidden">
        <nav className="workspace-bar-surface flex items-center justify-between gap-3">
          <Link href="/capture" className="group min-w-0">
            <Heading as="h3" variant="card">
              MASI-Lite
            </Heading>
            <Text as="span" variant="meta">
              Verified Memory Agent
            </Text>
          </Link>

          <div className="flex items-center gap-2">
            <ThemeToggle compact />
            <Button
              type="button"
              variant="soft"
              size="icon"
              onClick={() => setOpen(true)}
              aria-label="Open navigation menu"
            >
              <Menu className="h-5 w-5" />
            </Button>
          </div>
        </nav>
      </header>

      <div
        className={cn(
          "fixed inset-0 z-40 md:hidden",
          open ? "pointer-events-auto" : "pointer-events-none"
        )}
        aria-hidden={!open}
      >
        <button
          type="button"
          className={cn(
            "absolute inset-0 bg-foreground/20 backdrop-blur-sm transition-opacity",
            open ? "opacity-100" : "opacity-0"
          )}
          onClick={() => setOpen(false)}
          aria-label="Close navigation menu"
        />

        <aside
          className={cn(
            "sidebar-shell absolute left-0 top-0 h-full w-[19rem] overflow-hidden text-sidebar-foreground shadow-card transition-transform",
            open ? "translate-x-0" : "-translate-x-full"
          )}
        >
          <div className="flex items-center justify-between px-5 pt-5">
            <div>
              <Text variant="eyebrow" as="div">
                Workspace Menu
              </Text>
            </div>
            <Button
              type="button"
              variant="soft"
              size="icon"
              onClick={() => setOpen(false)}
              aria-label="Close navigation menu"
            >
              <X className="h-5 w-5" />
            </Button>
          </div>
          <SidebarNavContent onNavigate={() => setOpen(false)} />
        </aside>
      </div>
    </>
  );
}
