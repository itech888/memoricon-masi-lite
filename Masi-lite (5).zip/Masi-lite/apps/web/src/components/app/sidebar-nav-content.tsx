"use client";

import Link from "next/link";
import { ChevronRight, Workflow } from "lucide-react";
import { usePathname } from "next/navigation";

import {
  appNavItems,
  isPrimaryNavItemActive,
} from "@/components/app/navigation";
import { ThemeToggle } from "@/components/app/theme-toggle";
import { Heading, Text } from "@/components/ui/typography";
import { cn } from "@/lib/utils";

export interface SidebarNavContentProps {
  onNavigate?: () => void;
}

export function SidebarNavContent({ onNavigate }: SidebarNavContentProps) {
  const pathname = usePathname();

  return (
    <div className="flex h-full min-h-0 flex-1 flex-col px-5 py-5">
      <div className="flex min-h-0 flex-1 flex-col gap-6 overflow-y-auto pr-1">
        <Link
          href="/capture"
          className="rounded-[1.4rem] border border-sidebar-border bg-sidebar-surface px-4 py-4 shadow-soft"
          onClick={onNavigate}
        >
          <div className="flex items-center gap-4">
            <span className="inline-flex h-12 w-12 items-center justify-center rounded-[1rem] border border-primary/15 bg-primary-soft text-primary shadow-soft">
              <Workflow className="h-5 w-5" />
            </span>

            <span className="min-w-0 flex-1 space-y-0.5">
              <Text variant="eyebrow" as="span">
                Memoricon
              </Text>
              <Heading as="h3" variant="card">
                MASILITE
              </Heading>
            </span>
          </div>
        </Link>

        <div className="space-y-3">
          <Text variant="eyebrow" as="div">
            Workspace
          </Text>

          <nav className="space-y-2.5">
            {appNavItems.map((item: (typeof appNavItems)[number]) => {
              const isActive = isPrimaryNavItemActive(pathname, item.href);

              return (
                <Link
                  key={item.href}
                  href={item.href}
                  onClick={onNavigate}
                  className={cn(
                    "group flex items-center gap-3 rounded-[1.2rem] border px-3.5 py-3 text-sm font-medium transition-all duration-200",
                    isActive
                      ? "border-primary/15 bg-primary-soft text-primary shadow-soft"
                      : "border-sidebar-border bg-sidebar-surface text-sidebar-foreground shadow-soft hover:-translate-y-0.5 hover:border-panel-border-strong hover:bg-surface",
                  )}
                >
                  <span
                    className={cn(
                      "inline-flex h-9 w-9 items-center justify-center rounded-xl border transition",
                      isActive
                        ? "border-primary/15 bg-surface text-primary"
                        : "border-sidebar-border bg-background/80 text-sidebar-muted group-hover:text-sidebar-foreground",
                    )}
                  >
                    <item.icon className="h-4 w-4" />
                  </span>
                  <span className="flex min-w-0 flex-1 items-center justify-between gap-3">
                    <span>{item.label}</span>
                    <ChevronRight
                      className={cn(
                        "h-4 w-4 transition-transform",
                        isActive
                          ? "text-primary/80"
                          : "text-sidebar-muted group-hover:translate-x-0.5 group-hover:text-sidebar-foreground",
                      )}
                    />
                  </span>
                </Link>
              );
            })}
          </nav>
        </div>

        <div className="mt-auto rounded-[1.2rem] border border-sidebar-border bg-sidebar-surface px-4 py-4 shadow-soft">
          <ThemeToggle />
        </div>
      </div>
    </div>
  );
}
