"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";

import { cn } from "@/lib/utils";

const navItems = [
  { href: "/capture", label: "Capture" },
  { href: "/timeline", label: "Timeline" },
  { href: "/ask", label: "Ask" },
];

export function TopNav() {
  const pathname = usePathname();

  return (
    <div className="flex items-center gap-2 rounded-full border border-nav-border bg-surface-strong p-1 shadow-soft backdrop-blur">
      {navItems.map((item: (typeof navItems)[number]) => {
        const isActive =
          pathname === item.href || pathname.startsWith(`${item.href}/`);

        return (
          <Link
            key={item.href}
            href={item.href}
            className={cn(
              "rounded-full px-3 py-1.5 text-sm font-medium transition",
              isActive
                ? "bg-primary text-primary-foreground shadow"
                : "text-muted-foreground hover:bg-accent hover:text-accent-foreground",
            )}
          >
            {item.label}
          </Link>
        );
      })}
    </div>
  );
}
