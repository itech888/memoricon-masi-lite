import * as React from "react";
import { Lock, ShieldCheck, Zap } from "lucide-react";

import { Text } from "@/components/ui/typography";

const defaultItems = [
  { label: "Encrypted", icon: Lock },
  { label: "AI Structured", icon: Zap },
  { label: "Verified", icon: ShieldCheck },
];

export function AssuranceStrip() {
  return (
    <div className="mt-8 flex flex-wrap items-center justify-center gap-3 md:gap-4">
      {defaultItems.map((item: (typeof defaultItems)[number]) => (
        <div
          key={item.label}
          className="inline-flex items-center gap-2 rounded-full border border-panel-border bg-surface-soft px-4 py-2 shadow-soft"
        >
          <item.icon className="h-3.5 w-3.5 text-primary" />
          <Text variant="eyebrow" as="span">
            {item.label}
          </Text>
        </div>
      ))}
    </div>
  );
}
