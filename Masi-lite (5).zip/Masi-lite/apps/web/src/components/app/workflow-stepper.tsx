"use client";

import Link from "next/link";
import { Check, Lock } from "lucide-react";

import {
  getWorkflowStepHref,
  workflowNavItems,
  type WorkflowStepKey,
} from "@/components/app/navigation";
import { Heading, Text } from "@/components/ui/typography";
import { cn } from "@/lib/utils";

const stepOrder: WorkflowStepKey[] = ["capture", "extract", "verify"];

function resolveStepState(currentStep: WorkflowStepKey, step: WorkflowStepKey) {
  const currentIndex = stepOrder.indexOf(currentStep);
  const stepIndex = stepOrder.indexOf(step);

  if (stepIndex < currentIndex) {
    return "complete";
  }

  if (stepIndex === currentIndex) {
    return "current";
  }

  return "upcoming";
}

export interface WorkflowStepperProps {
  currentStep: WorkflowStepKey;
  hasDraft?: boolean;
  compact?: boolean;
}

export function WorkflowStepper({
  currentStep,
  hasDraft = false,
  compact = false,
}: WorkflowStepperProps) {
  return (
    <div
      className={cn("glass-panel", compact ? "px-4 py-4" : "px-4 py-4 md:px-5")}
    >
      <div
        className={cn(
          "flex flex-wrap items-center justify-between gap-3",
          compact ? "mb-3" : "mb-4",
        )}
      >
        <div className="space-y-1">
          <Text variant="eyebrow" as="div">
            Verified Memory Workflow
          </Text>
          <Heading as="h2" variant="subsection">
            Capture, refine, and confirm before anything is stored.
          </Heading>
        </div>
        <Text variant="meta" as="div">
          Step {stepOrder.indexOf(currentStep) + 1} of {stepOrder.length}
        </Text>
      </div>

      <div className="grid gap-3 md:grid-cols-3">
        {workflowNavItems.map(
          (item: (typeof workflowNavItems)[number], index: number) => {
          const step = item.key;
          const state = resolveStepState(currentStep, step);
          const isDisabled = !hasDraft && step !== "capture";
          const stateLabel =
            state === "complete"
              ? "Completed"
              : state === "current"
                ? "Current step"
                : "Up next";

          return (
            <Link
              key={item.href}
              href={isDisabled ? "#" : getWorkflowStepHref(step)}
              aria-disabled={isDisabled}
              className={cn(
                "group relative overflow-hidden rounded-[1.35rem] border px-4 py-4 transition-all duration-200",
                state === "current" &&
                  "border-primary bg-primary text-primary-foreground shadow-button",
                state === "complete" &&
                  "border-panel-border bg-surface text-foreground shadow-soft",
                state === "upcoming" &&
                  "border-panel-border bg-surface-panel text-muted-foreground",
                !isDisabled &&
                  state !== "current" &&
                  "hover:-translate-y-0.5 hover:border-panel-border-strong hover:bg-surface-soft",
                isDisabled && "pointer-events-none opacity-55",
              )}
            >
              <div className="flex items-start justify-between gap-3">
                <span
                  className={cn(
                    "inline-flex h-11 w-11 items-center justify-center rounded-2xl border text-sm font-semibold transition",
                    state === "current" &&
                      "border-primary-foreground/15 bg-primary-foreground/10 text-primary-foreground",
                    state === "complete" &&
                      "border-input bg-surface-soft text-foreground",
                    state === "upcoming" &&
                      "border-input bg-surface text-muted-foreground",
                  )}
                >
                  {state === "complete" ? (
                    <Check className="h-4 w-4" />
                  ) : isDisabled ? (
                    <Lock className="h-4 w-4" />
                  ) : (
                    <item.icon className="h-4 w-4" />
                  )}
                </span>

                <Text
                  as="span"
                  variant={state === "current" ? "eyebrow" : "meta"}
                  className={cn(
                    "text-right",
                    state === "current"
                      ? "text-primary-foreground/82"
                      : undefined,
                  )}
                >
                  {stateLabel}
                </Text>
              </div>

              <div className="mt-6 space-y-1.5">
                <Text
                  as="div"
                  variant={state === "current" ? "eyebrow" : "meta"}
                  className={cn(
                    state === "current"
                      ? "text-primary-foreground/72"
                      : undefined,
                  )}
                >
                  Step {index + 1}
                </Text>
                <Heading
                  as="h3"
                  variant="subsection"
                  className={cn(
                    state === "current"
                      ? "text-primary-foreground"
                      : "text-inherit",
                  )}
                >
                  {item.label}
                </Heading>
              </div>
            </Link>
          );
          },
        )}
      </div>
    </div>
  );
}
