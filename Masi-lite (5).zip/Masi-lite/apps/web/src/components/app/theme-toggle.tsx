"use client";

import { MoonStar, SunMedium } from "lucide-react";

import { Button } from "@/components/ui/button";
import { Text } from "@/components/ui/typography";
import { useTheme } from "@/components/app/theme-provider";

export interface ThemeToggleProps {
  compact?: boolean;
}

export function ThemeToggle({ compact = false }: ThemeToggleProps) {
  const { theme, toggleTheme } = useTheme();
  const isDark = theme === "dark";

  if (compact) {
    return (
      <Button
        type="button"
        variant="soft"
        size="icon"
        onClick={toggleTheme}
        aria-label={isDark ? "Switch to light mode" : "Switch to dark mode"}
      >
        {isDark ? (
          <SunMedium className="h-4 w-4" />
        ) : (
          <MoonStar className="h-4 w-4" />
        )}
      </Button>
    );
  }

  return (
    <div className="flex items-center justify-between gap-3">
      <div className="space-y-1">
        <Text variant="eyebrow" as="div">
          Theme
        </Text>
        <Text variant="meta">{isDark ? "Dark mode active" : "Light mode active"}</Text>
      </div>
      <Button type="button" variant="soft" size="sm" onClick={toggleTheme}>
        {isDark ? (
          <SunMedium className="h-4 w-4" />
        ) : (
          <MoonStar className="h-4 w-4" />
        )}
        {isDark ? "Light" : "Dark"}
      </Button>
    </div>
  );
}
