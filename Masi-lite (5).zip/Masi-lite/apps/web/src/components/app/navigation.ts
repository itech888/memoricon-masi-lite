import {
  BadgeCheck,
  Clock3,
  MessageSquareText,
  Mic,
  Sparkles,
} from "lucide-react";

export const appNavItems = [
  { href: "/capture", label: "Capture", icon: Mic },
  { href: "/timeline", label: "Timeline", icon: Clock3 },
  { href: "/ask", label: "Ask Recall", icon: MessageSquareText },
] as const;

export const workflowStepKeys = ["capture", "extract", "verify"] as const;
export type WorkflowStepKey = (typeof workflowStepKeys)[number];

export const workflowNavItems = [
  { key: "capture", href: "/capture", label: "Capture", icon: Mic },
  {
    key: "extract",
    href: "/capture?step=extract",
    label: "Extraction",
    icon: Sparkles,
  },
  {
    key: "verify",
    href: "/capture?step=verify",
    label: "Verification",
    icon: BadgeCheck,
  },
] as const;

export function getWorkflowStepHref(step: WorkflowStepKey) {
  if (step === "capture") {
    return "/capture";
  }

  return `/capture?step=${step}`;
}

export function isWorkflowRoute(pathname: string) {
  return pathname === "/capture" || pathname === "/extract" || pathname === "/verify";
}

export function isPrimaryNavItemActive(pathname: string, href: string) {
  if (href === "/capture") {
    return isWorkflowRoute(pathname);
  }

  return pathname === href || pathname.startsWith(`${href}/`);
}
