import * as React from "react";
import { cva, type VariantProps } from "class-variance-authority";

import { cn } from "@/lib/utils";

const statusPillVariants = cva(
  "inline-flex items-center gap-2 rounded-full border px-4 py-2 text-[0.74rem] font-semibold uppercase tracking-[0.14em]",
  {
    variants: {
      variant: {
        success: "border-status-success-border bg-status-success-bg text-status-success-foreground",
        info: "border-panel-border bg-surface text-foreground",
        warning: "border-status-warning-border bg-status-warning-bg text-status-warning-foreground",
        danger: "border-status-danger-border bg-status-danger-bg text-status-danger-foreground",
      },
    },
    defaultVariants: {
      variant: "info",
    },
  }
);

export interface StatusPillProps
  extends React.HTMLAttributes<HTMLDivElement>,
    VariantProps<typeof statusPillVariants> {
  dotVariant?: "success" | "info" | "warning" | "danger";
}

const dotColorMap = {
  success: "bg-status-ok",
  info: "bg-status-info",
  warning: "bg-secondary",
  danger: "bg-destructive",
} as const;

export function StatusPill({
  className,
  children,
  variant,
  dotVariant,
  ...props
}: StatusPillProps) {
  const resolvedDotVariant = dotVariant ?? (variant === "success" ? "success" : "info");

  return (
    <div className={cn(statusPillVariants({ variant, className }))} {...props}>
      <span className={cn("h-2.5 w-2.5 rounded-full", dotColorMap[resolvedDotVariant])} />
      {children}
    </div>
  );
}
