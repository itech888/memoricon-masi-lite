import Link from "next/link";
import * as React from "react";

import { Badge } from "@/components/ui/badge";
import { MetricBar } from "@/components/ui/metric-bar";
import { SectionCard } from "@/components/ui/section-card";
import { Text } from "@/components/ui/typography";

export interface MemoryResultCardProps {
  href: string;
  title: string;
  meta: string;
  tags: string[];
  confidence: number;
  note?: React.ReactNode;
}

export function MemoryResultCard({
  href,
  title,
  meta,
  tags,
  confidence,
  note,
}: MemoryResultCardProps) {
  return (
    <Link href={href} className="block">
      <SectionCard
        variant="outline"
        className="transition-[transform,background-color,border-color] duration-200 hover:-translate-y-0.5 hover:border-panel-border-strong hover:bg-surface-soft"
        contentClassName="space-y-4"
        headerAside={
          <div className="w-full max-w-[7rem]">
            <MetricBar
              size="compact"
              label="Confidence"
              value={confidence}
              displayValue={`${confidence}%`}
            />
          </div>
        }
        title={title}
      >
        <div>
          <Text variant="meta">{meta}</Text>
          {note ? (
            typeof note === "string" || typeof note === "number" ? (
              <Text variant="meta" className="mt-2">
                {note}
              </Text>
            ) : (
              note
            )
          ) : null}
        </div>

        <div className="flex flex-wrap gap-1">
          {tags.length > 0 ? (
            tags.map((tag: string) => (
              <Badge key={tag} variant="outline">
                {tag}
              </Badge>
            ))
          ) : (
            <Badge variant="soft">No Tags</Badge>
          )}
        </div>
      </SectionCard>
    </Link>
  );
}
