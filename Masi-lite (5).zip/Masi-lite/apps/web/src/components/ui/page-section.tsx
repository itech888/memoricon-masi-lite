import * as React from "react";
import { cva, type VariantProps } from "class-variance-authority";

import { cn } from "@/lib/utils";

const pageSectionVariants = cva("section-gap", {
  variants: {
    stagger: {
      default: "",
      one: "stagger-1",
      two: "stagger-2",
      three: "stagger-3",
    },
  },
  defaultVariants: {
    stagger: "default",
  },
});

type PageSectionTag = "section" | "div";

export interface PageSectionProps
  extends
    React.HTMLAttributes<HTMLElement>,
    VariantProps<typeof pageSectionVariants> {
  as?: PageSectionTag;
}

export function PageSection({
  as: Component = "section",
  className,
  stagger,
  ...props
}: PageSectionProps) {
  return (
    <Component
      className={cn(pageSectionVariants({ stagger, className }))}
      {...props}
    />
  );
}
