import * as React from "react";
import { cva, type VariantProps } from "class-variance-authority";

import { Text } from "@/components/ui/typography";
import { cn } from "@/lib/utils";

const formFieldVariants = cva("space-y-2", {
  variants: {
    variant: {
      default: "",
      dense: "space-y-1.5",
      section: "space-y-5"
    }
  },
  defaultVariants: {
    variant: "default"
  }
});

export interface FormFieldProps
  extends React.HTMLAttributes<HTMLDivElement>,
    VariantProps<typeof formFieldVariants> {
  label: React.ReactNode;
  hint?: React.ReactNode;
  action?: React.ReactNode;
}

function renderFieldText(content: React.ReactNode | undefined, variant: "eyebrow" | "label" | "meta") {
  if (content === undefined || content === null) {
    return null;
  }

  if (typeof content === "string" || typeof content === "number") {
    return <Text variant={variant}>{content}</Text>;
  }

  return content;
}

export function FormField({
  label,
  hint,
  action,
  className,
  variant,
  children,
  ...props
}: FormFieldProps) {
  const labelVariant = variant === "dense" ? "label" : "eyebrow";

  return (
    <div className={cn(formFieldVariants({ variant, className }))} {...props}>
      <div
        className={cn(
          "flex flex-wrap items-center justify-between gap-2",
          variant === "section" ? "gap-4" : undefined
        )}
      >
        {variant === "section" ? (
          <>
            {renderFieldText(label, "eyebrow")}
            <div className="h-px flex-1 bg-border" />
          </>
        ) : (
          renderFieldText(label, labelVariant)
        )}
        {action ? <div className="flex shrink-0 flex-wrap items-center gap-2">{action}</div> : null}
      </div>
      {renderFieldText(hint, "meta")}
      {children}
    </div>
  );
}
