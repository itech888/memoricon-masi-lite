import * as React from "react";
import { cva, type VariantProps } from "class-variance-authority";

import { Text } from "@/components/ui/typography";
import { cn } from "@/lib/utils";

const metricBarVariants = cva("space-y-2", {
  variants: {
    variant: {
      default: "",
      soft: "rounded-[1.2rem] border border-panel-border bg-surface-soft p-4"
    },
    size: {
      default: "",
      compact: "space-y-1"
    }
  },
  defaultVariants: {
    variant: "default",
    size: "default"
  }
});

export interface MetricBarProps
  extends React.HTMLAttributes<HTMLDivElement>,
    VariantProps<typeof metricBarVariants> {
  label?: React.ReactNode;
  value: number;
  displayValue?: React.ReactNode;
}

export function MetricBar({
  label,
  value,
  displayValue,
  className,
  variant,
  size,
  ...props
}: MetricBarProps) {
  const width = Math.max(0, Math.min(100, value));
  const resolvedDisplayValue = displayValue ?? `${Math.round(width)}%`;
  const barHeight = size === "compact" ? "h-1.5" : "h-2";

  return (
    <div className={cn(metricBarVariants({ variant, size, className }))} {...props}>
      {label || resolvedDisplayValue ? (
        <div className="flex items-center justify-between gap-3">
          {label ? (
            typeof label === "string" || typeof label === "number" ? (
              <Text variant="eyebrow">{label}</Text>
            ) : (
              label
            )
          ) : (
            <span />
          )}
          {typeof resolvedDisplayValue === "string" || typeof resolvedDisplayValue === "number" ? (
            <Text
              variant={size === "compact" ? "meta" : "body"}
              className={cn(size === "compact" ? "font-semibold text-foreground" : "text-lg font-semibold md:text-xl")}
            >
              {resolvedDisplayValue}
            </Text>
          ) : (
            resolvedDisplayValue
          )}
        </div>
      ) : null}

      <div className={cn(barHeight, "rounded-full bg-muted/80")}>
        <div
          className={cn(barHeight, "rounded-full bg-gradient-to-r from-primary to-primary-strong shadow-button")}
          style={{ width: `${width}%` }}
        />
      </div>
    </div>
  );
}
