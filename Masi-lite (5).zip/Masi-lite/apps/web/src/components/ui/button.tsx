import * as React from "react";
import { cva, type VariantProps } from "class-variance-authority";

import { cn } from "@/lib/utils";

const buttonVariants = cva(
  "inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-xl text-sm font-semibold transition-[transform,box-shadow,background-color,border-color,color] duration-200 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 ring-offset-background active:translate-y-px",
  {
    variants: {
      variant: {
        default:
          "bg-gradient-to-r from-primary to-primary-strong text-primary-foreground shadow-button hover:-translate-y-0.5 hover:shadow-card",
        outline:
          "border border-input bg-surface-strong text-foreground shadow-soft backdrop-blur-sm hover:-translate-y-0.5 hover:border-panel-border-strong hover:bg-surface",
        soft: "border border-panel-border bg-surface-soft text-foreground shadow-soft hover:-translate-y-0.5 hover:border-panel-border-strong hover:bg-surface",
        ghost: "text-muted-foreground hover:bg-accent hover:text-accent-foreground",
        destructive: "bg-destructive text-destructive-foreground shadow-soft hover:-translate-y-0.5 hover:opacity-90",
        destructiveOutline:
          "border border-status-danger-border bg-surface text-destructive shadow-soft hover:-translate-y-0.5 hover:bg-status-danger-bg"
      },
      size: {
        default: "h-11 px-4 py-2.5",
        sm: "h-9 px-3.5",
        lg: "h-12 px-8",
        icon: "h-11 w-11"
      }
    },
    defaultVariants: {
      variant: "default",
      size: "default"
    }
  }
);

export interface ButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement>,
    VariantProps<typeof buttonVariants> {}

const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant, size, ...props }, ref) => {
    return <button className={cn(buttonVariants({ variant, size, className }))} ref={ref} {...props} />;
  }
);
Button.displayName = "Button";

export { Button, buttonVariants };
