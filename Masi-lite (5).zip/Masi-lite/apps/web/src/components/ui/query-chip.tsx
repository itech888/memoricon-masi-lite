import * as React from "react";
import { cva, type VariantProps } from "class-variance-authority";

import { cn } from "@/lib/utils";

const queryChipVariants = cva(
  "inline-flex items-center rounded-full border px-4 py-2.5 text-sm font-medium transition-[transform,background-color,border-color,color] duration-200 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50",
  {
    variants: {
      variant: {
        default: "border-input bg-surface text-foreground shadow-soft hover:-translate-y-0.5 hover:border-panel-border-strong hover:bg-surface-soft",
        active: "border-primary/20 bg-primary-soft text-primary shadow-soft hover:-translate-y-0.5",
      },
    },
    defaultVariants: {
      variant: "default",
    },
  }
);

export interface QueryChipProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement>,
    VariantProps<typeof queryChipVariants> {}

export const QueryChip = React.forwardRef<HTMLButtonElement, QueryChipProps>(
  ({ className, variant, ...props }, ref) => {
    return (
      <button
        ref={ref}
        type="button"
        className={cn(queryChipVariants({ variant, className }))}
        {...props}
      />
    );
  }
);
QueryChip.displayName = "QueryChip";
