import * as React from "react";
import { cva, type VariantProps } from "class-variance-authority";

import { cn } from "@/lib/utils";

const choiceTileVariants = cva(
  "inline-flex w-full items-center justify-center rounded-[1.2rem] border px-5 py-4 text-base font-medium transition-[transform,background-color,border-color,color] duration-200 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2",
  {
    variants: {
      variant: {
        default: "border-input bg-surface text-foreground shadow-soft hover:-translate-y-0.5 hover:border-panel-border-strong hover:bg-surface-soft",
        selected: "border-primary/20 bg-primary-soft text-primary shadow-soft",
      },
    },
    defaultVariants: {
      variant: "default",
    },
  }
);

export interface ChoiceTileProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement>,
    VariantProps<typeof choiceTileVariants> {}

export const ChoiceTile = React.forwardRef<HTMLButtonElement, ChoiceTileProps>(
  ({ className, type = "button", variant, ...props }, ref) => {
    return (
      <button
        ref={ref}
        type={type}
        className={cn(choiceTileVariants({ variant, className }))}
        {...props}
      />
    );
  }
);
ChoiceTile.displayName = "ChoiceTile";
