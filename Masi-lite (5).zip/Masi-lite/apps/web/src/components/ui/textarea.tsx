import * as React from "react";
import { cva, type VariantProps } from "class-variance-authority";

import { cn } from "@/lib/utils";

const textareaVariants = cva(
  "flex w-full rounded-xl text-foreground ring-offset-background placeholder:text-muted-foreground transition-[border-color,box-shadow,background-color] focus-visible:outline-none disabled:cursor-not-allowed disabled:opacity-50",
  {
    variants: {
      variant: {
        default:
          "min-h-[88px] border border-input bg-surface-input px-4 py-3 text-sm shadow-soft focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2",
        outline:
          "min-h-[88px] border border-input bg-surface px-4 py-3 text-sm shadow-soft focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2",
        soft:
          "min-h-[88px] border border-panel-border bg-surface-soft px-4 py-3 text-sm shadow-soft focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2",
        ghost:
          "min-h-[80px] border-0 bg-transparent px-0 py-0 text-sm focus-visible:ring-0 focus-visible:ring-offset-0",
        transcript:
          "min-h-[29rem] resize-none border-0 bg-transparent px-0 py-0 text-[0.98rem] leading-8 text-foreground/90 focus-visible:ring-0 focus-visible:ring-offset-0",
        composer:
          "min-h-[8.75rem] resize-none border-0 bg-transparent px-0 py-0 text-[1.18rem] leading-[1.7] text-foreground focus-visible:ring-0 focus-visible:ring-offset-0 md:text-[1.32rem]"
      }
    },
    defaultVariants: {
      variant: "default"
    }
  }
);

export interface TextareaProps
  extends React.TextareaHTMLAttributes<HTMLTextAreaElement>,
    VariantProps<typeof textareaVariants> {}

const Textarea = React.forwardRef<HTMLTextAreaElement, TextareaProps>(
  ({ className, variant, ...props }, ref) => {
  return (
    <textarea
      className={cn(textareaVariants({ variant, className }))}
      ref={ref}
      {...props}
    />
  );
  }
);
Textarea.displayName = "Textarea";

export { Textarea };
