import Link, { type LinkProps } from "next/link";
import * as React from "react";
import { cva, type VariantProps } from "class-variance-authority";

import { cn } from "@/lib/utils";

const textLinkVariants = cva("text-sm transition", {
  variants: {
    variant: {
      default: "text-primary hover:underline",
      muted: "text-muted-foreground hover:text-foreground hover:underline"
    }
  },
  defaultVariants: {
    variant: "default"
  }
});

export interface TextLinkProps
  extends LinkProps,
    Omit<React.AnchorHTMLAttributes<HTMLAnchorElement>, keyof LinkProps>,
    VariantProps<typeof textLinkVariants> {}

export function TextLink({ className, variant, ...props }: TextLinkProps) {
  return <Link className={cn(textLinkVariants({ variant, className }))} {...props} />;
}
