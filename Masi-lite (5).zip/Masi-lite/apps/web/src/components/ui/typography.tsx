import * as React from "react";
import { cva, type VariantProps } from "class-variance-authority";

import { cn } from "@/lib/utils";

const headingVariants = cva("font-ui text-foreground tracking-[-0.03em]", {
  variants: {
    variant: {
      page: "text-[2.2rem] font-semibold leading-[1.04] md:text-[2.85rem]",
      section: "text-[1.72rem] font-semibold leading-[1.08] md:text-[2.05rem]",
      card: "text-[1.18rem] font-semibold leading-tight",
      cardInverse: "text-[1.18rem] font-semibold leading-tight text-sidebar-foreground",
      subsection: "text-base font-semibold leading-6",
      label: "text-xs font-semibold uppercase tracking-[0.16em] text-muted-foreground"
    }
  },
  defaultVariants: {
    variant: "section"
  }
});

const textVariants = cva("font-ui text-foreground", {
  variants: {
    variant: {
      body: "text-[0.94rem] leading-7 md:text-[0.98rem]",
      bodyInverse: "text-[0.97rem] leading-7 text-sidebar-foreground md:text-base",
      lead: "text-[1rem] leading-8 md:text-[1.05rem]",
      bodySm: "text-sm",
      muted: "text-sm text-muted-foreground",
      subtitle: "text-[0.98rem] leading-7 text-muted-foreground md:text-[1.04rem]",
      meta: "text-sm text-muted-foreground",
      metaInverse: "text-sm text-sidebar-muted",
      label: "text-sm font-semibold",
      eyebrow: "text-[0.72rem] font-semibold uppercase tracking-[0.18em] text-muted-foreground",
      eyebrowInverse: "text-[0.72rem] font-semibold uppercase tracking-[0.18em] text-sidebar-muted",
      eyebrowAccent: "text-[0.72rem] font-semibold uppercase tracking-[0.18em] text-primary",
      error: "text-sm font-medium text-destructive"
    }
  },
  defaultVariants: {
    variant: "body"
  }
});

type HeadingTag = "h1" | "h2" | "h3" | "h4";
type TextTag = "p" | "span" | "div";

export interface HeadingProps
  extends Omit<React.HTMLAttributes<HTMLHeadingElement>, "color">,
    VariantProps<typeof headingVariants> {
  as?: HeadingTag;
}

export const Heading = React.forwardRef<HTMLHeadingElement, HeadingProps>(
  ({ as: Component = "h2", className, variant, ...props }, ref) => {
    return <Component ref={ref} className={cn(headingVariants({ variant, className }))} {...props} />;
  }
);
Heading.displayName = "Heading";

export interface TextProps
  extends Omit<React.HTMLAttributes<HTMLElement>, "color">,
    VariantProps<typeof textVariants> {
  as?: TextTag;
}

export function Text({
  as: Component = "p",
  className,
  variant,
  ...props
}: TextProps) {
  return <Component className={cn(textVariants({ variant, className }))} {...props} />;
}

export { headingVariants, textVariants };
