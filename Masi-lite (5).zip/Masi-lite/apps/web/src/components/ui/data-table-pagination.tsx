import { ChevronLeft, ChevronRight } from "lucide-react";

import { Button } from "@/components/ui/button";
import { Select } from "@/components/ui/select";
import { Text } from "@/components/ui/typography";

export interface DataTablePaginationProps {
  page: number;
  pageCount: number;
  pageSize: number;
  total: number;
  displayStart: number;
  displayEnd: number;
  disabled?: boolean;
  onPageChange: (nextPage: number) => void;
  onPageSizeChange: (nextPageSize: number) => void;
}

export function DataTablePagination({
  page,
  pageCount,
  pageSize,
  total,
  displayStart,
  displayEnd,
  disabled = false,
  onPageChange,
  onPageSizeChange
}: DataTablePaginationProps) {
  const canGoPrev = page > 0;
  const canGoNext = page + 1 < pageCount;

  return (
    <>
      <div className="flex flex-wrap items-center gap-3">
        <Text variant="meta">
          Showing {displayStart} to {displayEnd} of {total} memories
        </Text>
        <div className="w-[8.5rem]">
          <Select
            aria-label="Rows per page"
            value={String(pageSize)}
            onChange={(event) => onPageSizeChange(Number(event.target.value))}
            variant="soft"
            uiSize="sm"
            disabled={disabled}
          >
            <option value="8">8 per page</option>
            <option value="12">12 per page</option>
            <option value="20">20 per page</option>
          </Select>
        </div>
      </div>

      <div className="flex items-center gap-2">
        <Text variant="meta">
          Page {pageCount === 0 ? 0 : page + 1} of {pageCount}
        </Text>
        <Button
          type="button"
          variant="ghost"
          size="sm"
          disabled={disabled || !canGoPrev}
          onClick={() => onPageChange(page - 1)}
          aria-label="Previous page"
        >
          <ChevronLeft className="h-4 w-4" />
        </Button>
        <Button
          type="button"
          variant="ghost"
          size="sm"
          disabled={disabled || !canGoNext}
          onClick={() => onPageChange(page + 1)}
          aria-label="Next page"
        >
          <ChevronRight className="h-4 w-4" />
        </Button>
      </div>
    </>
  );
}
