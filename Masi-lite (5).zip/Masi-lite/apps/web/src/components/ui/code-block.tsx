import * as React from "react";
import { cva, type VariantProps } from "class-variance-authority";

import { cn } from "@/lib/utils";

const codeBlockVariants = cva("overflow-auto rounded-xl border p-4 font-ui text-xs", {
  variants: {
    variant: {
      default: "border-panel-border bg-code-bg text-code-foreground",
      soft: "border-input bg-muted text-foreground"
    }
  },
  defaultVariants: {
    variant: "default"
  }
});

export interface CodeBlockProps
  extends React.HTMLAttributes<HTMLPreElement>,
    VariantProps<typeof codeBlockVariants> {}

export function CodeBlock({ className, variant, ...props }: CodeBlockProps) {
  return <pre className={cn(codeBlockVariants({ variant, className }))} {...props} />;
}
