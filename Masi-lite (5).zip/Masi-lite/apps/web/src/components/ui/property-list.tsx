import * as React from "react";
import { cva, type VariantProps } from "class-variance-authority";

import { Text } from "@/components/ui/typography";
import { cn } from "@/lib/utils";

const propertyListVariants = cva("space-y-4", {
  variants: {
    variant: {
      default: "",
      dense: "space-y-2.5"
    }
  },
  defaultVariants: {
    variant: "default"
  }
});

const propertyItemVariants = cva("", {
  variants: {
    variant: {
      default: "space-y-2 rounded-[1.25rem] border border-input bg-surface-soft px-4 py-4",
      inline: "flex flex-wrap items-baseline gap-2"
    }
  },
  defaultVariants: {
    variant: "default"
  }
});

export interface PropertyListProps
  extends React.HTMLAttributes<HTMLDivElement>,
    VariantProps<typeof propertyListVariants> {}

export interface PropertyItemProps
  extends React.HTMLAttributes<HTMLDivElement>,
    VariantProps<typeof propertyItemVariants> {
  label: React.ReactNode;
  value?: React.ReactNode;
}

function renderPropertyValue(value: React.ReactNode | undefined) {
  if (value === undefined || value === null) {
    return null;
  }

  if (typeof value === "string" || typeof value === "number") {
    return <Text variant="body">{value}</Text>;
  }

  return value;
}

export function PropertyList({ className, variant, ...props }: PropertyListProps) {
  return <div className={cn(propertyListVariants({ variant, className }))} {...props} />;
}

export function PropertyItem({
  label,
  value,
  children,
  className,
  variant,
  ...props
}: PropertyItemProps) {
  const content = children ?? renderPropertyValue(value);

  return (
    <div className={cn(propertyItemVariants({ variant, className }))} {...props}>
      {typeof label === "string" || typeof label === "number" ? (
        <Text variant="label">{label}</Text>
      ) : (
        label
      )}
      {content}
    </div>
  );
}
