import * as React from "react";
import { ChevronDown } from "lucide-react";
import { cva, type VariantProps } from "class-variance-authority";

import { cn } from "@/lib/utils";

const selectVariants = cva(
  "w-full appearance-none rounded-xl border text-foreground ring-offset-background shadow-soft transition-[border-color,box-shadow,background-color] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50",
  {
    variants: {
      variant: {
        default: "border border-input bg-surface-input",
        outline: "border border-input bg-surface",
        soft: "border border-panel-border bg-surface-soft"
      },
      uiSize: {
        default: "h-11 px-4 pr-11 text-sm",
        sm: "h-10 px-3.5 pr-10 text-sm"
      }
    },
    defaultVariants: {
      variant: "default",
      uiSize: "default"
    }
  }
);

export interface SelectProps
  extends React.SelectHTMLAttributes<HTMLSelectElement>,
    VariantProps<typeof selectVariants> {
  leadingIcon?: React.ReactNode;
}

export const Select = React.forwardRef<HTMLSelectElement, SelectProps>(
  ({ className, children, leadingIcon, uiSize, variant, ...props }, ref) => {
    return (
      <div className="relative">
        {leadingIcon ? (
          <div className="pointer-events-none absolute left-3 top-1/2 z-10 -translate-y-1/2 text-muted-foreground">
            {leadingIcon}
          </div>
        ) : null}
        <select
          ref={ref}
          className={cn(
            selectVariants({ variant, uiSize, className }),
            leadingIcon ? "pl-10" : undefined
          )}
          {...props}
        >
          {children}
        </select>
        <ChevronDown className="pointer-events-none absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
      </div>
    );
  }
);
Select.displayName = "Select";
