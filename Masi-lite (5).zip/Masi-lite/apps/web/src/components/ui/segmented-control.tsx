import * as React from "react";
import { cva, type VariantProps } from "class-variance-authority";

import { cn } from "@/lib/utils";

const segmentedControlVariants = cva(
  "inline-flex items-center rounded-[1rem] border border-input bg-surface p-1 shadow-soft",
  {
    variants: {
      size: {
        default: "gap-1",
        sm: "gap-0.5"
      }
    },
    defaultVariants: {
      size: "default"
    }
  }
);

const segmentedItemVariants = cva(
  "inline-flex items-center justify-center rounded-[0.8rem] px-3.5 py-2 text-sm font-medium transition-[background-color,color,transform] duration-200",
  {
    variants: {
      state: {
        active: "bg-primary text-primary-foreground shadow-button",
        inactive: "text-muted-foreground hover:text-foreground"
      }
    },
    defaultVariants: {
      state: "inactive"
    }
  }
);

export interface SegmentedControlItem {
  label: React.ReactNode;
  value: string;
  disabled?: boolean;
}

export interface SegmentedControlProps
  extends React.HTMLAttributes<HTMLDivElement>,
    VariantProps<typeof segmentedControlVariants> {
  items: SegmentedControlItem[];
  value: string;
  onValueChange: (value: string) => void;
}

export function SegmentedControl({
  items,
  value,
  onValueChange,
  className,
  size,
  ...props
}: SegmentedControlProps) {
  return (
    <div className={cn(segmentedControlVariants({ size, className }))} {...props}>
      {items.map((item: SegmentedControlItem) => {
        const isActive = item.value === value;

        return (
          <button
            key={item.value}
            type="button"
            disabled={item.disabled}
            className={cn(
              segmentedItemVariants({ state: isActive ? "active" : "inactive" }),
              item.disabled ? "pointer-events-none opacity-50" : undefined
            )}
            onClick={() => onValueChange(item.value)}
          >
            {item.label}
          </button>
        );
      })}
    </div>
  );
}
