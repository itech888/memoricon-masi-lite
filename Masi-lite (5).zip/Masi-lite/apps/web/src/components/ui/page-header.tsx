import * as React from "react";
import { cva, type VariantProps } from "class-variance-authority";

import { Heading, Text } from "@/components/ui/typography";
import { cn } from "@/lib/utils";

const pageHeaderVariants = cva("", {
  variants: {
    variant: {
      default: "page-hero",
      compact: "glass-panel px-5 py-5 md:px-6 md:py-5",
    },
  },
  defaultVariants: {
    variant: "default",
  },
});

type PageHeaderTag = "section" | "header" | "div";

function renderCopy(
  content: React.ReactNode | undefined,
  textVariant: "eyebrow" | "subtitle" | "meta",
) {
  if (content === undefined || content === null) {
    return null;
  }

  if (typeof content === "string" || typeof content === "number") {
    return <Text variant={textVariant}>{content}</Text>;
  }

  return content;
}

export interface PageHeaderProps
  extends
    Omit<React.HTMLAttributes<HTMLElement>, "title">,
    VariantProps<typeof pageHeaderVariants> {
  title: React.ReactNode;
  description?: React.ReactNode;
  eyebrow?: React.ReactNode;
  meta?: React.ReactNode;
  actions?: React.ReactNode;
  as?: PageHeaderTag;
}

export function PageHeader({
  title,
  description,
  eyebrow,
  meta,
  actions,
  as: Component = "section",
  className,
  variant,
  ...props
}: PageHeaderProps) {
  return (
    <Component
      className={cn(pageHeaderVariants({ variant, className }))}
      {...props}
    >
      <div
        className={cn(
          "flex flex-col items-start gap-4 md:flex-row md:flex-wrap md:items-start md:justify-between",
          variant === "default" ? "mb-0" : "mb-4",
        )}
      >
        <div className="min-w-0 flex-1 space-y-2">
          {renderCopy(eyebrow, "eyebrow")}
          {typeof title === "string" || typeof title === "number" ? (
            <Heading
              as="h1"
              variant={variant === "compact" ? "section" : "page"}
            >
              {title}
            </Heading>
          ) : (
            title
          )}
          {renderCopy(description, variant === "compact" ? "meta" : "subtitle")}
          {renderCopy(meta, "meta")}
        </div>

        {actions ? (
          <div className="flex w-full flex-wrap items-center gap-2 md:w-auto md:shrink-0 md:justify-end">
            {actions}
          </div>
        ) : null}
      </div>
    </Component>
  );
}
