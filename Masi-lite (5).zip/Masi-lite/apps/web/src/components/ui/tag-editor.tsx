import * as React from "react";
import { X } from "lucide-react";

import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";

export interface TagEditorProps
  extends Omit<React.HTMLAttributes<HTMLDivElement>, "onChange"> {
  tags: string[];
  placeholder?: string;
  disabled?: boolean;
  onChange: (tags: string[]) => void;
}

export function TagEditor({
  tags,
  placeholder = "Add tag...",
  disabled,
  onChange,
  className,
  ...props
}: TagEditorProps) {
  const [value, setValue] = React.useState("");

  function commitTag() {
    const nextTag = value.trim();

    if (!nextTag) {
      return;
    }

    if (tags.includes(nextTag)) {
      setValue("");
      return;
    }

    onChange([...tags, nextTag]);
    setValue("");
  }

  function removeTag(tag: string) {
    onChange(tags.filter((item: string) => item !== tag));
  }

  return (
    <div
      className={cn(
        "rounded-2xl border border-input bg-surface-input px-3 py-3",
        className
      )}
      {...props}
    >
      {tags.length > 0 ? (
        <div className="mb-3 flex flex-wrap gap-2">
          {tags.map((tag: string) => (
            <button
              key={tag}
              type="button"
              onClick={() => removeTag(tag)}
              disabled={disabled}
              className="inline-flex"
            >
              <Badge variant="primary" className="gap-2 px-3 py-1.5 text-sm font-medium">
                {tag}
                <X className="h-3.5 w-3.5" />
              </Badge>
            </button>
          ))}
        </div>
      ) : null}

      <Input
        variant="ghost"
        value={value}
        onChange={(event) => setValue(event.target.value)}
        onKeyDown={(event) => {
          if (event.key === "Enter") {
            event.preventDefault();
            commitTag();
          }
        }}
        onBlur={commitTag}
        placeholder={placeholder}
        disabled={disabled}
      />
    </div>
  );
}
