import * as React from "react";
import { cva, type VariantProps } from "class-variance-authority";

import { Heading } from "@/components/ui/typography";
import { cn } from "@/lib/utils";

const cardVariants = cva("rounded-[1.65rem] border text-card-foreground", {
  variants: {
    variant: {
      default:
        "border-panel-border bg-surface-strong shadow-card backdrop-blur-xl",
      outline:
        "border-input bg-surface shadow-soft",
      soft:
        "border-panel-border bg-surface-soft shadow-soft backdrop-blur-md"
    },
    overflow: {
      visible: "overflow-visible",
      hidden: "overflow-hidden"
    }
  },
  defaultVariants: {
    variant: "default",
    overflow: "visible"
  }
});

export interface CardProps extends React.HTMLAttributes<HTMLDivElement>, VariantProps<typeof cardVariants> {}

const Card = React.forwardRef<HTMLDivElement, CardProps>(
  ({ className, variant, overflow, ...props }, ref) => (
    <div
      ref={ref}
      className={cn(cardVariants({ variant, overflow, className }))}
      {...props}
    />
  )
);
Card.displayName = "Card";

const CardHeader = React.forwardRef<HTMLDivElement, React.HTMLAttributes<HTMLDivElement>>(
  ({ className, ...props }, ref) => <div ref={ref} className={cn("flex flex-col space-y-1.5 p-6 md:p-7", className)} {...props} />
);
CardHeader.displayName = "CardHeader";

const CardTitle = React.forwardRef<HTMLHeadingElement, React.HTMLAttributes<HTMLHeadingElement>>(
  ({ className, ...props }, ref) => (
    <Heading as="h3" ref={ref} variant="card" className={className} {...props} />
  )
);
CardTitle.displayName = "CardTitle";

const CardContent = React.forwardRef<HTMLDivElement, React.HTMLAttributes<HTMLDivElement>>(
  ({ className, ...props }, ref) => <div ref={ref} className={cn("p-6 pt-0 md:p-7 md:pt-0", className)} {...props} />
);
CardContent.displayName = "CardContent";

export { Card, CardHeader, CardTitle, CardContent };
