import Link from "next/link";
import * as React from "react";
import { FileText } from "lucide-react";

import { Text } from "@/components/ui/typography";
import { cn } from "@/lib/utils";

export interface SourceCardProps
  extends Omit<React.AnchorHTMLAttributes<HTMLAnchorElement>, "href" | "title"> {
  href: string;
  title: React.ReactNode;
  meta?: React.ReactNode;
}

export function SourceCard({ href, title, meta, className, ...props }: SourceCardProps) {
  return (
    <Link
      href={href}
      className={cn(
        "flex items-center gap-3 rounded-[1.2rem] border border-input bg-surface px-4 py-4 shadow-soft transition-[transform,background-color,border-color] duration-200 hover:-translate-y-0.5 hover:border-panel-border-strong hover:bg-surface-soft",
        className
      )}
      {...props}
    >
      <span className="inline-flex h-10 w-10 items-center justify-center rounded-xl border border-input bg-surface-soft text-muted-foreground">
        <FileText className="h-4 w-4" />
      </span>
      <span className="min-w-0 flex-1">
        {typeof title === "string" || typeof title === "number" ? (
          <Text as="div" variant="bodySm" className="truncate font-medium">
            {title}
          </Text>
        ) : (
          title
        )}
        {meta ? (
          typeof meta === "string" || typeof meta === "number" ? (
            <Text variant="meta" className="mt-1">
              {meta}
            </Text>
          ) : (
            meta
          )
        ) : null}
      </span>
    </Link>
  );
}
