import * as React from "react";

import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  type CardProps,
} from "@/components/ui/card";
import { Text } from "@/components/ui/typography";
import { cn } from "@/lib/utils";

export interface SectionCardProps extends Omit<CardProps, "title"> {
  title?: React.ReactNode;
  description?: React.ReactNode;
  headerAside?: React.ReactNode;
  footer?: React.ReactNode;
  contentClassName?: string;
}

export function SectionCard({
  title,
  description,
  headerAside,
  footer,
  children,
  contentClassName,
  ...props
}: SectionCardProps) {
  return (
    <Card {...props}>
      {title || description || headerAside ? (
        <CardHeader>
          <div className="flex flex-wrap items-start justify-between gap-3">
            <div className="min-w-0 flex-1 space-y-1">
              {title ? <CardTitle>{title}</CardTitle> : null}
              {description ? <Text variant="meta">{description}</Text> : null}
            </div>
            {headerAside ? (
              <div className="flex shrink-0 flex-wrap items-center gap-2">
                {headerAside}
              </div>
            ) : null}
          </div>
        </CardHeader>
      ) : null}

      <CardContent className={cn("p-5 pt-0 md:p-7 ", contentClassName)}>
        {children}
      </CardContent>

      {footer ? (
        <div className="border-t border-input  px-5 py-4 md:px-7 md:py-5">
          {footer}
        </div>
      ) : null}
    </Card>
  );
}
