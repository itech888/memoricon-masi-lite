import * as React from "react";
import { cva, type VariantProps } from "class-variance-authority";

import { cn } from "@/lib/utils";

const tableShellVariants = cva(
  "overflow-hidden rounded-[1.65rem] border border-panel-border-strong bg-surface-strong shadow-card backdrop-blur-xl",
  {
    variants: {
      variant: {
        default: "",
        soft: "bg-surface-soft"
      }
    },
    defaultVariants: {
      variant: "default"
    }
  }
);

export interface TableShellProps
  extends React.HTMLAttributes<HTMLDivElement>,
    VariantProps<typeof tableShellVariants> {}

export function TableShell({
  className,
  variant,
  ...props
}: TableShellProps) {
  return <div className={cn(tableShellVariants({ variant, className }))} {...props} />;
}

export function TableContainer({
  className,
  ...props
}: React.HTMLAttributes<HTMLDivElement>) {
  return <div className={cn("overflow-x-auto", className)} {...props} />;
}

export function Table({
  className,
  ...props
}: React.TableHTMLAttributes<HTMLTableElement>) {
  return <table className={cn("w-full caption-bottom text-sm", className)} {...props} />;
}

export function TableHeader({
  className,
  ...props
}: React.HTMLAttributes<HTMLTableSectionElement>) {
  return <thead className={cn("bg-surface-muted", className)} {...props} />;
}

export function TableBody({
  className,
  ...props
}: React.HTMLAttributes<HTMLTableSectionElement>) {
  return <tbody className={cn("[&_tr:last-child]:border-0", className)} {...props} />;
}

export function TableRow({
  className,
  ...props
}: React.HTMLAttributes<HTMLTableRowElement>) {
  return (
    <tr
      className={cn(
        "border-b border-panel-border bg-surface-strong transition-colors odd:bg-surface/88 even:bg-surface-soft/45 hover:bg-accent/60",
        className
      )}
      {...props}
    />
  );
}

export function TableHead({
  className,
  ...props
}: React.ThHTMLAttributes<HTMLTableCellElement>) {
  return (
    <th
      className={cn(
        "h-12 px-4 text-left align-middle text-[0.72rem] font-semibold uppercase tracking-[0.16em] text-muted-foreground",
        className
      )}
      {...props}
    />
  );
}

export function TableCell({
  className,
  ...props
}: React.TdHTMLAttributes<HTMLTableCellElement>) {
  return <td className={cn("align-middle px-4 py-5", className)} {...props} />;
}

export function TableToolbar({
  className,
  ...props
}: React.HTMLAttributes<HTMLDivElement>) {
  return (
    <div
      className={cn(
        "flex flex-col gap-3 border-b border-panel-border bg-surface-muted px-4 py-4 md:px-5 lg:flex-row lg:items-center lg:justify-between",
        className
      )}
      {...props}
    />
  );
}

export function TableFooterBar({
  className,
  ...props
}: React.HTMLAttributes<HTMLDivElement>) {
  return (
    <div
      className={cn(
        "flex flex-col gap-3 border-t border-panel-border bg-surface-muted px-4 py-4 md:flex-row md:items-center md:justify-between md:px-5",
        className
      )}
      {...props}
    />
  );
}
