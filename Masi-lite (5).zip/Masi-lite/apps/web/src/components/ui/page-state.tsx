import * as React from "react";
import { cva, type VariantProps } from "class-variance-authority";

import { PageHeader } from "@/components/ui/page-header";
import { cn } from "@/lib/utils";

const pageStateVariants = cva("space-y-4", {
  variants: {
    variant: {
      default: "",
      error: ""
    }
  },
  defaultVariants: {
    variant: "default"
  }
});

export interface PageStateProps
  extends Omit<React.HTMLAttributes<HTMLDivElement>, "title">,
    VariantProps<typeof pageStateVariants> {
  title: React.ReactNode;
  description: React.ReactNode;
  action?: React.ReactNode;
}

export function PageState({
  title,
  description,
  action,
  className,
  variant,
  ...props
}: PageStateProps) {
  return (
    <div className={cn(pageStateVariants({ variant, className }))} {...props}>
      <PageHeader
        title={title}
        description={description}
        variant="compact"
      />
      {action ? <div className="flex flex-wrap items-center gap-2">{action}</div> : null}
    </div>
  );
}
