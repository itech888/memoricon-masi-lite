import * as React from "react";
import { cva, type VariantProps } from "class-variance-authority";

import { cn } from "@/lib/utils";

const badgeVariants = cva(
  "inline-flex items-center rounded-full border px-3 py-1 text-[0.72rem] font-semibold uppercase tracking-[0.12em] transition-colors",
  {
    variants: {
      variant: {
        default: "border-transparent bg-secondary-soft text-secondary-foreground",
        outline: "border-input bg-surface text-foreground",
        soft: "border-panel-border bg-surface-soft text-foreground",
        primary: "border-transparent bg-primary-soft text-primary",
        success: "border-status-success-border bg-status-success-bg text-status-success-foreground",
        warning: "border-status-warning-border bg-status-warning-bg text-status-warning-foreground",
        danger: "border-status-danger-border bg-status-danger-bg text-status-danger-foreground"
      }
    },
    defaultVariants: {
      variant: "default"
    }
  }
);

export interface BadgeProps
  extends React.HTMLAttributes<HTMLDivElement>,
    VariantProps<typeof badgeVariants> {}

function Badge({ className, variant, ...props }: BadgeProps) {
  return <div className={cn(badgeVariants({ variant }), className)} {...props} />;
}

export { Badge, badgeVariants };
