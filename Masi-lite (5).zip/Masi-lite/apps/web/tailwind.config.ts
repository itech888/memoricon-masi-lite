import type { Config } from "tailwindcss";

const config: Config = {
  darkMode: ["class"],
  content: [
    "./src/app/**/*.{ts,tsx}",
    "./src/components/**/*.{ts,tsx}",
    "./src/lib/**/*.{ts,tsx}"
  ],
  theme: {
    extend: {
      fontFamily: {
        ui: ["var(--font-ui)", "sans-serif"]
      },
      colors: {
        border: "hsl(var(--border))",
        input: "hsl(var(--input))",
        ring: "hsl(var(--ring))",
        background: "hsl(var(--background))",
        foreground: "hsl(var(--foreground))",
        primary: {
          DEFAULT: "hsl(var(--primary))",
          strong: "hsl(var(--primary-strong))",
          soft: "hsl(var(--primary-soft))",
          foreground: "hsl(var(--primary-foreground))"
        },
        secondary: {
          DEFAULT: "hsl(var(--secondary))",
          soft: "hsl(var(--secondary-soft))",
          border: "hsl(var(--secondary-border))",
          foreground: "hsl(var(--secondary-foreground))"
        },
        muted: {
          DEFAULT: "hsl(var(--muted))",
          foreground: "hsl(var(--muted-foreground))"
        },
        accent: {
          DEFAULT: "hsl(var(--accent))",
          foreground: "hsl(var(--accent-foreground))"
        },
        card: {
          DEFAULT: "hsl(var(--card))",
          foreground: "hsl(var(--card-foreground))"
        },
        destructive: {
          DEFAULT: "hsl(var(--destructive))",
          foreground: "hsl(var(--destructive-foreground))"
        },
        surface: {
          DEFAULT: "hsl(var(--surface))",
          soft: "hsl(var(--surface-soft))",
          strong: "hsl(var(--surface-strong))",
          muted: "hsl(var(--surface-muted))",
          panel: "hsl(var(--surface-panel))",
          input: "hsl(var(--surface-input))"
        },
        panel: {
          DEFAULT: "hsl(var(--panel-border))",
          border: "hsl(var(--panel-border))",
          "border-strong": "hsl(var(--panel-border-strong))"
        },
        nav: {
          surface: "hsl(var(--nav-surface))",
          border: "hsl(var(--nav-border))"
        },
        code: {
          bg: "hsl(var(--code-bg))",
          foreground: "hsl(var(--code-foreground))"
        },
        highlight: {
          ring: "hsl(var(--highlight-ring))"
        },
        sidebar: {
          DEFAULT: "hsl(var(--sidebar))",
          foreground: "hsl(var(--sidebar-foreground))",
          muted: "hsl(var(--sidebar-muted))",
          border: "hsl(var(--sidebar-border))",
          surface: "hsl(var(--sidebar-surface))",
          active: "hsl(var(--sidebar-active))",
          "active-foreground": "hsl(var(--sidebar-active-foreground))"
        },
        status: {
          ok: "hsl(var(--status-ok))",
          info: "hsl(var(--status-info))",
          success: {
            bg: "hsl(var(--status-success-bg))",
            border: "hsl(var(--status-success-border))",
            foreground: "hsl(var(--status-success-foreground))"
          },
          warning: {
            bg: "hsl(var(--status-warning-bg))",
            border: "hsl(var(--status-warning-border))",
            foreground: "hsl(var(--status-warning-foreground))"
          },
          danger: {
            bg: "hsl(var(--status-danger-bg))",
            border: "hsl(var(--status-danger-border))",
            foreground: "hsl(var(--status-danger-foreground))"
          }
        }
      },
      borderRadius: {
        lg: "var(--radius)",
        md: "calc(var(--radius) - 2px)",
        sm: "calc(var(--radius) - 4px)"
      },
      boxShadow: {
        soft: "0 18px 42px -34px hsl(var(--soft-shadow))",
        card: "0 30px 70px -42px hsl(var(--card-shadow))",
        button: "0 16px 34px -18px hsl(var(--button-shadow))"
      },
      keyframes: {
        "fade-up": {
          "0%": { opacity: "0", transform: "translateY(12px)" },
          "100%": { opacity: "1", transform: "translateY(0)" }
        }
      },
      animation: {
        "fade-up": "fade-up 500ms ease-out both"
      }
    }
  },
  plugins: []
};

export default config;
