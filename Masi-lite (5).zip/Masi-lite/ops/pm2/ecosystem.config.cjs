module.exports = {
  apps: [
    {
      name: "masi-api",
      cwd: "/var/www/masi-lite",
      script: "npm",
      args: "run start --workspace @masi/api",
      env: {
        NODE_ENV: "production",
        PORT: "8080"
      },
      instances: 1,
      exec_mode: "fork",
      autorestart: true,
      max_memory_restart: "320M",
      kill_timeout: 5000,
      time: true
    },
    {
      name: "masi-web",
      cwd: "/var/www/masi-lite",
      script: "npm",
      args: "run start --workspace @masi/web",
      env: {
        NODE_ENV: "production",
        PORT: "3000"
      },
      instances: 1,
      exec_mode: "fork",
      autorestart: true,
      max_memory_restart: "420M",
      kill_timeout: 5000,
      time: true
    }
  ]
};
