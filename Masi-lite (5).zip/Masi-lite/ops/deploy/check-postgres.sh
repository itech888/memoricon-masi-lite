#!/usr/bin/env bash
set -euo pipefail

if [[ -z "${DATABASE_URL:-}" ]]; then
  echo "[db-check] DATABASE_URL is not set"
  echo "[db-check] Export it first: export DATABASE_URL='postgresql://...'"
  exit 1
fi

echo "[db-check] Checking server connection"
psql "${DATABASE_URL}" -v ON_ERROR_STOP=1 -c "SELECT now() AS server_time;"

echo "[db-check] Checking role and schema privileges"
psql "${DATABASE_URL}" -v ON_ERROR_STOP=1 -c "SELECT current_user;"
psql "${DATABASE_URL}" -v ON_ERROR_STOP=1 -c "SELECT has_schema_privilege(current_user, 'public', 'USAGE') AS has_public_usage, has_schema_privilege(current_user, 'public', 'CREATE') AS has_public_create;"

echo "[db-check] Ensuring pgvector extension"
psql "${DATABASE_URL}" -v ON_ERROR_STOP=1 -c "CREATE EXTENSION IF NOT EXISTS vector;"
psql "${DATABASE_URL}" -v ON_ERROR_STOP=1 -c "SELECT extname, extversion FROM pg_extension WHERE extname = 'vector';"

echo "[db-check] Complete"
