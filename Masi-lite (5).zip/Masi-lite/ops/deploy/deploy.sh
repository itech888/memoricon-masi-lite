#!/usr/bin/env bash
set -euo pipefail

APP_DIR="${APP_DIR:-/var/www/masi-lite}"
BRANCH="${BRANCH:-main}"

echo "[deploy] App directory: ${APP_DIR}"
echo "[deploy] Branch: ${BRANCH}"

cd "${APP_DIR}"

if [[ ! -f "package.json" ]]; then
  echo "[deploy] package.json not found in ${APP_DIR}"
  exit 1
fi

if [[ ! -f "services/api/.env" ]]; then
  echo "[deploy] Missing services/api/.env"
  exit 1
fi

if [[ ! -f "apps/web/.env.local" ]]; then
  echo "[deploy] Missing apps/web/.env.local"
  exit 1
fi

echo "[deploy] Sync API runtime env"
cp "services/api/.env" ".env"

echo "[deploy] Pull latest code"
git fetch origin
git checkout "${BRANCH}"
git pull --ff-only origin "${BRANCH}"

echo "[deploy] Install dependencies"
npm ci

echo "[deploy] Build workspaces"
npm run build

echo "[deploy] Apply database migrations"
npm run db:migrate:deploy

echo "[deploy] Restart processes"
pm2 startOrReload ops/pm2/ecosystem.config.cjs --update-env
pm2 save
pm2 status

echo "[deploy] Complete"
