#!/usr/bin/env bash
set -euo pipefail

NODE_MAJOR="${NODE_MAJOR:-22}"
CREATE_SWAP="${CREATE_SWAP:-1}"
SWAP_SIZE_GB="${SWAP_SIZE_GB:-2}"

echo "[bootstrap] Update apt packages"
sudo apt update
sudo apt upgrade -y

echo "[bootstrap] Install base dependencies"
sudo apt install -y ca-certificates curl gnupg git nginx ufw build-essential postgresql-client

echo "[bootstrap] Install Node.js ${NODE_MAJOR}.x"
if ! command -v node >/dev/null 2>&1; then
  curl -fsSL "https://deb.nodesource.com/setup_${NODE_MAJOR}.x" | sudo -E bash -
  sudo apt install -y nodejs
fi

echo "[bootstrap] Install PM2"
if ! command -v pm2 >/dev/null 2>&1; then
  sudo npm install -g pm2
fi

if [[ "${CREATE_SWAP}" == "1" ]]; then
  if ! sudo swapon --show | grep -q "/swapfile"; then
    echo "[bootstrap] Create ${SWAP_SIZE_GB}G swapfile"
    sudo fallocate -l "${SWAP_SIZE_GB}G" /swapfile
    sudo chmod 600 /swapfile
    sudo mkswap /swapfile
    sudo swapon /swapfile
    echo "/swapfile none swap sw 0 0" | sudo tee -a /etc/fstab >/dev/null
  else
    echo "[bootstrap] Swapfile already exists"
  fi
fi

echo "[bootstrap] Configure UFW"
sudo ufw allow OpenSSH
sudo ufw allow "Nginx Full"
sudo ufw --force enable

echo "[bootstrap] Complete"
