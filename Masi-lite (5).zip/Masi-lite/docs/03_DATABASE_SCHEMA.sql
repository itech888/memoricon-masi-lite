-- 3) PostgreSQL schema for MASI-Lite Verified Memory Prototype
-- Compatible with standard Postgres. Optional pgvector section included below.
CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TABLE IF NOT EXISTS memories (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),

  -- Source data
  transcript TEXT NOT NULL,
  summary TEXT NOT NULL,
  tags TEXT[] NOT NULL DEFAULT '{}',

  -- MASI fields
  masi_state TEXT NOT NULL,
  masi_intent TEXT NOT NULL,
  masi_constraint TEXT NOT NULL,
  masi_verification TEXT NOT NULL,
  masi_outcome TEXT NOT NULL,

  -- Metadata
  confidence_score NUMERIC(5,4) NOT NULL CHECK (confidence_score >= 0 AND confidence_score <= 1),
  source_device TEXT NOT NULL,
  audio_url TEXT,

  -- Verification workflow
  verification_status TEXT NOT NULL CHECK (verification_status IN ('draft', 'verified', 'discarded')),
  verification_question TEXT,
  verified_at TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS idx_memories_created_at_desc ON memories (created_at DESC);
CREATE INDEX IF NOT EXISTS idx_memories_verification_status ON memories (verification_status);
CREATE INDEX IF NOT EXISTS idx_memories_tags_gin ON memories USING GIN (tags);

-- Full text search index for fallback retrieval
ALTER TABLE memories
  ADD COLUMN IF NOT EXISTS search_document tsvector GENERATED ALWAYS AS (
    to_tsvector(
      'english',
      coalesce(transcript, '') || ' ' ||
      coalesce(summary, '') || ' ' ||
      coalesce(masi_state, '') || ' ' ||
      coalesce(masi_intent, '') || ' ' ||
      coalesce(masi_constraint, '') || ' ' ||
      coalesce(masi_verification, '') || ' ' ||
      coalesce(masi_outcome, '')
    )
  ) STORED;

CREATE INDEX IF NOT EXISTS idx_memories_search_document ON memories USING GIN (search_document);

-- Optional semantic retrieval (pgvector)
-- 1) CREATE EXTENSION IF NOT EXISTS vector;
-- 2) Match dimension to chosen embedding model.
-- ALTER TABLE memories ADD COLUMN IF NOT EXISTS embedding vector(1536);
-- CREATE INDEX IF NOT EXISTS idx_memories_embedding ON memories USING ivfflat (embedding vector_cosine_ops) WITH (lists = 100);

-- Updated-at trigger
CREATE OR REPLACE FUNCTION set_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trigger_set_updated_at ON memories;
CREATE TRIGGER trigger_set_updated_at
BEFORE UPDATE ON memories
FOR EACH ROW
EXECUTE PROCEDURE set_updated_at();
