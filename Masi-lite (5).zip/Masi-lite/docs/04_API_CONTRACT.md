# 4) API Contract

Base URL (example): `https://api.your-domain.com`

All responses are JSON.

## 4.1 POST /capture
Accepts text or audio and returns transcript + MASI extraction draft.

### Request (text mode)
```json
{
  "input_type": "text",
  "text": "The vacuum pump pressure on Line 3 dropped below threshold during wafer processing. I stopped the process and replaced the pump filter.",
  "source_device": "web"
}
```

### Request (audio mode)
`multipart/form-data`
- `input_type=audio`
- `audio_file=<binary>`
- `source_device=web`

### Response
```json
{
  "draft_memory": {
    "transcript": "...",
    "summary": "...",
    "tags": ["maintenance", "pump", "wafer-processing"],
    "masi": {
      "state": "...",
      "intent": "...",
      "constraint": "...",
      "verification": "...",
      "outcome": "..."
    },
    "confidence_score": 0.78,
    "source_device": "web",
    "audio_url": null,
    "verification_status": "draft",
    "verification_question": "Is this a confirmed maintenance action?",
    "verification_response": "needs_clarification"
  }
}
```

## 4.2 POST /memory
Stores a confirmed memory entry.

### Request
```json
{
  "transcript": "...",
  "summary": "Vacuum pump pressure drop on Line 3",
  "tags": ["maintenance", "pump", "wafer-processing"],
  "masi": {
    "state": "Wafer processing operation on Line 3",
    "intent": "Maintain safe operating conditions",
    "constraint": "Pump pressure must remain above minimum threshold",
    "verification": "Pump filter replacement performed",
    "outcome": "Process paused and maintenance action taken"
  },
  "confidence_score": 0.78,
  "source_device": "web",
  "audio_url": null,
  "verification_status": "verified",
  "verification_question": "Is this a confirmed maintenance action?",
  "verification_response": "confirmed"
}
```

### Response
```json
{
  "memory": {
    "id": "9efb1288-1c3b-4e88-8d7f-57bddeef9ca4",
    "timestamp": "2026-03-06T12:34:56.000Z",
    "summary": "Vacuum pump pressure drop on Line 3",
    "verification_status": "verified"
  }
}
```

## 4.3 GET /memory
Returns memory cards (newest first).

### Query params
- `q` optional search text
- `tag` optional tag filter
- `date_from` optional ISO datetime or `YYYY-MM-DD`
- `date_to` optional ISO datetime or `YYYY-MM-DD`
- `limit` default 20
- `offset` default 0

### Response
```json
{
  "items": [
    {
      "id": "9efb1288-1c3b-4e88-8d7f-57bddeef9ca4",
      "timestamp": "2026-03-06T12:34:56.000Z",
      "summary": "Vacuum pump pressure drop on Line 3",
      "tags": ["maintenance", "pump", "wafer-processing"],
      "confidence_score": 0.78,
      "verification_status": "verified"
    }
  ],
  "total": 1
}
```

## 4.4 GET /memory/:id
Returns full memory detail.

### Response
```json
{
  "memory": {
    "id": "...",
    "timestamp": "...",
    "transcript": "...",
    "summary": "...",
    "tags": ["..."],
    "masi": {
      "state": "...",
      "intent": "...",
      "constraint": "...",
      "verification": "...",
      "outcome": "..."
    },
    "confidence_score": 0.78,
    "source_device": "web",
    "audio_url": null,
    "verification_status": "verified",
    "verification_response": "confirmed",
    "verified_at": "2026-03-06T12:35:01.000Z"
  }
}
```

## 4.5 POST /ask
Retrieves relevant memories and returns answer + citations.

### Request
```json
{
  "question": "What happened with the vacuum pump on Line 3?",
  "top_k": 5
}
```

### Response
```json
{
  "answer": "During wafer processing on Line 3, pump pressure dropped below threshold. The process was paused and the pump filter was replaced.",
  "citations": [
    {
      "memory_id": "9efb1288-1c3b-4e88-8d7f-57bddeef9ca4",
      "summary": "Vacuum pump pressure drop on Line 3",
      "timestamp": "2026-03-06T12:34:56.000Z",
      "relevance_score": 0.91
    }
  ]
}
```

## 4.6 Error Format
```json
{
  "error": {
    "code": "VALIDATION_ERROR",
    "message": "Field 'question' is required",
    "details": []
  }
}
```

Recommended codes:
- `VALIDATION_ERROR`
- `TRANSCRIPTION_ERROR`
- `EXTRACTION_ERROR`
- `DATABASE_ERROR`
- `RETRIEVAL_ERROR`
- `INTERNAL_ERROR`
