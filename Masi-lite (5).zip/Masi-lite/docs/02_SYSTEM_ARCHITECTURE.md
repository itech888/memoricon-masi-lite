# 2) System Architecture

## 2.1 High-Level Architecture

- **Frontend (Next.js)**
  - Tailwind CSS + shadcn-style component primitives
  - Capture UI (voice/text)
  - MASI preview + edit UI
  - Verification UI
  - Timeline + detail views
  - Ask/Recall UI
- **Backend API (Node.js + Express)**
  - Audio intake and Whisper transcription
  - MASI extraction orchestration
  - Verification and persistence
  - Retrieval + answer generation with citations
- **Database (PostgreSQL)**
  - Accessed through Prisma ORM
  - `memories` table
  - Optional embeddings table/column for semantic retrieval
- **AI Services (OpenAI API)**
  - Whisper transcription
  - Chat model for extraction and QA synthesis
  - Embeddings model (recommended)

## 2.2 Request Flow

### Capture Flow
1. Frontend posts audio/text to `POST /capture`.
2. Backend transcribes audio (if present).
3. Backend calls extraction prompt to generate MASI JSON.
4. Backend returns transcript + extracted structured draft.

### Verify/Store Flow
1. Frontend lets user edit draft fields.
2. Verification response must be explicitly affirmative before save is enabled.
3. Frontend posts confirmed object to `POST /memory`.
4. Backend validates schema and rejects non-affirmative verification responses.
5. Backend saves memory with `verification_status=verified`.
6. Backend generates and stores an embedding for recall retrieval.

### Recall Flow
1. Frontend posts question to `POST /ask`.
2. Backend embeds the question.
3. Backend retrieves relevant memories through pgvector similarity search.
3. Backend prompts model with retrieved contexts.
4. Backend returns answer + citation array.

## 2.3 Device-Agnostic Contract
All capture clients (web/mobile/future smart glasses) use the same backend endpoints.

Client-specific only:
- audio capture UX

Shared backend contract:
- transcript + MASI extraction
- verification persistence
- recall query and citation logic

## 2.4 Recommended Repo Layout

```txt
masi-lite/
  apps/
    web/                 # Next.js frontend
  services/
    api/                 # Express backend
  packages/
    shared/              # zod schemas, types
  docs/
```

## 2.5 Reliability Rules
- Never store as `verified` unless user confirms.
- Never persist drafts to PostgreSQL before verification.
- Store both raw transcript and structured fields.
- Store a real `audio_url` for voice captures.
- Citation output must reference concrete memory IDs.
- Validate model JSON output against schema before returning to UI.

## 2.6 Logging and Observability
- Log request ID per API call.
- Log model errors with sanitized payload metadata.
- Log storage operations (insert/update) without secrets.

## 2.7 Security (Prototype Level)
- Use API keys via environment variables only.
- Restrict CORS to deployed frontend URL.
- Set payload size limits for audio uploads.
- Basic rate limit on `/capture` and `/ask`.
