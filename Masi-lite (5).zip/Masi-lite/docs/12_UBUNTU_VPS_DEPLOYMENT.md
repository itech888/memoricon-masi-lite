# 12) Ubuntu Production Deployment Guide

This is the production deployment guide for MASI-Lite on a single Ubuntu 24.04 VPS.

It matches the current production setup used for `memoricon.ai`.

## 12.1 Architecture

- Web app: Next.js (`@masi/web`) on `127.0.0.1:3000`
- API: Express (`@masi/api`) on `127.0.0.1:8080`
- Database: local PostgreSQL 17 with `pgvector`
- Process manager: PM2
- Reverse proxy: Nginx
- TLS: Certbot / Let's Encrypt
- Audio storage: local filesystem at `/var/lib/masi-lite/audio`

Public routing:

- `https://memoricon.ai/` -> Next.js
- `https://memoricon.ai/api/` -> API
- `https://memoricon.ai/media/audio/` -> API-served audio

## 12.2 Server Prerequisites

- Ubuntu 24.04 VPS
- SSH access as `root`
- Domain pointing to the server IP
- OpenAI API key
- GitHub access to this repository

Recommended server size:

- 1 vCPU / 1 GB RAM is acceptable for this prototype
- Swap is strongly recommended

## 12.3 Initial Server Bootstrap

SSH into the server:

```bash
ssh root@YOUR_SERVER_IP
```

Prepare the app directory:

```bash
mkdir -p /var/www
cd /var/www
git clone git@github.com:AwaisKhanz/masi-lite.git
cd masi-lite
```

Run bootstrap:

```bash
./ops/deploy/bootstrap-ubuntu.sh
```

This installs:

- Node.js
- npm
- PM2
- Nginx
- UFW
- build tools
- PostgreSQL client tools
- swap file

## 12.4 Install Local PostgreSQL 17 + pgvector

Add the official PostgreSQL APT repository:

```bash
apt update
apt install -y postgresql-common ca-certificates curl
install -d /usr/share/postgresql-common/pgdg
curl -o /usr/share/postgresql-common/pgdg/apt.postgresql.org.asc --fail https://www.postgresql.org/media/keys/ACCC4CF8.asc

. /etc/os-release
echo "deb [signed-by=/usr/share/postgresql-common/pgdg/apt.postgresql.org.asc] https://apt.postgresql.org/pub/repos/apt $VERSION_CODENAME-pgdg main" \
  > /etc/apt/sources.list.d/pgdg.list

apt update
```

Install PostgreSQL 17 and pgvector:

```bash
apt install -y postgresql-17 postgresql-client-17 postgresql-contrib-17 postgresql-17-pgvector
systemctl enable --now postgresql
```

Create the application role, database, and extension:

```bash
sudo -u postgres psql <<'SQL'
CREATE ROLE masi_user WITH LOGIN PASSWORD 'CHANGE_THIS_PASSWORD';
CREATE DATABASE masi_lite OWNER masi_user;
\c masi_lite
CREATE EXTENSION IF NOT EXISTS vector;
GRANT USAGE, CREATE ON SCHEMA public TO masi_user;
ALTER SCHEMA public OWNER TO masi_user;
SQL
```

Verify database access:

```bash
PGPASSWORD='CHANGE_THIS_PASSWORD' psql -h localhost -U masi_user -d masi_lite -c "select current_database(), current_user;"
PGPASSWORD='CHANGE_THIS_PASSWORD' psql -h localhost -U masi_user -d masi_lite -c "select extname from pg_extension where extname='vector';"
```

## 12.5 Configure Environment Files

### API env

Create the API env file:

```bash
cp ops/env/api.production.env.example services/api/.env
nano services/api/.env
```

Example:

```env
NODE_ENV=production
PORT=8080

APP_BASE_URL=https://memoricon.ai/api
DATABASE_URL=postgresql://masi_user:CHANGE_THIS_PASSWORD@localhost:5432/masi_lite?schema=public

CORS_ORIGIN=https://memoricon.ai
REQUEST_BODY_LIMIT=5mb
RATE_LIMIT_WINDOW_MS=60000
RATE_LIMIT_MAX_CAPTURE=30
RATE_LIMIT_MAX_ASK=30

OPENAI_API_KEY=YOUR_OPENAI_KEY
OPENAI_TRANSCRIBE_MODEL=gpt-4o-mini-transcribe
OPENAI_CHAT_MODEL=gpt-4.1-mini
OPENAI_EMBEDDING_MODEL=text-embedding-3-small

AUDIO_STORAGE_MODE=local
AUDIO_STORAGE_DIR=/var/lib/masi-lite/audio
```

### Important runtime note

The current PM2 config runs the API with:

- `cwd: /var/www/masi-lite`

The API loads env using `dotenv/config`, so at runtime it reads:

- `/var/www/masi-lite/.env`

not:

- `/var/www/masi-lite/services/api/.env`

Because of that, sync the API env into the repo root before starting or deploying:

```bash
cp /var/www/masi-lite/services/api/.env /var/www/masi-lite/.env
```

### Web env

Create the web env file:

```bash
cp ops/env/web.production.env.example apps/web/.env.local
nano apps/web/.env.local
```

Example:

```env
NODE_ENV=production
NEXT_PUBLIC_API_BASE_URL=https://memoricon.ai/api
NEXT_PUBLIC_SITE_URL=https://memoricon.ai
```

### Audio directory

Create the local audio directory:

```bash
mkdir -p /var/lib/masi-lite/audio
chown -R $USER:$USER /var/lib/masi-lite
```

## 12.6 First Build, Migration, and Start

Install dependencies:

```bash
npm ci
```

Run migrations:

```bash
npm run db:migrate:deploy
```

Build the app:

```bash
npm run build
```

Start PM2:

```bash
pm2 start ops/pm2/ecosystem.config.cjs
pm2 save
pm2 startup
pm2 status
```

## 12.7 Health Checks Before Nginx

Verify API directly:

```bash
curl -i http://127.0.0.1:8080/health
```

Expected readiness:

- `database: up`
- `openai: up`
- `audio_storage: ready`
- `embeddings: up`

Verify web directly:

```bash
curl -I http://127.0.0.1:3000
```

The web app may return `307` redirecting `/` to `/capture`. That is expected.

## 12.8 Configure Nginx

Install the Nginx site file:

```bash
cp /var/www/masi-lite/ops/nginx/masi-lite.conf /etc/nginx/sites-available/masi-lite
```

Edit the site file:

```bash
nano /etc/nginx/sites-available/masi-lite
```

Set:

```nginx
server_name memoricon.ai www.memoricon.ai;
```

Enable the site:

```bash
ln -sf /etc/nginx/sites-available/masi-lite /etc/nginx/sites-enabled/masi-lite
rm -f /etc/nginx/sites-enabled/default
nginx -t
systemctl reload nginx
```

## 12.9 Configure DNS

Create these DNS records:

- `A` record: `@` -> server IPv4
- `A` record: `www` -> server IPv4

Verify:

```bash
dig +short memoricon.ai
dig +short www.memoricon.ai
```

Both should resolve to the server IP.

## 12.10 Enable HTTPS

Install Certbot:

```bash
apt update
apt install -y certbot python3-certbot-nginx
```

Issue the certificate:

```bash
certbot --nginx -d memoricon.ai -d www.memoricon.ai
```

Recommended choices:

- agree to terms: `y`
- EFF mailing list: `N`
- redirect HTTP to HTTPS: choose redirect

Verify:

```bash
curl -I https://memoricon.ai
curl -I https://memoricon.ai/api/health
```

Test renewal:

```bash
certbot renew --dry-run
```

## 12.11 Ongoing Deployments

Normal update flow:

```bash
cd /var/www/masi-lite
./ops/deploy/deploy.sh
```

This script:

1. checks env files
2. syncs `services/api/.env` -> root `.env`
3. pulls latest code
4. runs `npm ci`
5. runs `npm run build`
6. runs `npm run db:migrate:deploy`
7. reloads PM2

If you want to do the steps manually:

```bash
cd /var/www/masi-lite
git pull --ff-only origin main
cp services/api/.env .env
npm ci
npm run db:migrate:deploy
npm run build
pm2 startOrReload ops/pm2/ecosystem.config.cjs --update-env
pm2 save
```

## 12.12 Database Operations

Apply schema migrations:

```bash
npm run db:migrate:deploy
```

Check current tables:

```bash
PGPASSWORD='CHANGE_THIS_PASSWORD' psql -h localhost -U masi_user -d masi_lite -c "\dt"
```

Check vector extension:

```bash
PGPASSWORD='CHANGE_THIS_PASSWORD' psql -h localhost -U masi_user -d masi_lite -c "select extname from pg_extension where extname='vector';"
```

Optional demo seed:

```bash
npm run db:seed
```

## 12.13 Post-Deploy Verification

Check Nginx:

```bash
nginx -t
systemctl status nginx --no-pager
```

Check PM2:

```bash
pm2 status
pm2 logs masi-api --lines 100
pm2 logs masi-web --lines 100
```

Check public endpoints:

```bash
curl -I https://memoricon.ai
curl -i https://memoricon.ai/api/health
```

Check browser-scoped memory flow:

1. open the site in one browser
2. create and save a memory
3. confirm it appears in Timeline
4. confirm Ask/Recall can find it
5. open a different browser
6. confirm the first browser's memories are not visible there

## 12.14 Known Operational Notes

### Root `.env` sync

Because of the current PM2 `cwd`, API runtime uses the repo root `.env`.

That is why `deploy.sh` copies:

```bash
services/api/.env -> .env
```

If API health unexpectedly shows wrong database or CORS values, verify:

```bash
grep '^DATABASE_URL=' /var/www/masi-lite/.env
grep '^DATABASE_URL=' /var/www/masi-lite/services/api/.env
```

### Browser-scoped memories

This app does not use full authentication.

Instead, it uses a per-browser generated session UUID. That means:

- one browser only sees its own memories
- another browser gets a different memory set
- Ask/Recall only searches that browser's memories

Existing memories created before `session_id` was added will not appear in scoped results unless they are backfilled manually.

### Kernel upgrade notice

Ubuntu may report a pending kernel upgrade. That does not block deployment.

Reboot during a safe window:

```bash
reboot
```

Then verify:

```bash
pm2 status
systemctl status nginx --no-pager
curl -I https://memoricon.ai
curl -i https://memoricon.ai/api/health
```

## 12.15 Troubleshooting

### API health shows database down

Check:

```bash
PGPASSWORD='CHANGE_THIS_PASSWORD' psql -h localhost -U masi_user -d masi_lite -c "select 1;"
pm2 logs masi-api --lines 200
```

If PM2 logs show stale database settings, sync env again:

```bash
cp /var/www/masi-lite/services/api/.env /var/www/masi-lite/.env
pm2 restart masi-api --update-env
pm2 save
```

### Web is serving old `NEXT_PUBLIC_*` values

Rebuild and restart the web app:

```bash
cd /var/www/masi-lite
npm run build
pm2 restart masi-web --update-env
pm2 save
```

### Shared package / TypeScript build problems on server

If you get odd monorepo build resolution errors after pulling code:

```bash
cd /var/www/masi-lite
rm -rf node_modules
rm -rf apps/web/.next
rm -rf packages/shared/dist
rm -rf services/api/dist
find . -name '*.tsbuildinfo' -delete
npm cache verify
npm ci
npm run build
```

### SSL issuance fails on first run

Re-run:

```bash
certbot --nginx -d memoricon.ai -d www.memoricon.ai
```

Transient ACME authorization issues can resolve on the second run.
