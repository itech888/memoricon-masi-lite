# 8) Testing and Demo Runbook

## 8.1 Test Layers
- Unit tests: schema validation, retrieval ranking utility, API validators.
- Integration tests: `/capture`, `/memory`, `/ask` with real DB.
- E2E tests: browser flow across all 6 screens.

## 8.2 Critical Test Cases

Quick automated checks:
- `npm run db:smoke` verifies DB read/write path.
- `npm run seed:demo` inserts sample memories for demo.
- `npm run smoke:e2e` runs capture -> verify/save -> list -> ask flow against running API.

### T1: Text Capture Happy Path
1. Enter text in capture screen.
2. Submit and verify draft fields are populated.
3. Confirm memory.
4. Check timeline for new card.

Expected: Memory saved as `verified` with all required fields.

### T2: Audio Capture Happy Path
1. Record short audio clip.
2. Submit.
3. Verify transcript appears.

Expected: Transcript is non-empty and editable via extraction screen.

### T3: Edit Before Confirm
1. Capture input.
2. Edit MASI fields.
3. Confirm.
4. Open detail.

Expected: Stored record reflects edited values.

### T4: Discard Path
1. Capture input.
2. Go to verify.
3. Click discard.

Expected: No verified memory is created.

### T5: Recall with Citation
1. Save known memory.
2. Ask related question.

Expected: Answer references relevant memory content and includes citation memory ID.

## 8.3 Manufacturing Use Case Validation
Use exact sample:

Input:
"The vacuum pump pressure on Line 3 dropped below threshold during wafer processing. I stopped the process and replaced the pump filter."

Checks:
- State maps to Line 3 wafer operation.
- Intent maps to safe operation.
- Constraint maps to threshold requirement.
- Verification mentions filter replacement.
- Outcome mentions pause + maintenance action.
- Recall question returns answer with citation.

## 8.4 Demo Checklist
- Public frontend URL accessible.
- API URL healthy.
- At least 3 memories pre-seeded for recall demonstration.
- One manufacturing scenario recorded live during demo.
- Citation links open corresponding memory detail records.

## 8.5 Failure Handling During Demo
- If transcription fails: switch to text input fallback.
- If extraction parsing fails: show retry button and preserve transcript.
- If recall returns low confidence: show "insufficient evidence" response.
