# 6) UI Screen Spec (Next.js)

## 6.1 Route Map
- `/capture` -> Screen 1: Capture
- `/extract` -> Screen 2: MASI Extraction Preview
- `/verify` -> Screen 3: Verification
- `/timeline` -> Screen 4: Memory Timeline
- `/memory/[id]` -> Screen 5: Memory Detail
- `/ask` -> Screen 6: Ask/Recall

## 6.2 Shared UI Rules
- Keep UI clean and functional (demo-first).
- Use Tailwind CSS with shadcn-style primitives (`Button`, `Input`, `Textarea`, `Card`) for consistency.
- Show loading and error states on every API action.
- Preserve in-progress draft memory in local state until confirmed/discarded.

## 6.3 Screen 1: Capture
### Required Components
- Large mic button (`Start` / `Stop`)
- Optional text input (`textarea`)
- Recording state indicator
- Submit button

### Behavior
- User can choose text or audio mode.
- On submit, call `POST /capture`.
- On success, navigate to `/extract` with draft memory payload.

## 6.4 Screen 2: MASI Extraction Preview
### Required Components
- Transcript panel
- Summary field
- MASI fields:
  - State
  - Intent
  - Constraint
  - Verification
  - Outcome
- Editable inputs for all fields
- Continue button

### Behavior
- Pre-fill with backend extraction.
- User edits if needed.
- Continue to `/verify` carrying edited draft.

## 6.5 Screen 3: Verification
### Required Components
- Summary display
- Confidence score (percentage)
- Verification question
- Buttons:
  - Confirm Memory
  - Edit Memory
  - Discard

### Behavior
- `Confirm` -> call `POST /memory` with `verification_status=verified`, then navigate `/timeline`.
- `Edit` -> navigate back `/extract`.
- `Discard` -> clear draft and navigate `/capture`.

## 6.6 Screen 4: Memory Timeline
### Required Components
- Search input
- Scrollable memory card list
- Card fields: summary, timestamp, tags

### Behavior
- Fetch from `GET /memory`.
- Click card -> `/memory/[id]`.

## 6.7 Screen 5: Memory Detail
### Required Components
- Transcript
- Summary
- MASI fields
- Timestamp
- Source device
- Optional audio player if `audio_url` exists

### Behavior
- Load with `GET /memory/:id`.

## 6.8 Screen 6: Ask/Recall
### Required Components
- Question input
- Submit button
- Answer panel
- Citations list with memory links

### Behavior
- Submit -> `POST /ask`.
- Display answer and citation cards.
- Citation click opens `/memory/[id]`.

## 6.9 Suggested Component Structure
```txt
apps/web/src/
  app/
    capture/page.tsx
    extract/page.tsx
    verify/page.tsx
    timeline/page.tsx
    memory/[id]/page.tsx
    ask/page.tsx
  components/
    capture/Recorder.tsx
    memory/MasiEditor.tsx
    memory/MemoryCard.tsx
    recall/CitationList.tsx
```
