# 1) Product Requirements Document (PRD)

## 1.1 Objective

Build a working prototype of a **MASI-Lite Verified Memory Agent** that reliably captures user memory, structures it into MASI fields, verifies correctness with the user, stores verified memory in PostgreSQL, and answers later recall questions with citations.

## 1.2 Primary Demonstration Flow

1. User records voice (or enters text).
2. System transcribes speech to text (if voice).
3. System extracts MASI structure from transcript.
4. User verifies/edits extracted fields.
5. Verified memory is persisted.
6. User asks a question; system retrieves relevant memories and returns answer with citation(s).

## 1.3 In Scope (Prototype)

- Single-user demo mode (no authentication).
- Web app (Next.js).
- REST backend (Node.js + Express).
- PostgreSQL persistent storage via Prisma ORM.
- OpenAI Whisper for speech-to-text.
- OpenAI Chat model for:
  - MASI extraction
  - Verification prompt generation
  - Answer generation with cited memory IDs
- Timeline, detail view, and ask/recall UX.

## 1.4 Out of Scope (Prototype)

- Multi-user tenancy and RBAC.
- Advanced analytics dashboards.
- Offline sync.
- Smart glasses client implementation (only backend compatibility).
- Enterprise security/compliance hardening.

## 1.5 User Roles

- Primary role: operator/technician/supervisor using a single demo account context.

## 1.6 Core Data Model (Required Fields)

Each memory entry must include:

- `id`
- `timestamp`
- `transcript`
- `summary`
- `tags[]`
- `masi.state`
- `masi.intent`
- `masi.constraint`
- `masi.verification`
- `masi.outcome`
- `confidence_score`
- `source_device`
- `audio_url` (optional)
- `verification_status` (draft/verified/discarded)

## 1.7 Functional Requirements

### FR-1 Capture

- User can record audio from browser.
- User can alternatively enter text manually.
- System shows recording state: idle/recording/processing.

### FR-2 Transcription

- System accepts audio and returns transcript text.
- If transcription fails, user sees actionable retry message.

### FR-3 MASI Extraction

- System converts transcript to structured MASI JSON.
- System produces summary, tags, and confidence score.
- Output must be schema-valid JSON.

### FR-4 Verification

- User can edit any extracted field.
- User can confirm, edit-and-confirm, or discard.
- Only confirmed entries become `verified`.

### FR-5 Storage

- Verified memory is saved in PostgreSQL.
- Timeline API returns newest-first memory cards.

### FR-6 Recall

- User asks a natural-language question.
- System retrieves relevant memories.
- System answer includes explicit citations (memory IDs + summaries).

## 1.8 Non-Functional Requirements

- End-to-end (capture to save) should complete in < 15s under normal network.
- Recall response should complete in < 8s for up to 2,000 memory records.
- API errors return consistent JSON error format.
- Logs exclude raw secrets.

## 1.9 Acceptance Criteria

- All six screens operate end-to-end without manual DB intervention.
- Manufacturing use case succeeds exactly as documented.
- Recall answer includes at least 1 citation for relevant question.
- Data persists across server restarts.

## 1.10 Example Demo Script

Input:
"I told Jenifer that smart glasses will capture audio but verification runs on the server."

Expected behavior:

- Transcript appears.
- MASI fields extracted.
- User confirms.
- Memory appears in timeline.
- Ask: "What did I say about smart glasses architecture?"
- Answer includes cited memory record.
